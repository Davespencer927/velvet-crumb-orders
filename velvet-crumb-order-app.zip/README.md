# Velvet Crumb order app

Customers pick brownies and blondies from a picture menu, make their choices (base and topping, or fill a box with flavours), choose collection or local delivery and a day, and pay by card, Apple Pay or Google Pay through Stripe. Jess runs everything from a separate admin page on her phone, branded with the Velvet Crumb logo.

It is a Node.js app that runs on Fly.io, with Jess's own Stripe account. It has no outside packages to install, and its database is built into Node (Node 22.13 or later). The database and photos live on a Fly.io volume, so no separate database service (such as Supabase) is needed.

## What's in it

**Customer page** (`/`)
- Menu grouped by section (Classic, Loaded, Boxes, Gluten free and vegan…), each item with a picture, price, description and allergens
- + and − buttons on each picture. Items with choices open a picker: e.g. brownie or blondie base and a topping
- Boxes of 4, 6 and 9 (and the gluten free and vegan boxes) are filled with + and − on each flavour, no typing. Customers pick a base when the box has classic bakes, and the price follows the menu: all classic, a mix, or all loaded. Jess edits the flavour lists in Settings, under Box flavours
- Notices at the top of the menu, worded by Jess (e.g. "Coming soon", "Special offer", "Monthly specials")
- Items can carry a label on the picture (e.g. "Special offer", "New") and a crossed-out "was" price
- "Coming soon" items show on the menu with their label but can't be ordered yet
- Basket bar and a checkout sheet
- Collection (free) or local delivery (fee, optional free-delivery threshold, optional postcode list)
- Day picker driven by Jess's weekly opening times, with separate collection and delivery days and times, notice needed, days off and a daily order limit. The time window goes on the confirmation
- Allergens shown on every item, at checkout (customer must tick to confirm) and on the confirmation
- Payment taken there and then by Stripe Checkout; the order only counts once paid
- Order page with the collection address (only shown after payment) and a receipt email

**Admin page** (`/admin`, password protected)
- **Orders**: coming up by day, a "to bake" list per day (with each choice), Mark ready, Mark collected/delivered, Cancel and refund (refunds through Stripe), Call/Text/Email buttons
- **Clients**: everyone who pays is saved automatically (matched by email or mobile, so repeat customers aren't duplicated). Search, add clients by hand (e.g. a café or a Facebook regular), edit, add notes, see their order history and total spend, delete, download as CSV
- **Menu**: add, edit, delete, reorder; upload a photo (resized on the phone first) or pick a clip-art picture; price and cost to make with live profit per item; sets of choices with extra price and extra cost per choice; a question for the customer; a label on the picture and a "was" price for offers; 14 allergens or "contains none"; On sale / Coming soon / Sold out / Hidden
- **Money**: sales, cost of bakes, card fees, other costs and profit for this month, last month, this or last tax year, or any dates; best sellers; month by month; log other costs; CSV downloads for the accounts
- **Privacy notice and terms of sale** at `/privacy` and `/terms`, linked from the menu, checkout and order page. Jess edits the wording on the Settings tab; `{business}` and `{contact}` fill in from Settings
- **Settings**: notices on the menu (heading and wording, show or hide, up to 6), opening days and times (collection and delivery separately, all closed until Jess ticks them), notice, limits, days off, pause orders, collection and delivery details, allergen note, alert email, Instagram and Facebook links, card fee rates, delete test orders

## The starter menu

The first time the app starts it loads Jess's menu from both menu sheets: Classic, Loaded, Boxes of 4, 6 and 9, and the gluten free and vegan range with boxes of 2, 4, 6 and 9, all at the menu prices. Each has a clip-art picture until Jess uploads photos. The Monthly special is there but hidden, for Jess to rename and show each month. The gluten free and vegan range starts as **Coming soon**: on the menu but not orderable until Jess switches each item to On sale. Two notices are set up from the menu sheet, "Coming soon" and "Monthly specials", for Jess to reword, hide or replace (e.g. with a special offer).

Left for Jess to fill in on the Menu tab:
- **Cost to make** for each item (and for a mixed or all-loaded box, in the item's Box section), so the Money tab shows real profit
- **Box flavours** in Settings: two lists to start with, Main menu and Gluten free and vegan, taken from the menu sheets. Jess can rename, add or remove flavours, mark each Classic or Loaded, and change the bases. Each box item says how many bakes it holds and which list it uses
- **Allergens** from her allergen register. Until she does, customers see "Allergens: ask Jess before ordering" and the Menu tab flags each item

Once loaded, the starter menu never comes back: anything Jess deletes stays deleted.

## Keeping data only as long as needed

The privacy notice promises these, and the app does them automatically:
- Unpaid orders are deleted after 30 days
- Clients with no orders for 2 years are deleted
- Names and contact details are removed from orders older than 6 years (the amounts stay for the accounts)

## How the money page works

- **Sales**: every paid order, including delivery fees, by the day it was paid.
- **Cost of bakes**: each item's *cost to make* (from the pricing calculator), plus any extra cost for the choices picked, × how many sold. It's saved with each order, so changing a cost later doesn't rewrite the past.
- **Card fees**: the real Stripe fee for each payment (estimated from the % in Settings until Stripe reports it). Stripe keeps the fee on refunds, so those still count.
- **Other costs**: anything Jess logs by hand: equipment, ads, market pitches, Fly.io and the domain. Ingredients and packaging are already covered by the cost to make, so don't log them twice.
- Refunded orders are left out of sales.

## Run it on a computer

```
ADMIN_PASSWORD=pick-one npm start
```

Open http://localhost:3000 for the shop and http://localhost:3000/admin for the admin. With no Stripe key it runs in **test mode**: orders can be "paid" with a test button and nothing is charged.

Run the tests with `npm test`.

## Go-live steps (all from an iPad browser)

1. **GitHub**: create a new private repository, e.g. `velvet-crumb-orders`, ticking "Add a README file", and put this folder's contents at the top level of it (`fly.toml`, `Dockerfile`, `package.json`, `src/`, `public/`…). On an iPad the easiest way is a GitHub Codespace: open the repo → Code → Codespaces → create, upload the zip, then in the terminal run `unzip velvet-crumb-order-app.zip && cp -r velvet-crumb/. . && rm -r velvet-crumb velvet-crumb-order-app.zip && git add -A && git commit -m "Velvet Crumb app" && git push`.
2. **Fly.io**: sign in with GitHub, then Dashboard → Launch an app → pick the repo. It reads `fly.toml`: London region, one always-on machine, and a 1 GB volume for the data, created on the first deploy. If `velvet-crumb-orders` is taken as a name, change `app =` in `fly.toml` on GitHub and launch again.
3. **Admin password**: in Fly.io → your app → Secrets, add `ADMIN_PASSWORD` (long and unique) and `BASE_URL` = `https://velvet-crumb-orders.fly.dev` (or your own name), then Deploy secrets.
4. **Check it**: open the app's address for the shop and `/admin` for the admin. It runs in test mode until Stripe is added.
5. **Menu and settings** (Jess): on the Menu tab, add the cost to make and allergens for each item, and photos when ready. On Settings, tick the opening days and times, then set notice needed, the collection address, delivery fee and postcodes, the alert email and phone, and the notices.
6. **Stripe** (Jess, as the business owner): open and verify a Stripe account. Add the secret `STRIPE_SECRET_KEY` (test key first, `sk_test_…`). In Stripe → Developers → Webhooks, add an endpoint at `https://<your address>/api/stripe/webhook` for these events:
   - `checkout.session.completed`
   - `checkout.session.async_payment_succeeded`
   - `checkout.session.expired`

   Copy its signing secret into the secret `STRIPE_WEBHOOK_SECRET` and deploy secrets.
7. **Test**: place orders with Stripe's test card 4242 4242 4242 4242, check the confirmation, mark ready and collected, cancel and refund one.
8. **Go live**: Settings → Delete test orders, then swap in the live Stripe key (`sk_live_…`) and a live-mode webhook with its own signing secret. Share the link and a QR code on Instagram and Facebook.

Optional, any time:
- **Order emails**: with Resend, verify a domain, then add the secrets `RESEND_API_KEY` and `EMAIL_FROM` (e.g. `Velvet Crumb <orders@yourdomain>`). Without this, orders still work and Jess sees them in the admin.
- **Own domain**: Fly.io → your app → Certificates → add the domain, add the DNS records it shows where the domain was bought, then change `BASE_URL` and the Stripe webhook address.

**Updating the app later**: on GitHub, upload the new `velvet-crumb-order-app.zip` with the same name (Add file → Upload files) to replace the old one. Fly.io rebuilds and redeploys automatically. The `Dockerfile` at the top of the repository unpacks the zip during the build.

## Settings on the server (Fly.io → Secrets)

| Name | What it's for |
| --- | --- |
| `ADMIN_PASSWORD` | Admin sign-in. Changing it signs everyone out |
| `DATA_DIR` | Where the database and photos live (`/data`, set in `fly.toml`) |
| `BASE_URL` | The app's public address, used in Stripe and email links |
| `STRIPE_SECRET_KEY` | Jess's Stripe secret key. Blank = test mode |
| `STRIPE_WEBHOOK_SECRET` | Signing secret for the Stripe webhook |
| `RESEND_API_KEY`, `EMAIL_FROM` | Order emails (optional) |
| `SESSION_SECRET` | Optional. Signs admin sign-ins; the app makes and keeps its own if not set |

Everything Jess might change day to day is on the admin Settings tab instead.

## Still to do before launch

- Jess to read and adjust the draft privacy notice and terms (cancellation notice period, storage advice, retention periods)
- Allergens and costs for every item (see The starter menu)
- Real photos to replace the clip art
- Fly.io snapshots the volume daily and keeps 5 days by default. Download the CSVs (orders, costs, clients) now and then as an extra copy

## Files

```
fly.toml          Fly.io settings: London, one machine, 1 GB volume
Dockerfile        how Fly.io builds the app
src/server.js     routes and start-up
src/orders.js     menu, choices, placing orders, payment, order page
src/boxes.js      box flavour lists and box pricing
src/admin.js      admin: orders, menu, money, settings
src/clients.js    clients list, saved from paid orders
src/legal.js      draft privacy notice and terms, and the pages that show them
src/starter-menu.js  Jess's menu, loaded on first start
src/stripe.js     Stripe Checkout, webhooks, refunds, fees
src/email.js      confirmation and alert emails (Resend)
src/db.js         database tables, allergens list, default settings
public/           customer page, order page and admin page, logo (logo.svg) and icons
public/clipart/   clip-art pictures for the menu
test/             end-to-end tests
```

## Updating to box flavours

Upload the new zip to GitHub with the same name, velvet-crumb-order-app.zip. When the app restarts it converts the existing boxes once: the "Box type" choice and the typed flavours question are replaced by the flavour picker, keeping Jess's prices and any costs she has entered. Orders already placed are not changed.
