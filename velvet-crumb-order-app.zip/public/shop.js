// Velvet Crumb customer page: menu, choices, basket and checkout.
(() => {
  'use strict';

  // ---------- Helpers ----------
  const $ = (sel, root = document) => root.querySelector(sel);

  // Builds elements safely: text always goes in as text, never as HTML.
  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') el.className = value;
      else if (key === 'text') el.textContent = value;
      else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
      else if (key in el && typeof value !== 'string') el[key] = value;
      else el.setAttribute(key, value === true ? '' : value);
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false || child === '') continue;
      el.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return el;
  }

  const money = (p) => `£${(p / 100).toFixed(2)}`;
  const plus = (p) => (p ? `+${money(p)}` : '');
  const store = {
    get(key, fallback) {
      try {
        const v = JSON.parse(localStorage.getItem(key));
        return v ?? fallback;
      } catch {
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch {
        /* storage unavailable: basket lasts for this visit only */
      }
    },
  };

  async function api(path, options = {}) {
    const res = await fetch(path, {
      ...options,
      headers: options.body ? { 'Content-Type': 'application/json' } : undefined,
    });
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || 'Something went wrong. Please try again.');
    return body;
  }

  const isBlondie = (p) => /blondie/i.test(`${p.name} ${p.category}`) && !/brownie/i.test(p.name);
  const hasChoices = (p) => p.options.length > 0 || Boolean(p.note_label) || Boolean(p.box);
  const TIER_LABELS = { classic: 'All classic', mix: 'Mix of classic and loaded', loaded: 'All loaded' };

  // Works out a box from the flavours picked: tier, price and description.
  // Returns null if the picks don't fill the box (or no longer match the menu).
  function boxSummary(p, picks) {
    const bx = p.box;
    const counts = new Map();
    for (const f of picks?.flavours || []) {
      if (!bx.flavours.some((x) => x.name === f.name)) return null;
      counts.set(f.name, (counts.get(f.name) || 0) + f.qty);
    }
    const total = [...counts.values()].reduce((a, b) => a + b, 0);
    const kind = (n) => bx.flavours.find((x) => x.name === n).kind;
    const classic = [...counts].filter(([n, q]) => q > 0 && kind(n) === 'classic');
    const loaded = [...counts].filter(([n, q]) => q > 0 && kind(n) === 'loaded');
    const tier = !loaded.length ? 'classic' : !classic.length ? 'loaded' : 'mix';
    const needsBase = classic.length > 0 && bx.bases.length > 0;
    const list = (entries) => entries.map(([n, q]) => `${q} ${n}`).join(', ');
    const parts = [TIER_LABELS[tier]];
    if (classic.length) parts.push(`Classic${picks?.base ? ` (base: ${picks.base})` : ''}: ${list(classic)}`);
    if (loaded.length) parts.push(`Loaded: ${list(loaded)}`);
    return {
      total,
      full: total === bx.size,
      tier,
      price: bx.prices[tier],
      needsBase,
      baseOk: !needsBase || bx.bases.includes(picks?.base),
      text: parts.join('. '),
    };
  }

  function allergenText(p) {
    if (!p.allergens_set) return 'Allergens: ask Jess before ordering.';
    if (!p.allergens.length) return 'Contains none of the 14 main allergens.';
    return null;
  }

  function icon(name) {
    const paths = {
      plus: 'M12 5v14M5 12h14',
      minus: 'M5 12h14',
      bin: 'M5 7h14M10 11v6M14 11v6M7 7l1 12h8l1-12M9 7V4h6v3',
    };
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', '20');
    svg.setAttribute('height', '20');
    svg.setAttribute('aria-hidden', 'true');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', paths[name]);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', 'currentColor');
    path.setAttribute('stroke-width', '2.4');
    path.setAttribute('stroke-linecap', 'round');
    path.setAttribute('stroke-linejoin', 'round');
    svg.append(path);
    return svg;
  }

  function picture(p, cls = '') {
    return p.image
      ? h('img', { src: p.image, alt: p.name, loading: 'lazy', width: 600, height: 600, class: cls || undefined })
      : h('div', { class: `piece ${isBlondie(p) ? 'blondie' : ''} ${cls}`, role: 'img', 'aria-label': `${p.name} (photo coming soon)` });
  }

  // ---------- State ----------
  let shop = null;
  let products = new Map();
  // Each basket line: { id, qty, options: [{ group, choices: [] }], note }
  let basket = store.get('vc-basket-v2', []);
  if (!Array.isArray(basket)) basket = [];
  const saved = store.get('vc-details', {});
  const form = {
    method: '',
    date: '',
    name: saved.name || '',
    email: saved.email || '',
    phone: saved.phone || '',
    address: saved.address || '',
    postcode: saved.postcode || '',
    notes: '',
    allergensChecked: false,
    remember: Boolean(saved.name || saved.email),
  };
  const cardSlots = new Map();

  // ---------- Tray in the header ----------
  for (const [id, kind] of [['tray-brownie', ''], ['tray-blondie', 'blondie']]) {
    const half = document.getElementById(id);
    for (let i = 0; i < 20; i += 1) half.append(h('i', { class: `piece ${kind}` }));
  }

  // ---------- Basket ----------
  const lineKey = (l) => `${l.id}|${JSON.stringify(l.options || [])}|${l.note || ''}|${JSON.stringify(l.box || null)}`;

  function lineDetails(line) {
    const p = products.get(line.id);
    if (!p) return null;
    let extra = 0;
    const parts = [];
    for (const g of p.options) {
      const picked = (line.options || []).find((o) => o.group === g.name);
      const chosen = (picked?.choices || []).map((n) => g.choices.find((c) => c.name === n));
      if (chosen.some((c) => !c)) return null; // Jess changed the choices since
      if (g.required && !chosen.length) return null;
      chosen.forEach((c) => (extra += c.price_pence));
      if (chosen.length) parts.push(`${g.name}: ${chosen.map((c) => c.name).join(', ')}`);
    }
    if (p.note_required && !line.note) return null;
    if (p.box) {
      const b = boxSummary(p, line.box);
      if (!b || !b.full || !b.baseOk) return null;
      return { product: p, unit: b.price + extra, optionsText: [b.text, ...parts].join('. ') };
    }
    if (line.box) return null;
    return { product: p, unit: p.price_pence + extra, optionsText: parts.join('. ') };
  }

  function basketLines() {
    return basket
      .map((line) => ({ line, ...lineDetails(line) }))
      .filter((l) => l.product && l.product.status === 'on' && l.line.qty > 0);
  }
  const basketCount = () => basketLines().reduce((n, l) => n + l.line.qty, 0);
  const subtotal = () => basketLines().reduce((s, l) => s + l.line.qty * l.unit, 0);
  const countFor = (id) => basketLines().filter((l) => l.product.id === id).reduce((n, l) => n + l.line.qty, 0);

  function saveBasket() {
    basket = basket.filter((l) => l.qty > 0);
    store.set('vc-basket-v2', basket);
  }

  function addLine(newLine) {
    const key = lineKey(newLine);
    const existing = basket.find((l) => lineKey(l) === key);
    if (existing) existing.qty = Math.min(50, existing.qty + newLine.qty);
    else basket.push(newLine);
    afterBasketChange(newLine.id);
  }

  function setLineQty(line, qty) {
    line.qty = Math.max(0, Math.min(50, qty));
    if (!basket.includes(line)) basket.push(line);
    afterBasketChange(line.id);
  }

  function afterBasketChange(id) {
    saveBasket();
    refreshCard(id, true);
    refreshBar();
    if (!$('#checkout').hidden) {
      if (!basketLines().length) closeSheet('#checkout');
      else refreshCheckoutTotals();
    }
  }

  // The quick +/− for items with no choices to make.
  function simpleLine(p) {
    return basket.find((l) => l.id === p.id && !(l.options || []).length && !l.note) || { id: p.id, qty: 0, options: [], note: '' };
  }

  function stepper(line, name, { allowBin = false } = {}) {
    const qty = line.qty;
    return h('div', { class: `qty${qty ? ' has-qty' : ''}` },
      h('button', {
        type: 'button',
        'aria-label': qty === 1 ? `Remove ${name}` : `One fewer ${name}`,
        onclick: () => setLineQty(line, qty - 1),
      }, icon(qty === 1 && allowBin ? 'bin' : 'minus')),
      h('output', { 'aria-live': 'polite', 'aria-label': `${qty} ${name}`, text: qty }),
      h('button', { type: 'button', 'aria-label': `One more ${name}`, onclick: () => setLineQty(line, qty + 1) }, icon('plus')),
    );
  }

  function cardControl(p) {
    if (hasChoices(p)) {
      const count = countFor(p.id);
      return h('div', { class: `qty${count ? ' has-qty' : ''}` },
        count > 0 && h('span', { class: 'qty-count', text: `${count} in order` }),
        h('button', { type: 'button', 'aria-label': `Choose and add ${p.name}`, onclick: () => openPicker(p) }, icon('plus')),
      );
    }
    const line = simpleLine(p);
    if (!line.qty) {
      return h('div', { class: 'qty' },
        h('button', { type: 'button', 'aria-label': `Add one ${p.name}`, onclick: () => setLineQty(line, 1) }, icon('plus')),
      );
    }
    return stepper(line, p.name);
  }

  function refreshCard(id, bump = false) {
    const slot = cardSlots.get(id);
    const p = products.get(id);
    if (!slot || !p || p.status !== 'on') return;
    const control = cardControl(p);
    if (bump) control.classList.add('bump');
    slot.replaceChildren(control);
  }

  function refreshBar() {
    const count = basketCount();
    $('#basket-bar').hidden = !count || !shop?.open;
    $('#basket-count').textContent = count;
    $('#basket-count').setAttribute('aria-label', `${count} item${count === 1 ? '' : 's'}`);
    $('#basket-total').textContent = money(subtotal());
  }

  // ---------- Menu ----------
  function renderShop() {
    document.title = `${shop.name} | Order brownies and blondies`;
    $('#tagline').textContent = shop.tagline;
    $('#allergen-notice').textContent = shop.allergenNotice;

    const ways = [shop.collection.enabled && 'Collection', shop.delivery.enabled && 'local delivery'].filter(Boolean);
    const firstDate = (shop.dates || []).find((d) => !d.full);
    $('#next-date').textContent = !shop.open
      ? ''
      : firstDate
        ? `${ways.join(' or ')} from ${firstDate.label}.`
        : 'Order days are coming soon.';

    const contact = $('#contact');
    contact.replaceChildren();
    if (shop.contactPhone || shop.contactEmail) {
      contact.append(
        'Questions about an order? Message Jess',
        ...(shop.contactPhone ? [' on ', h('a', { href: `tel:${shop.contactPhone.replace(/\s+/g, '')}`, text: shop.contactPhone })] : []),
        ...(shop.contactEmail ? [shop.contactPhone ? ' or email ' : ' at ', h('a', { href: `mailto:${shop.contactEmail}`, text: shop.contactEmail })] : []),
        '.',
      );
    }
    const socials = $('#socials');
    socials.replaceChildren(
      ...[
        shop.instagram && h('a', { href: `https://www.instagram.com/${encodeURIComponent(shop.instagram)}/`, rel: 'noopener', text: `Instagram @${shop.instagram}` }),
        shop.instagram && shop.facebookUrl && ' and ',
        shop.facebookUrl && h('a', { href: shop.facebookUrl, rel: 'noopener', text: 'Facebook' }),
      ].filter(Boolean),
    );

    const menu = $('#menu');
    menu.replaceChildren();
    cardSlots.clear();

    if (!shop.open) menu.append(h('p', { class: 'menu-status', text: shop.closedMessage }));

    if (shop.notices?.length) {
      menu.append(h('div', { class: 'notices' },
        shop.notices.map((n) => h('section', { class: 'notice-card' },
          n.title && h('h2', { text: n.title }),
          n.text && h('p', { text: n.text }),
        )),
      ));
    }

    const visible = [...products.values()];
    if (!visible.length) {
      menu.append(h('p', { class: 'menu-status', text: 'The menu is being updated. Check back soon.' }));
      $('#cats').hidden = true;
      return;
    }

    const groups = new Map();
    for (const p of visible) {
      const key = p.category || 'Bakes';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(p);
    }

    const cats = $('#cats');
    cats.replaceChildren();
    cats.hidden = groups.size < 2;

    let index = 0;
    for (const [name, items] of groups) {
      const id = `section-${index++}`;
      cats.append(h('a', { href: `#${id}`, text: name }));
      menu.append(
        h('section', { class: 'menu-section', 'aria-labelledby': id },
          h('h2', { id, text: name }),
          h('div', { class: 'grid' }, items.map(card)),
        ),
      );
    }
    watchSections();
  }

  function card(p) {
    const soldOut = p.status === 'soldout';
    const soon = p.status === 'soon';
    const photo = h('div', { class: 'item-photo' }, picture(p));
    if (soldOut) {
      photo.append(h('span', { class: 'soldout-tag', text: 'Sold out' }));
    } else if (soon) {
      photo.append(h('span', { class: 'soldout-tag', text: p.badge || 'Coming soon' }));
    } else {
      if (p.badge) photo.append(h('span', { class: 'badge-tag', text: p.badge }));
      if (shop.open) {
        const slot = h('div');
        cardSlots.set(p.id, slot);
        slot.append(cardControl(p));
        photo.append(slot);
      }
    }
    const fromPrice = Boolean(p.box) || p.options.some((g) => g.choices.some((c) => c.price_pence > 0));
    const warning = allergenText(p);
    return h('article', { class: `item${soldOut ? ' is-soldout' : ''}${soon ? ' is-soon' : ''}` },
      photo,
      h('h3', { class: 'item-name', text: p.name }),
      h('p', { class: 'item-price' },
        `${fromPrice ? 'From ' : ''}${money(p.box ? Math.min(...Object.values(p.box.prices)) : p.price_pence)}`,
        p.was_price_pence > 0 && h('s', { class: 'was', text: money(p.was_price_pence) }),
        p.was_price_pence > 0 && h('span', { class: 'visually-hidden', text: ` (was ${money(p.was_price_pence)})` }),
      ),
      p.description && h('p', { class: 'item-desc', text: p.description }),
      h('p', { class: 'item-allergens' }, warning || [h('strong', { text: 'Contains: ' }), p.allergens.join(', ')]),
    );
  }

  let observer;
  function watchSections() {
    observer?.disconnect();
    const links = [...document.querySelectorAll('#cats a')];
    if (!links.length || !('IntersectionObserver' in window)) return;
    observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          const id = e.target.getAttribute('aria-labelledby');
          links.forEach((a) => a.setAttribute('aria-current', String(a.hash === `#${id}`)));
          const active = links.find((a) => a.hash === `#${id}`);
          if (active) active.parentElement.scrollTo({ left: active.offsetLeft - 20, behavior: 'smooth' });
        }
      },
      { rootMargin: '-30% 0px -60% 0px' },
    );
    document.querySelectorAll('.menu-section').forEach((s) => observer.observe(s));
  }

  // ---------- Sheets ----------
  let lastFocus = null;
  function openSheet(sel, titleSel) {
    lastFocus = document.activeElement;
    for (const el of document.querySelectorAll('body > :not(.sheet):not(.sheet-backdrop)')) el.inert = true;
    $('#sheet-backdrop').hidden = false;
    $(sel).hidden = false;
    document.body.style.overflow = 'hidden';
    const title = $(titleSel);
    title.setAttribute('tabindex', '-1');
    title.focus();
  }
  function closeSheet(sel) {
    $(sel).hidden = true;
    if (!document.querySelector('.sheet:not([hidden])')) {
      for (const el of document.querySelectorAll('[inert]')) el.inert = false;
      $('#sheet-backdrop').hidden = true;
      document.body.style.overflow = '';
      lastFocus?.focus?.();
    }
  }

  // ---------- Choices picker ----------
  function openPicker(p) {
    const f = $('#picker-form');
    f.replaceChildren();
    $('#picker-title').textContent = p.name;
    const picked = new Map(p.options.map((g) => [g.name, []]));
    let qty = 1;
    let note = '';

    const warning = allergenText(p);
    f.append(h('div', { class: 'picker-intro' },
      picture(p),
      h('div', {},
        p.description && h('p', { text: p.description }),
        h('p', { class: 'item-allergens' }, warning || [h('strong', { text: 'Contains: ' }), p.allergens.join(', ')]),
      ),
    ));

    // Boxes: fill with flavours using + and −
    const boxCounts = new Map();
    let boxBase = '';
    let refreshBox = () => {};
    const boxPicks = () => ({ flavours: [...boxCounts].filter(([, q]) => q > 0).map(([name, q]) => ({ name, qty: q })), base: boxBase });
    if (p.box) {
      const bx = p.box;
      const total = () => [...boxCounts.values()].reduce((a, b) => a + b, 0);
      const rows = [];
      const section = (kind, title, hint) => {
        const list = bx.flavours.filter((x) => x.kind === kind);
        if (!list.length) return null;
        return h('fieldset', { class: 'picker-group' },
          h('legend', {}, h('span', { text: title }), h('small', { text: hint })),
          h('div', { class: 'flavour-list' }, list.map((fl) => {
            const out = h('output', { 'aria-live': 'polite', text: '0' });
            const minus = h('button', { type: 'button', 'aria-label': `One fewer ${fl.name}`, onclick: () => change(fl.name, -1) }, icon('minus'));
            const plusB = h('button', { type: 'button', 'aria-label': `Add ${fl.name}`, onclick: () => change(fl.name, 1) }, icon('plus'));
            const row = h('div', { class: 'flavour-row' }, h('span', { text: fl.name }), h('div', { class: 'qty' }, minus, out, plusB));
            rows.push({ name: fl.name, out, minus, plusB, row });
            return row;
          })),
        );
      };
      const change = (name, d) => {
        const n = Math.max(0, (boxCounts.get(name) || 0) + d);
        if (d > 0 && total() >= bx.size) return;
        boxCounts.set(name, n);
        refreshBox();
      };
      const baseGroup = bx.bases.length
        ? h('fieldset', { class: 'picker-group', hidden: true },
          h('legend', {}, h('span', { text: 'Base for your classic bakes' }), h('small', { text: 'Pick one' })),
          h('div', { class: 'picker-choices' }, bx.bases.map((b) => h('label', { class: 'pick' },
            h('input', { type: 'radio', name: 'box-base', value: b, onchange: () => { boxBase = b; refreshBox(); } }),
            h('span', { text: b }),
          ))),
        )
        : null;
      f.append(
        h('p', { class: 'box-intro', text: `Fill your box with ${bx.size} bakes. ${money(bx.prices.classic)} all classic, ${money(bx.prices.mix)} for a mix, ${money(bx.prices.loaded)} all loaded.` }),
        section('classic', 'Classic', 'On a base of your choice'),
        baseGroup,
        section('loaded', 'Loaded', 'Filled and topped'),
      );
      refreshBox = () => {
        const t = total();
        const classicCount = rows.filter((r) => bx.flavours.find((x) => x.name === r.name).kind === 'classic').reduce((a, r) => a + (boxCounts.get(r.name) || 0), 0);
        for (const r of rows) {
          const q = boxCounts.get(r.name) || 0;
          r.out.textContent = q;
          r.minus.disabled = q === 0;
          r.plusB.disabled = t >= bx.size;
          r.row.classList.toggle('has', q > 0);
        }
        if (baseGroup) baseGroup.hidden = classicCount === 0;
        refreshPickerTotal();
      };
    }

    for (const g of p.options) {
      const max = g.type === 'one' ? 1 : g.max || g.choices.length;
      const hint = g.type === 'one' ? (g.required ? 'Pick one' : 'Optional') : `Pick up to ${max}${g.required ? '' : ', optional'}`;
      const box = h('div', { class: 'picker-choices' });
      const inputs = [];
      g.choices.forEach((c) => {
        const input = h('input', { type: g.type === 'one' ? 'radio' : 'checkbox', name: `g-${g.name}`, value: c.name });
        input.addEventListener('change', () => {
          if (g.type === 'one') picked.set(g.name, [c.name]);
          else picked.set(g.name, inputs.filter((i) => i.checked).map((i) => i.value));
          if (g.type === 'many') {
            const full = picked.get(g.name).length >= max;
            inputs.forEach((i) => (i.disabled = full && !i.checked));
          }
          refreshPickerTotal();
        });
        inputs.push(input);
        box.append(h('label', { class: 'pick' }, input, h('span', { text: c.name }), c.price_pence > 0 && h('span', { class: 'extra', text: plus(c.price_pence) })));
      });
      f.append(h('fieldset', { class: 'picker-group' }, h('legend', {}, h('span', { text: g.name }), h('small', { text: hint })), box));
    }

    if (p.note_label) {
      const area = h('textarea', { id: 'picker-note', rows: 3, maxlength: 300 });
      area.addEventListener('input', () => (note = area.value));
      f.append(h('div', { class: 'field' },
        h('label', { for: 'picker-note', text: `${p.note_label}${p.note_required ? '' : ' (optional)'}` }),
        area,
      ));
    }

    const qtyOut = h('output', { 'aria-live': 'polite', text: qty });
    const setQty = (n) => {
      qty = Math.max(1, Math.min(50, n));
      qtyOut.textContent = qty;
      refreshPickerTotal();
    };
    f.append(h('div', { class: 'picker-qty' },
      h('span', { text: 'How many' }),
      h('div', { class: 'qty has-qty' },
        h('button', { type: 'button', 'aria-label': 'One fewer', onclick: () => setQty(qty - 1) }, icon('minus')),
        qtyOut,
        h('button', { type: 'button', 'aria-label': 'One more', onclick: () => setQty(qty + 1) }, icon('plus')),
      ),
    ));

    const error = h('p', { class: 'form-error', role: 'alert' });
    const addButton = h('button', { type: 'submit', class: 'btn' });
    const boxStatus = p.box ? h('p', { class: 'box-status', 'aria-live': 'polite' }) : null;
    f.append(h('div', { class: 'sheet-foot' }, boxStatus, error, addButton));

    function unitPrice() {
      let extra = 0;
      for (const g of p.options) {
        for (const n of picked.get(g.name)) extra += g.choices.find((c) => c.name === n)?.price_pence || 0;
      }
      if (p.box) {
        const b = boxSummary(p, boxPicks());
        return (b && b.total ? b.price : p.box.prices.classic) + extra;
      }
      return p.price_pence + extra;
    }
    function refreshPickerTotal() {
      if (boxStatus) {
        const b = boxSummary(p, boxPicks());
        boxStatus.textContent = `${b.total} of ${p.box.size} bakes chosen${b.total ? `. ${TIER_LABELS[b.tier]}, ${money(b.price)} a box` : ''}`;
        boxStatus.classList.toggle('is-full', b.full);
      }
      addButton.textContent = `Add to order ${money(unitPrice() * qty)}`;
    }
    refreshPickerTotal();

    f.onsubmit = (e) => {
      e.preventDefault();
      error.textContent = '';
      for (const g of p.options) {
        if (g.required && !picked.get(g.name).length) {
          error.textContent = `Choose the ${g.name.toLowerCase()}.`;
          return;
        }
      }
      if (p.box) {
        const b = boxSummary(p, boxPicks());
        if (!b.full) {
          error.textContent = `Choose ${p.box.size} bakes for your box. You've chosen ${b.total}.`;
          return;
        }
        if (!b.baseOk) {
          error.textContent = 'Choose the base for your classic bakes.';
          return;
        }
      }
      if (p.note_required && !note.trim()) {
        error.textContent = `Fill in: ${p.note_label}`;
        $('#picker-note')?.focus();
        return;
      }
      const picks = p.box ? boxPicks() : undefined;
      if (picks && !boxSummary(p, picks).needsBase) picks.base = '';
      addLine({
        id: p.id,
        qty,
        options: p.options.filter((g) => picked.get(g.name).length).map((g) => ({ group: g.name, choices: picked.get(g.name) })),
        note: note.trim(),
        box: picks,
      });
      closeSheet('#picker');
    };

    refreshBox();
    openSheet('#picker', '#picker-title');
  }

  // ---------- Checkout ----------
  const datesFor = (method) => (shop.dates || []).filter((d) => (method === 'delivery' ? d.deliver : method === 'collection' ? d.collect : d.collect || d.deliver));

  function openCheckout() {
    if (!basketLines().length) return;
    const methods = [shop.collection.enabled && 'collection', shop.delivery.enabled && 'delivery'].filter(Boolean);
    if (!methods.includes(form.method)) form.method = methods.length === 1 ? methods[0] : '';
    if (form.date && !datesFor(form.method).some((d) => d.date === form.date && !d.full)) form.date = '';
    buildCheckout();
    openSheet('#checkout', '#checkout-title');
  }

  function step(n, title, ...content) {
    return h('section', { class: 'step', 'aria-labelledby': `step-${n}` },
      h('h3', { id: `step-${n}` }, h('span', { class: 'n', 'aria-hidden': 'true', text: n }), title),
      ...content,
    );
  }

  function field(label, input, hint) {
    return h('div', { class: 'field' },
      h('label', { for: input.id, text: label }),
      hint && h('p', { class: 'hint', text: hint }),
      input,
    );
  }

  function bind(input, key) {
    input.value = form[key] || '';
    input.addEventListener('input', () => {
      form[key] = input.value;
    });
    return input;
  }

  function buildCheckout() {
    const f = $('#checkout-form');
    f.replaceChildren();

    if (shop.testMode) {
      f.append(h('p', { class: 'notice notice-warn', text: 'Test mode: card payments are not switched on yet, so no money is taken.' }));
    }

    f.append(step(1, 'Your order', h('ul', { class: 'lines', id: 'lines' })));

    const methods = [shop.collection.enabled && 'collection', shop.delivery.enabled && 'delivery'].filter(Boolean);
    const choices = h('div', { class: 'choices', role: 'radiogroup', 'aria-labelledby': 'step-2' });
    const addChoice = (value, title, price, note) => {
      const input = h('input', {
        type: 'radio',
        name: 'method',
        value,
        checked: form.method === value,
        onchange: () => {
          form.method = value;
          $('#delivery-fields').hidden = value !== 'delivery';
          if (form.date && !datesFor(value).some((d) => d.date === form.date)) form.date = '';
          renderDates();
          refreshCheckoutTotals();
        },
      });
      choices.append(h('label', { class: 'choice' },
        input,
        h('span', { class: 'choice-title', text: title }),
        h('span', { class: 'choice-price', text: price }),
        note && h('span', { class: 'choice-note', text: note }),
      ));
    };
    if (methods.includes('collection')) addChoice('collection', 'Collect', 'Free', shop.collection.area);
    if (methods.includes('delivery')) {
      const { fee, freeOver, note } = shop.delivery;
      const extra = freeOver > 0 ? ` Free on orders over ${money(freeOver)}.` : '';
      addChoice('delivery', 'Local delivery', fee ? money(fee) : 'Free', `${note || ''}${extra}`.trim());
    }
    const deliveryFields = h('div', { class: 'step-fields', id: 'delivery-fields', hidden: form.method !== 'delivery', style: 'margin-top:0.9rem' },
      field('Delivery address', bind(h('textarea', { id: 'address', autocomplete: 'street-address', rows: 2 }), 'address')),
      field('Postcode', bind(h('input', { id: 'postcode', autocomplete: 'postal-code', autocapitalize: 'characters' }), 'postcode'),
        shop.delivery.postcodes ? `We deliver to ${shop.delivery.postcodes}.` : ''),
    );
    f.append(step(2, 'Collect or delivery',
      methods.length
        ? [choices, deliveryFields]
        : h('p', { class: 'notice notice-warn', text: 'Jess hasn’t opened any collection or delivery days yet. Check back soon.' }),
    ));

    f.append(step(3, 'Choose a day', h('div', { id: 'dates-slot' }), h('p', { class: 'date-picked', id: 'date-hint', 'aria-live': 'polite' })));

    f.append(step(4, 'Your details', h('div', { class: 'step-fields' },
      field('Name', bind(h('input', { id: 'name', autocomplete: 'name' }), 'name')),
      field('Email', bind(h('input', { id: 'email', type: 'email', autocomplete: 'email', inputmode: 'email' }), 'email'), 'Your confirmation and receipt go here.'),
      field('Mobile', bind(h('input', { id: 'phone', type: 'tel', autocomplete: 'tel', inputmode: 'tel' }), 'phone'), 'So Jess can reach you about your order.'),
      field('Notes for Jess (optional)', bind(h('textarea', { id: 'notes', rows: 2, maxlength: 500 }), 'notes'), 'A gift message, a birthday, anything she should know.'),
    )));

    const allergyBox = h('input', {
      type: 'checkbox',
      id: 'allergens-checked',
      checked: form.allergensChecked,
      onchange: (e) => (form.allergensChecked = e.target.checked),
    });
    const rememberBox = h('input', {
      type: 'checkbox',
      id: 'remember-me',
      checked: form.remember,
      onchange: (e) => (form.remember = e.target.checked),
    });
    f.append(h('section', { class: 'step-fields' },
      h('p', { class: 'notice notice-warn', text: shop.allergenNotice }),
      h('label', { class: 'check', for: 'allergens-checked' }, allergyBox, h('span', { text: 'I have checked the allergens for everything in my order.' })),
      h('label', { class: 'check', for: 'remember-me' }, rememberBox, h('span', { text: 'Remember my details on this device for next time' })),
    ));

    f.append(h('div', { class: 'sheet-foot' },
      h('div', { class: 'sums', id: 'sums' }),
      h('p', { class: 'form-error', id: 'form-error', role: 'alert' }),
      h('button', { type: 'submit', class: 'btn', id: 'pay' }),
      h('p', { class: 'checkout-legal' },
        'By paying you agree to our ', h('a', { href: '/terms', target: '_blank', rel: 'noopener', text: 'terms of sale' }),
        '. Our ', h('a', { href: '/privacy', target: '_blank', rel: 'noopener', text: 'privacy notice' }), ' explains how we use your details.',
      ),
    ));

    renderDates();
    refreshCheckoutTotals();
  }

  function renderDates() {
    const slot = $('#dates-slot');
    if (!slot) return;
    if (!form.method) {
      slot.replaceChildren(h('p', { class: 'hint', style: 'color:var(--cocoa)', text: 'Choose collect or delivery first to see the days.' }));
      renderDateHint();
      return;
    }
    const dates = datesFor(form.method);
    if (!dates.length) {
      slot.replaceChildren(h('p', { class: 'notice notice-warn', text: 'There are no days open for this right now. Check back soon.' }));
      renderDateHint();
      return;
    }
    const chips = h('div', { class: 'dates', role: 'group', 'aria-labelledby': 'step-3' });
    for (const d of dates) {
      const dt = new Date(`${d.date}T00:00:00Z`);
      const part = (o) => dt.toLocaleDateString('en-GB', { ...o, timeZone: 'UTC' });
      chips.append(h('button', {
        type: 'button',
        class: 'date-chip',
        disabled: d.full,
        'aria-pressed': String(form.date === d.date),
        'aria-label': d.full ? `${d.label}, fully booked` : d.label,
        onclick: (e) => {
          form.date = d.date;
          chips.querySelectorAll('.date-chip').forEach((c) => c.setAttribute('aria-pressed', String(c === e.currentTarget)));
          renderDateHint();
        },
      },
      h('span', { class: 'dow', text: part({ weekday: 'short' }) }),
      h('span', { class: 'day', text: part({ day: 'numeric' }) }),
      h('span', { class: 'mon', text: part({ month: 'short' }) }),
      ));
    }
    slot.replaceChildren(chips);
    renderDateHint();
  }

  function renderDateHint() {
    const hint = $('#date-hint');
    if (!hint) return;
    const d = (shop.dates || []).find((x) => x.date === form.date);
    if (!d || !form.method) {
      hint.textContent = '';
      return;
    }
    const slot = form.method === 'collection' ? d.collect : d.deliver;
    hint.textContent = form.method === 'collection'
      ? `Collect on ${d.label}${slot?.label ? `, ${slot.label}` : ''}.`
      : `Delivery on ${d.label}${slot?.label ? `, ${slot.label}` : ''}. Jess will message you with a time.`;
  }

  function deliveryFee() {
    if (form.method !== 'delivery') return 0;
    const { fee, freeOver } = shop.delivery;
    return freeOver > 0 && subtotal() >= freeOver ? 0 : fee;
  }

  function refreshCheckoutTotals() {
    const list = $('#lines');
    if (!list) return;
    list.replaceChildren(
      ...basketLines().map(({ line, product, unit, optionsText }) =>
        h('li', { class: 'line' },
          h('span', { class: 'line-name', text: product.name }),
          h('span', { class: 'line-total', text: money(unit * line.qty) }),
          (optionsText || line.note) && h('span', { class: 'line-options' },
            optionsText,
            optionsText && line.note && h('br'),
            line.note && `Note: ${line.note}`,
          ),
          stepper(line, product.name, { allowBin: true }),
          h('span', { class: 'line-allergens', text: allergenText(product) || `Contains: ${product.allergens.join(', ')}` }),
        ),
      ),
    );
    const sub = subtotal();
    const fee = deliveryFee();
    $('#sums').replaceChildren(
      ...[
        h('span', { text: 'Bakes' }), h('span', { text: money(sub) }),
        form.method === 'delivery' && h('span', { text: 'Delivery' }),
        form.method === 'delivery' && h('span', { text: fee ? money(fee) : 'Free' }),
        h('span', { class: 'total', text: 'Total' }), h('span', { class: 'total', text: money(sub + fee) }),
      ].filter(Boolean),
    );
    $('#form-error').textContent = shop.minOrder && sub < shop.minOrder ? `The minimum order is ${money(shop.minOrder)}.` : '';
    $('#pay').textContent = `Pay ${money(sub + fee)}`;
  }

  function validate() {
    if (!basketLines().length) return ['Your basket is empty.'];
    if (shop.minOrder && subtotal() < shop.minOrder) return [`The minimum order is ${money(shop.minOrder)}.`];
    if (!form.method) return ['Choose collection or delivery.', '#step-2'];
    if (form.method === 'delivery') {
      if (form.address.trim().length < 5) return ['Enter the delivery address.', '#address'];
      if (!/^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i.test(form.postcode.trim())) return ['Enter a full UK postcode.', '#postcode'];
    }
    if (!form.date) return ['Choose a day.', '#step-3'];
    if (form.name.trim().length < 2) return ['Enter your name.', '#name'];
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) return ['Enter a valid email address.', '#email'];
    if (form.phone.replace(/\D/g, '').length < 10) return ['Enter your mobile number.', '#phone'];
    if (!form.allergensChecked) return ['Tick the box to confirm you have checked the allergens.', '#allergens-checked'];
    return null;
  }

  async function submit(e) {
    e.preventDefault();
    const error = $('#form-error');
    error.textContent = '';
    const problem = validate();
    if (problem) {
      error.textContent = problem[0];
      if (problem[1]) {
        const target = $(problem[1]);
        target?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        if (target?.matches('input, textarea')) target.focus({ preventScroll: true });
      }
      return;
    }
    const pay = $('#pay');
    pay.disabled = true;
    pay.textContent = shop.testMode ? 'Placing your order…' : 'Taking you to payment…';
    if (form.remember) {
      store.set('vc-details', { name: form.name, email: form.email, phone: form.phone, address: form.address, postcode: form.postcode });
    } else {
      try {
        localStorage.removeItem('vc-details');
      } catch {
        /* nothing saved */
      }
    }
    try {
      const result = await api('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          items: basketLines().map(({ line }) => ({ id: line.id, qty: line.qty, options: line.options, note: line.note, box: line.box })),
          method: form.method,
          date: form.date,
          name: form.name,
          email: form.email,
          phone: form.phone,
          address: form.address,
          postcode: form.postcode,
          notes: form.notes,
          allergensChecked: form.allergensChecked,
        }),
      });
      window.location.href = result.url;
    } catch (err) {
      error.textContent = err.message;
      pay.disabled = false;
      load().then(() => refreshCheckoutTotals()).catch(() => {});
    }
  }

  // ---------- Start ----------
  async function load() {
    const data = await api('/api/shop');
    shop = { ...data.shop, testMode: data.testMode, dates: data.dates };
    products = new Map(data.products.map((p) => [p.id, p]));
    // Drop anything no longer on sale, or whose choices have changed.
    basket = basket.filter((l) => l && l.qty > 0 && lineDetails(l) && products.get(l.id)?.status === 'on');
    saveBasket();
    renderShop();
    refreshBar();
  }

  $('#open-checkout').addEventListener('click', openCheckout);
  $('#close-checkout').addEventListener('click', () => closeSheet('#checkout'));
  $('#close-picker').addEventListener('click', () => closeSheet('#picker'));
  $('#sheet-backdrop').addEventListener('click', () => document.querySelectorAll('.sheet:not([hidden])').forEach((s) => closeSheet(`#${s.id}`)));
  $('#checkout-form').addEventListener('submit', submit);
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const open = document.querySelector('.sheet:not([hidden])');
    if (open) closeSheet(`#${open.id}`);
  });

  load()
    .then(() => {
      if (new URLSearchParams(location.search).has('basket') && basketLines().length) {
        history.replaceState(null, '', '/');
        openCheckout();
      }
    })
    .catch((err) => {
      $('#menu').replaceChildren(h('p', { class: 'menu-status', text: `The menu could not load. ${err.message}` }));
    });
})();
