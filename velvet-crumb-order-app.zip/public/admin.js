// Velvet Crumb admin: orders, menu, money and settings.
(() => {
  'use strict';

  // ---------- Helpers ----------
  const $ = (sel, root = document) => root.querySelector(sel);

  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') el.className = value;
      else if (key === 'text') el.textContent = value;
      else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
      else if (key in el && typeof value !== 'string') el[key] = value;
      else el.setAttribute(key, value === true ? '' : value);
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false) continue;
      el.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return el;
  }

  const money = (p) => `${p < 0 ? '−' : ''}£${(Math.abs(p) / 100).toFixed(2)}`;
  const pounds = (p) => (p / 100).toFixed(2);
  const toPence = (v) => {
    const n = parseFloat(String(v).replace(/[£,\s]/g, ''));
    return Number.isFinite(n) ? Math.round(n * 100) : NaN;
  };
  const ukToday = () =>
    new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  const addDays = (iso, n) => {
    const d = new Date(`${iso}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  };
  const niceDate = (iso, opts = { day: 'numeric', month: 'short', year: 'numeric' }) =>
    new Date(`${iso}T00:00:00Z`).toLocaleDateString('en-GB', { ...opts, timeZone: 'UTC' });
  const monthName = (ym) => niceDate(`${ym}-01`, { month: 'long', year: 'numeric' });

  async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch(path, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && !path.endsWith('/login')) {
      showLogin();
      throw new Error(data.error || 'Sign in again to carry on.');
    }
    if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
    return data;
  }

  let toastTimer;
  function toast(message, isError = false) {
    const t = $('#toast');
    t.textContent = message;
    t.classList.toggle('is-error', isError);
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), isError ? 6000 : 3000);
  }

  const view = $('#view');
  const viewHead = (title, ...extra) => h('div', { class: 'view-head' }, h('h2', { text: title }), ...extra);
  const loading = () => h('p', { class: 'empty', text: 'Loading…' });

  const field = (label, input, hint) =>
    h('div', { class: 'field' },
      h('label', { for: input.id, text: label }),
      hint && h('p', { class: 'hint', text: hint }),
      input,
    );

  // ---------- State ----------
  const state = {
    meta: { stripe: false, email: false },
    settings: null,
    allergens: [],
    expenseCategories: [],
    ordersView: 'upcoming',
    period: 'this-month',
    customFrom: addDays(ukToday(), -30),
    customTo: ukToday(),
    panelOpen: false,
  };

  // ---------- Sign in ----------
  function showLogin(message) {
    $('#app').hidden = true;
    $('#login').hidden = false;
    $('#login-error').textContent = message || '';
    $('#password').focus();
  }

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#login-error').textContent = '';
    try {
      await api('/api/admin/login', { method: 'POST', body: { password: $('#password').value } });
      $('#password').value = '';
      start();
    } catch (err) {
      $('#login-error').textContent = err.message;
    }
  });

  $('#sign-out').addEventListener('click', async () => {
    await api('/api/admin/logout', { method: 'POST', body: {} }).catch(() => {});
    showLogin();
  });

  async function start() {
    $('#login').hidden = true;
    $('#app').hidden = false;
    await loadSettings();
    await refreshOverview();
    route();
  }

  async function loadSettings() {
    const data = await api('/api/admin/settings');
    state.settings = data.settings;
    state.allergens = data.allergens;
    state.expenseCategories = data.expenseCategories;
    state.meta = data.status;
    state.legalDefaults = data.legalDefaults;
    const banner = $('#mode-banner');
    banner.hidden = state.meta.stripe;
    banner.textContent = 'Test mode: Stripe is not connected yet, so customers are not charged.';
  }

  async function refreshOverview() {
    try {
      const { counts } = await api('/api/admin/overview');
      const badge = $('#orders-badge');
      badge.hidden = !counts.toBake;
      badge.textContent = counts.toBake;
      badge.setAttribute('aria-label', `${counts.toBake} to bake`);
      state.scheduleSet = counts.scheduleSet;
    } catch {
      /* shown on next action */
    }
  }

  // ---------- Tabs ----------
  const tabs = { orders: renderOrders, clients: renderClients, menu: renderMenu, money: renderMoney, settings: renderSettings };
  function route() {
    const tab = location.hash.slice(1) in tabs ? location.hash.slice(1) : 'orders';
    if (state.panelOpen) state.closePanel?.();
    document.querySelectorAll('.tabs a').forEach((a) => {
      if (a.dataset.tab === tab) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
    view.replaceChildren(loading());
    tabs[tab]().catch((err) => {
      view.replaceChildren(h('p', { class: 'notice notice-bad', text: err.message }));
    });
  }
  window.addEventListener('hashchange', route);

  // ---------- Orders ----------
  const STATUS = {
    paid: 'To bake',
    ready: 'Ready',
    completed: 'Done',
    refunded: 'Refunded',
    cancelled: 'Cancelled',
    expired: 'Not paid',
    pending: 'At payment',
  };

  async function renderOrders() {
    const segments = h('div', { class: 'segments', role: 'group', 'aria-label': 'Which orders' });
    for (const [key, label] of [['upcoming', 'Coming up'], ['past', 'Done'], ['cancelled', 'Cancelled'], ['unpaid', 'Not paid']]) {
      segments.append(h('button', {
        type: 'button',
        'aria-pressed': String(state.ordersView === key),
        text: label,
        onclick: () => {
          state.ordersView = key;
          route();
        },
      }));
    }
    const list = h('div', {}, loading());
    const banner = state.scheduleSet === false && h('p', { class: 'notice notice-warn setup-banner' },
      'Customers can’t choose a day yet. ', h('a', { href: '#settings', text: 'Set your opening days and times in Settings' }), '.');
    view.replaceChildren(...[viewHead('Orders'), banner, segments, list].filter(Boolean));

    const [{ orders }, bake] = await Promise.all([
      api(`/api/admin/orders?view=${state.ordersView}`),
      state.ordersView === 'upcoming' ? api('/api/admin/bake-list') : Promise.resolve({ rows: [] }),
    ]);

    if (!orders.length) {
      const empty = {
        upcoming: 'No orders coming up yet. New paid orders appear here.',
        past: 'Finished orders appear here once you mark them collected or delivered.',
        cancelled: 'No cancelled orders.',
        unpaid: 'Nobody has left an order at the payment page.',
      };
      list.replaceChildren(h('div', { class: 'empty' }, h('p', { text: empty[state.ordersView] })));
      return;
    }

    const byDate = new Map();
    for (const o of orders) {
      if (!byDate.has(o.date)) byDate.set(o.date, []);
      byDate.get(o.date).push(o);
    }
    list.replaceChildren();
    for (const [date, dayOrders] of byDate) {
      const label = dayOrders[0].dateLabel + (date === ukToday() ? ' (today)' : '');
      const toBake = bake.rows.filter((r) => r.date === date);
      const total = toBake.reduce((n, r) => n + r.qty, 0);
      list.append(h('section', { class: 'day' },
        h('div', { class: 'day-head' },
          h('h3', { text: label }),
          h('span', { text: `${dayOrders.length} order${dayOrders.length === 1 ? '' : 's'}` }),
        ),
        total > 0 && h('details', { class: 'bake' },
          h('summary', { text: `To bake: ${total} item${total === 1 ? '' : 's'}` }),
          h('ul', {}, toBake.map((r) => h('li', { text: `${r.qty} × ${r.name}${r.options ? ` (${r.options})` : ''}` }))),
        ),
        h('div', { class: 'orders' }, dayOrders.map(orderCard)),
      ));
    }
  }

  function orderCard(o) {
    const done = o.method === 'collection' ? 'Mark collected' : 'Mark delivered';
    const statusLabel = o.status === 'completed' ? (o.method === 'collection' ? 'Collected' : 'Delivered') : STATUS[o.status];
    const when = o.time_window ? `, ${o.time_window}` : '';
    const where = o.method === 'delivery' ? `Delivery${when} to ${o.address}, ${o.postcode}` : `Collection${when}`;
    const phone = o.phone.replace(/[^\d+]/g, '');

    const actions = [];
    const move = (status, label, quiet) =>
      h('button', {
        type: 'button',
        class: `btn btn-small${quiet ? ' btn-quiet' : ''}`,
        text: label,
        onclick: async (e) => {
          e.currentTarget.disabled = true;
          try {
            await api(`/api/admin/orders/${o.id}/status`, { method: 'POST', body: { status } });
            toast(`${o.ref}: ${label.replace('Mark ', 'marked ').replace('Undo', 'undone')}`);
            refreshOverview();
            route();
          } catch (err) {
            toast(err.message, true);
            route();
          }
        },
      });
    const cancel = () =>
      h('button', {
        type: 'button',
        class: 'btn btn-small btn-danger',
        text: o.payment_method === 'stripe' ? 'Cancel and refund' : 'Cancel',
        onclick: async (e) => {
          const ok = window.confirm(
            o.payment_method === 'stripe'
              ? `Cancel ${o.ref} and refund ${money(o.total_pence)} to ${o.name}'s card? This cannot be undone.`
              : `Cancel ${o.ref}?`,
          );
          if (!ok) return;
          e.currentTarget.disabled = true;
          try {
            await api(`/api/admin/orders/${o.id}/cancel`, { method: 'POST', body: {} });
            toast(o.payment_method === 'stripe' ? `${o.ref} refunded` : `${o.ref} cancelled`);
            refreshOverview();
            route();
          } catch (err) {
            toast(err.message, true);
            route();
          }
        },
      });

    if (o.status === 'paid') actions.push(move('ready', 'Mark ready'), move('completed', done, true), cancel());
    if (o.status === 'ready') actions.push(move('completed', done), move('paid', 'Undo', true), cancel());
    if (o.status === 'completed') actions.push(move('ready', 'Undo', true));
    if (o.status === 'pending' || o.status === 'expired') actions.push(cancel());

    return h('article', { class: 'order', 'data-status': o.status },
      h('div', { class: 'order-top' },
        h('div', {},
          o.client_id
            ? h('button', { type: 'button', class: 'order-name link-button', text: o.name, onclick: () => openClient(o.client_id) })
            : h('p', { class: 'order-name', text: o.name }),
          h('p', { class: 'order-meta', text: `${o.ref}. ${where}` }),
        ),
        h('span', { class: `pill pill-${o.status}`, text: statusLabel }),
      ),
      h('ul', { class: 'order-items' }, o.items.map((i) => h('li', {},
        `${i.qty} × ${i.name}`,
        (i.options || i.note) && h('span', { class: 'order-meta', style: 'display:block;font-weight:400', text: [i.options, i.note && `Note: ${i.note}`].filter(Boolean).join('. ') }),
      ))),
      o.notes && h('p', { class: 'order-notes', text: `Note: ${o.notes}` }),
      h('p', { class: 'contact-links' },
        h('a', { href: `tel:${phone}`, text: 'Call' }),
        h('a', { href: `sms:${phone}`, text: 'Text' }),
        h('a', { href: `mailto:${o.email}?subject=${encodeURIComponent(`Your Velvet Crumb order ${o.ref}`)}`, text: 'Email' }),
      ),
      h('div', { class: 'order-foot' },
        h('span', { class: 'order-total' },
          money(o.total_pence),
          o.payment_method === 'test' && h('span', { class: 'tag', text: 'Test' }),
        ),
        actions,
      ),
    );
  }

  // ---------- Menu ----------
  const blondieLike = (p) => /blondie/i.test(`${p.name} ${p.category}`);
  const thumb = (p) =>
    p.image ? h('img', { src: p.image, alt: '' }) : h('i', { class: `piece ${blondieLike(p) ? 'blondie' : ''}` });

  async function renderMenu() {
    const { products } = await api('/api/admin/products');
    const addButton = h('button', { type: 'button', class: 'btn btn-small', text: 'Add item', onclick: () => openEditor(null, products) });
    if (!products.length) {
      view.replaceChildren(
        viewHead('Menu'),
        h('div', { class: 'empty' },
          h('p', { text: 'Your menu is empty. Add your first bake with a photo, price and allergens.' }),
          h('button', { type: 'button', class: 'btn', text: 'Add item', onclick: () => openEditor(null, products) }),
        ),
      );
      return;
    }

    const ids = products.map((p) => p.id);
    const reorder = async (index, dir) => {
      const next = [...ids];
      [next[index], next[index + dir]] = [next[index + dir], next[index]];
      try {
        await api('/api/admin/products-order', { method: 'POST', body: { ids: next } });
        route();
      } catch (err) {
        toast(err.message, true);
      }
    };

    const list = h('ul', { class: 'items' });
    products.forEach((p, i) => {
      const profit = p.price_pence - p.cost_pence;
      const priceText = p.box ? `${money(p.price_pence)}, ${money(p.box.mix_pence)}, ${money(p.box.loaded_pence)}` : money(p.price_pence);
      const sub = p.cost_pence
        ? `${priceText}. Costs ${money(p.cost_pence)}, makes ${money(profit)}`
        : `${priceText}. Cost to make not set`;
      list.append(h('li', { class: 'item-row' },
        h('div', { class: 'thumb' }, thumb(p)),
        h('button', { type: 'button', class: 'item-open', onclick: () => openEditor(p, products), 'aria-label': `Edit ${p.name}` },
          h('span', { class: 'item-title' },
            p.name,
            p.status === 'soldout' && h('span', { class: 'tag', text: 'Sold out' }),
            p.status === 'hidden' && h('span', { class: 'tag', text: 'Hidden' }),
            p.status === 'soon' && h('span', { class: 'tag', text: p.badge || 'Coming soon' }),
            p.status !== 'soon' && p.badge && h('span', { class: 'tag', text: p.badge }),
            !p.allergens_set && h('span', { class: 'tag tag-warn', text: 'Add allergens' }),
          ),
          h('span', { class: 'item-sub', text: `${p.category ? `${p.category}. ` : ''}${sub}` }),
        ),
        h('div', { class: 'move' },
          h('button', { type: 'button', 'aria-label': `Move ${p.name} up`, disabled: i === 0, text: '↑', onclick: () => reorder(i, -1) }),
          h('button', { type: 'button', 'aria-label': `Move ${p.name} down`, disabled: i === products.length - 1, text: '↓', onclick: () => reorder(i, 1) }),
        ),
      ));
    });

    const missing = products.filter((p) => p.status !== 'hidden' && !p.allergens_set).length;
    view.replaceChildren(...[
      viewHead('Menu', addButton),
      missing > 0 && h('p', { class: 'notice notice-warn setup-banner', text: `${missing} item${missing === 1 ? ' needs' : 's need'} allergens. Customers see “ask Jess” until you add them.` }),
      list,
      h('p', { class: 'hint', style: 'margin-top:1rem;color:var(--cocoa);font-size:var(--step--1)', text: 'Tap an item to change it. Use the arrows to set the order customers see.' }),
    ].filter(Boolean));
  }

  async function resizeImage(file, max = 1400) {
    const url = URL.createObjectURL(file);
    try {
      const img = await new Promise((resolve, reject) => {
        const i = new Image();
        i.onload = () => resolve(i);
        i.onerror = () => reject(new Error('That photo could not be opened. Try a JPEG or PNG.'));
        i.src = url;
      });
      const scale = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.naturalWidth * scale);
      canvas.height = Math.round(img.naturalHeight * scale);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', 0.85);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  function openPanel(title, body, foot) {
    const backdrop = h('div', { class: 'panel-backdrop' });
    const panel = h('section', { class: 'panel', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('header', { class: 'panel-head' },
        h('h2', { text: title }),
        h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Close', onclick: () => close() }),
      ),
      h('div', { class: 'panel-body' }, body),
      h('footer', { class: 'panel-foot' }, foot),
    );
    const others = [...document.body.children];
    others.forEach((el) => (el.inert = true));
    document.body.append(backdrop, panel);
    document.body.style.overflow = 'hidden';
    state.panelOpen = true;
    state.closePanel = () => close();
    const onKey = (e) => e.key === 'Escape' && close();
    document.addEventListener('keydown', onKey);
    backdrop.addEventListener('click', () => close());
    function close() {
      others.forEach((el) => (el.inert = false));
      backdrop.remove();
      panel.remove();
      document.body.style.overflow = '';
      document.removeEventListener('keydown', onKey);
      state.panelOpen = false;
      state.closePanel = null;
    }
    panel.querySelector('input, textarea, button')?.focus();
    return close;
  }

  const CLIPART = [
    'classic', 'triple-chocolate', 'biscuit', 'jam-blondie', 'choc-chunk', 'raspberry-blondie', 'cherry-brownie', 'special',
    'box-2', 'box-4', 'box-6', 'box-9', 'gf-classic', 'gf-triple-chocolate', 'gf-raspberry-blondie', 'gf-cherry-brownie',
    'gf-box-2', 'gf-box-4', 'gf-box-6', 'gf-box-9',
  ].map((n) => `/clipart/${n}.svg`);

  function openEditor(product, allProducts) {
    const p = product || {
      name: '', description: '', category: '', price_pence: 0, cost_pence: 0, allergens: [], allergens_set: false,
      image: '', status: 'on', options: [], note_label: '', note_required: false,
    };
    let image = p.image;
    // Working copy of the choices, edited in place.
    const groups = structuredClone(p.options || []);

    // Photo
    const preview = h('div', { class: 'preview' });
    const showPreview = () => preview.replaceChildren(image ? h('img', { src: image, alt: '' }) : h('i', { class: 'piece' }));
    showPreview();
    const fileInput = h('input', { type: 'file', accept: 'image/*', class: 'visually-hidden', id: 'photo-file' });
    const choose = h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Upload a photo', onclick: () => fileInput.click() });
    const clipRow = h('div', { class: 'clipart-row', role: 'group', 'aria-label': 'Or pick a picture' });
    const renderClip = () =>
      clipRow.replaceChildren(...CLIPART.map((src) => h('button', {
        type: 'button',
        'aria-pressed': String(image === src),
        'aria-label': `Use the ${src.split('/').pop().replace('.svg', '').replace(/-/g, ' ')} picture`,
        onclick: () => {
          image = src;
          showPreview();
          renderClip();
        },
      }, h('img', { src, alt: '' }))));
    renderClip();
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files[0];
      if (!file) return;
      choose.disabled = true;
      choose.textContent = 'Uploading…';
      try {
        const dataUrl = await resizeImage(file);
        const res = await api('/api/admin/uploads', { method: 'POST', body: { dataUrl } });
        image = res.image;
        showPreview();
        renderClip();
      } catch (err) {
        toast(err.message, true);
      } finally {
        choose.disabled = false;
        choose.textContent = 'Upload a photo';
        fileInput.value = '';
      }
    });

    // Details
    const name = h('input', { id: 'item-name', value: p.name, maxlength: 80, autocomplete: 'off' });
    const desc = h('textarea', { id: 'item-desc', rows: 3, maxlength: 400 });
    desc.value = p.description;
    const sections = [...new Set([...allProducts.map((x) => x.category).filter(Boolean), 'Classic', 'Loaded', 'Boxes'])];
    const category = h('input', { id: 'item-category', value: p.category, list: 'section-list', maxlength: 40, autocomplete: 'off' });
    const sectionList = h('datalist', { id: 'section-list' }, sections.map((x) => h('option', { value: x })));
    const price = h('input', { id: 'item-price', inputmode: 'decimal', value: p.price_pence ? pounds(p.price_pence) : '', placeholder: '0.00' });
    const cost = h('input', { id: 'item-cost', inputmode: 'decimal', value: p.cost_pence ? pounds(p.cost_pence) : '', placeholder: '0.00' });
    const marginLine = h('p', { class: 'margin-line', 'aria-live': 'polite' });
    const updateMargin = () => {
      const pr = toPence(price.value);
      const co = toPence(cost.value || 0);
      if (!pr || Number.isNaN(co)) {
        marginLine.textContent = 'Add the price and what one costs to make (ingredients and packaging) to see your profit per item.';
        return;
      }
      const profit = pr - co;
      marginLine.replaceChildren('Profit per item ', h('strong', { text: money(profit) }), ` (${Math.round((profit / pr) * 100)}% of the price)`);
    };
    price.addEventListener('input', updateMargin);
    cost.addEventListener('input', updateMargin);
    updateMargin();

    // Label on the picture and offers
    const badge = h('input', { id: 'item-badge', value: p.badge || '', maxlength: 30, list: 'badge-list', autocomplete: 'off', placeholder: 'e.g. Special offer' });
    const badgeList = h('datalist', { id: 'badge-list' },
      ['Special offer', 'New', 'Coming soon', 'Limited edition', 'Best seller', 'Back by demand'].map((x) => h('option', { value: x })));
    const was = h('input', { id: 'item-was', inputmode: 'decimal', value: p.was_price_pence ? pounds(p.was_price_pence) : '', placeholder: '0.00' });

    // Box customers fill with flavours
    const sets = state.settings.box_flavour_sets || [];
    const boxOn = h('input', { type: 'checkbox', checked: Boolean(p.box) });
    const boxSize = h('input', { id: 'box-size', inputmode: 'numeric', value: p.box ? String(p.box.size) : '', placeholder: 'e.g. 6' });
    const boxSet = h('select', { id: 'box-set' }, sets.map((x) => h('option', { value: x.id, text: x.name, selected: p.box?.set === x.id })));
    const money0 = (v) => (v ? pounds(v) : '');
    const boxMix = h('input', { id: 'box-mix', inputmode: 'decimal', value: money0(p.box?.mix_pence), placeholder: '0.00' });
    const boxLoaded = h('input', { id: 'box-loaded', inputmode: 'decimal', value: money0(p.box?.loaded_pence), placeholder: '0.00' });
    const boxMixCost = h('input', { id: 'box-mix-cost', inputmode: 'decimal', value: money0(p.box?.mix_cost_pence), placeholder: '0.00' });
    const boxLoadedCost = h('input', { id: 'box-loaded-cost', inputmode: 'decimal', value: money0(p.box?.loaded_cost_pence), placeholder: '0.00' });
    const boxDetails = h('div', { class: 'groups', hidden: !p.box },
      h('div', { class: 'two' }, field('Bakes in the box', boxSize), field('Flavour list', boxSet)),
      h('p', { class: 'hint', style: 'color:var(--cocoa);font-size:var(--step--1)', text: 'The price and cost to make above are for a box of all classic bakes. Edit the flavours in Settings, under Box flavours.' }),
      h('div', { class: 'two' }, field('Price for a mix (£)', boxMix), field('Price if all loaded (£)', boxLoaded)),
      h('div', { class: 'two' }, field('Cost for a mix (£)', boxMixCost), field('Cost if all loaded (£)', boxLoadedCost)),
    );
    boxOn.addEventListener('change', () => (boxDetails.hidden = !boxOn.checked));

    // Choices for customers
    const groupsBox = h('div', { class: 'groups' });
    const renderGroups = () => {
      groupsBox.replaceChildren(...groups.map((g, gi) => {
        const gName = h('input', { id: `g-name-${gi}`, value: g.name, maxlength: 40, placeholder: 'e.g. Topping', oninput: (e) => (g.name = e.target.value) });
        const typeSel = h('select', { 'aria-label': 'How many can they pick', onchange: (e) => { g.type = e.target.value; renderGroups(); } },
          h('option', { value: 'one', text: 'Pick one', selected: g.type !== 'many' }),
          h('option', { value: 'many', text: 'Pick several', selected: g.type === 'many' }),
        );
        const maxInput = g.type === 'many' && h('label', {}, 'Up to ', h('input', {
          type: 'number', min: 1, max: 60, value: String(g.max || g.choices.length || 1),
          oninput: (e) => (g.max = Number(e.target.value)),
        }));
        const req = h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: Boolean(g.required), onchange: (e) => (g.required = e.target.checked) }), 'Must choose');
        const rows = h('div', { class: 'choice-rows' },
          g.choices.map((c, ci) => h('div', { class: 'choice-row' },
            h('input', { value: c.name, maxlength: 60, placeholder: 'Choice name', 'aria-label': `Choice ${ci + 1} name`, oninput: (e) => (c.name = e.target.value) }),
            h('label', { class: 'amt' }, 'Adds to price £',
              h('input', { value: c.price_pence ? pounds(c.price_pence) : '', inputmode: 'decimal', placeholder: '0.00', oninput: (e) => (c.price_pence = e.target.value.trim() ? toPence(e.target.value) : 0) })),
            h('label', { class: 'amt' }, 'Adds to cost £',
              h('input', { value: c.cost_pence ? pounds(c.cost_pence) : '', inputmode: 'decimal', placeholder: '0.00', oninput: (e) => (c.cost_pence = e.target.value.trim() ? toPence(e.target.value) : 0) })),
            h('button', { type: 'button', class: 'icon-button', 'aria-label': `Remove ${c.name || 'this choice'}`, text: '✕', onclick: () => { g.choices.splice(ci, 1); renderGroups(); } }),
          )),
        );
        return h('div', { class: 'group-card' },
          h('div', { class: 'group-head' },
            h('div', { class: 'field' }, h('label', { for: `g-name-${gi}`, text: 'Name of this choice' }), gName),
            h('button', { type: 'button', class: 'btn btn-small btn-danger', text: 'Remove', onclick: () => { groups.splice(gi, 1); renderGroups(); } }),
          ),
          h('div', { class: 'group-rules' }, typeSel, maxInput, req),
          rows,
          h('button', { type: 'button', class: 'link-button', style: 'justify-self:start', text: 'Add a choice', onclick: () => { g.choices.push({ name: '', price_pence: 0, cost_pence: 0 }); renderGroups(); } }),
        );
      }));
    };
    renderGroups();
    const addGroup = h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Add a set of choices', onclick: () => {
      groups.push({ name: '', type: 'one', required: true, max: 1, choices: [{ name: '', price_pence: 0, cost_pence: 0 }] });
      renderGroups();
      groupsBox.lastElementChild?.querySelector('input')?.focus();
    } });

    // Question for the customer
    const noteLabel = h('input', { id: 'item-note', value: p.note_label || '', maxlength: 120, placeholder: 'e.g. Which flavours would you like in your box?' });
    const noteReq = h('input', { type: 'checkbox', checked: Boolean(p.note_required) });

    // Allergens
    const allergenBoxes = state.allergens.map((a) =>
      h('label', { class: 'check' }, h('input', { type: 'checkbox', value: a, checked: p.allergens.includes(a) }), h('span', { text: a })),
    );
    const noneBox = h('input', { type: 'checkbox', checked: Boolean(p.allergens_set && !p.allergens.length) });
    const syncNone = () => {
      const any = allergenBoxes.some((l) => l.querySelector('input').checked);
      if (any) noneBox.checked = false;
      noneBox.disabled = any;
    };
    allergenBoxes.forEach((l) => l.querySelector('input').addEventListener('change', syncNone));
    syncNone();

    const statusRow = h('div', { class: 'radio-row' },
      [['on', 'On sale'], ['soon', 'Coming soon'], ['soldout', 'Sold out'], ['hidden', 'Hidden']].map(([value, label]) =>
        h('label', {}, h('input', { type: 'radio', name: 'item-status', value, checked: p.status === value }), label),
      ),
    );

    const error = h('p', { class: 'form-error', role: 'alert' });
    const save = h('button', { type: 'button', class: 'btn', text: product ? 'Save changes' : 'Add to menu' });
    const del = product && h('button', { type: 'button', class: 'btn btn-danger', text: 'Delete' });
    const hint = (t) => h('p', { class: 'hint', style: 'color:var(--cocoa);font-size:var(--step--1)', text: t });

    const close = openPanel(product ? `Edit ${p.name}` : 'Add an item',
      [
        h('div', { class: 'photo-edit' }, preview, h('div', { class: 'buttons' }, choose, fileInput, hint('Square photos look best.'))),
        h('div', { class: 'field' }, h('span', { class: 'label', text: 'Or pick a picture' }), clipRow),
        field('Name', name),
        field('Description', desc, 'One or two lines customers will see.'),
        h('div', {}, field('Section', category, 'Items are grouped by section on the menu, e.g. Loaded.'), sectionList),
        h('div', { class: 'two' }, field('Price (£)', price), field('Cost to make (£)', cost)),
        marginLine,
        h('div', { class: 'two' },
          h('div', {}, field('Label on the picture', badge, 'Optional. Pick or type your own.'), badgeList),
          field('Was price (£)', was, 'Optional, for offers. Shown crossed out.'),
        ),
        h('fieldset', {},
          h('legend', { text: 'Box' }),
          h('label', { class: 'check' }, boxOn, 'Customers fill this box with flavours'),
          boxDetails,
        ),
        h('fieldset', {},
          h('legend', { text: 'Choices customers make' }),
          hint('For example a base (brownie or blondie) or a topping. A choice can add to the price.'),
          groupsBox,
          h('div', {}, addGroup),
        ),
        h('fieldset', {},
          h('legend', { text: 'Question for the customer (optional)' }),
          field('Question', noteLabel, 'They answer in a box when adding this item.'),
          h('label', { class: 'check' }, noteReq, 'They must answer'),
        ),
        h('fieldset', {},
          h('legend', { text: 'Allergens' }),
          hint('Include allergens from every topping or choice customers can pick.'),
          h('div', { class: 'check-grid' }, allergenBoxes),
          h('label', { class: 'check' }, noneBox, 'Contains none of the 14 allergens'),
        ),
        h('fieldset', {}, h('legend', { text: 'Show on the menu' }), statusRow,
          hint('Coming soon shows the item with its label, but customers can’t order it yet.')),
        error,
      ],
      [save, del],
    );

    save.addEventListener('click', async () => {
      error.textContent = '';
      const cleanGroups = groups
        .map((g) => ({ ...g, name: g.name.trim(), choices: g.choices.filter((c) => c.name.trim()) }))
        .filter((g) => g.name || g.choices.length);
      for (const g of cleanGroups) {
        if (!g.name) return (error.textContent = 'Give each set of choices a name, e.g. Topping.');
        if (!g.choices.length) return (error.textContent = `Add at least one choice to ${g.name}.`);
        if (g.choices.some((c) => Number.isNaN(c.price_pence) || Number.isNaN(c.cost_pence))) return (error.textContent = `Check the amounts in ${g.name}: use numbers like 1.50.`);
      }
      const body = {
        name: name.value,
        description: desc.value,
        category: category.value,
        price_pence: toPence(price.value),
        cost_pence: cost.value.trim() ? toPence(cost.value) : 0,
        allergens: allergenBoxes.map((l) => l.querySelector('input')).filter((i) => i.checked).map((i) => i.value),
        allergens_none: noneBox.checked,
        image,
        status: statusRow.querySelector('input:checked')?.value || 'on',
        badge: badge.value,
        was_price_pence: was.value.trim() ? toPence(was.value) : 0,
        options: cleanGroups,
        box: boxOn.checked
          ? {
            size: Number(boxSize.value),
            set: boxSet.value,
            mix_pence: toPence(boxMix.value),
            loaded_pence: toPence(boxLoaded.value),
            mix_cost_pence: boxMixCost.value.trim() ? toPence(boxMixCost.value) : 0,
            loaded_cost_pence: boxLoadedCost.value.trim() ? toPence(boxLoadedCost.value) : 0,
          }
          : null,
        note_label: noteLabel.value,
        note_required: noteReq.checked,
      };
      if (!body.name.trim()) return (error.textContent = 'Give the item a name.');
      if (!(body.price_pence > 0)) return (error.textContent = 'Enter a price, e.g. 3.50.');
      if (Number.isNaN(body.cost_pence) || body.cost_pence < 0) return (error.textContent = 'Enter the cost to make, e.g. 1.20, or leave it blank.');
      if (Number.isNaN(body.was_price_pence)) return (error.textContent = 'Enter the was price, e.g. 4.00, or leave it blank.');
      if (body.box) {
        if (!Number.isInteger(body.box.size) || body.box.size < 1 || body.box.size > 48) return (error.textContent = 'Enter how many bakes go in the box, e.g. 6.');
        if (!body.box.set) return (error.textContent = 'Add a flavour list in Settings first.');
        if (!(body.box.mix_pence > 0) || !(body.box.loaded_pence > 0)) return (error.textContent = 'Enter the box prices for a mix and for all loaded.');
        if (Number.isNaN(body.box.mix_cost_pence) || Number.isNaN(body.box.loaded_cost_pence)) return (error.textContent = 'Check the box costs: use numbers like 7.50.');
      }
      save.disabled = true;
      try {
        if (product) await api(`/api/admin/products/${product.id}`, { method: 'PUT', body });
        else await api('/api/admin/products', { method: 'POST', body });
        close();
        toast(product ? 'Changes saved' : `${body.name.trim()} added to the menu`);
        route();
      } catch (err) {
        error.textContent = err.message;
        save.disabled = false;
      }
    });

    del?.addEventListener('click', async () => {
      if (!window.confirm(`Delete ${p.name} from the menu? Past orders keep their details. To take it off for now, choose Hidden instead.`)) return;
      try {
        await api(`/api/admin/products/${product.id}`, { method: 'DELETE' });
        close();
        toast(`${p.name} deleted`);
        route();
      } catch (err) {
        error.textContent = err.message;
      }
    });
  }

  // ---------- Clients ----------
  async function renderClients() {
    const search = h('input', { type: 'search', id: 'client-search', placeholder: 'Name, phone, email or postcode', value: state.clientQuery || '', autocomplete: 'off' });
    const list = h('div', {}, loading());
    const addButton = h('button', { type: 'button', class: 'btn btn-small', text: 'Add client', onclick: () => openClientEditor(null) });
    view.replaceChildren(
      viewHead('Clients', addButton),
      h('div', { class: 'search' }, field('Search', search)),
      list,
      h('section', { class: 'block' },
        h('div', { class: 'exports' }, h('a', { class: 'btn btn-small btn-quiet', href: '/api/admin/export/clients.csv', text: 'Download clients (CSV)' })),
      ),
    );

    let timer;
    const load = async () => {
      const { clients } = await api(`/api/admin/clients?q=${encodeURIComponent(state.clientQuery || '')}`);
      if (!clients.length) {
        list.replaceChildren(h('div', { class: 'empty' }, h('p', {
          text: state.clientQuery ? 'No clients match that search.' : 'Clients appear here when they order online. You can also add someone yourself.',
        })));
        return;
      }
      list.replaceChildren(h('ul', { class: 'client-list' }, clients.map((c) => h('li', {},
        h('button', { type: 'button', onclick: () => openClient(c.id) },
          h('span', { class: 'client-name', text: c.name }),
          h('span', { class: 'client-sub', text: [c.phone, c.postcode, c.source === 'added' ? 'Added by you' : ''].filter(Boolean).join(', ') || c.email }),
          h('span', { class: 'client-stat' },
            c.orders ? `${c.orders} order${c.orders === 1 ? '' : 's'}` : 'No orders yet',
            c.orders ? h('span', { style: 'display:block;color:var(--cocoa);font-weight:400', text: money(c.spent) }) : null,
          ),
        ),
      ))));
    };
    search.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        state.clientQuery = search.value.trim();
        load().catch((err) => toast(err.message, true));
      }, 250);
    });
    await load();
  }

  async function openClient(id) {
    let data;
    try {
      data = await api(`/api/admin/clients/${id}`);
    } catch (err) {
      toast(err.message, true);
      return;
    }
    const c = data.client;
    const phone = c.phone.replace(/[^\d+]/g, '');
    const edit = h('button', { type: 'button', class: 'btn', text: 'Edit details' });
    const close = openPanel(c.name, [
      h('div', { class: 'receipt-block', style: 'display:grid;gap:0.3rem' },
        c.phone && h('p', { text: c.phone }),
        c.email && h('p', { text: c.email }),
        (c.address || c.postcode) && h('p', { style: 'white-space:pre-line', text: [c.address, c.postcode].filter(Boolean).join('\n') }),
        h('p', { class: 'contact-links', style: 'margin-top:0.4rem' },
          phone && h('a', { href: `tel:${phone}`, text: 'Call' }),
          phone && h('a', { href: `sms:${phone}`, text: 'Text' }),
          c.email && h('a', { href: `mailto:${c.email}`, text: 'Email' }),
        ),
      ),
      c.notes && h('p', { class: 'order-notes', text: c.notes }),
      h('p', { class: 'margin-line', text: c.orders ? `${c.orders} paid order${c.orders === 1 ? '' : 's'}, ${money(c.spent)} in total.` : 'No paid orders yet.' }),
      h('section', {},
        h('h3', { style: 'font-size:var(--step-1);margin-bottom:0.5rem', text: 'Orders' }),
        data.orders.length
          ? h('ul', { class: 'history' }, data.orders.map((o) => h('li', {},
            h('div', { class: 'top' }, h('span', { text: `${o.dateLabel}` }), h('span', { text: money(o.total_pence) })),
            h('div', { style: 'color:var(--cocoa)', text: `${o.ref}. ${o.method === 'delivery' ? 'Delivery' : 'Collection'}. ${STATUS[o.status] || o.status}` }),
            h('div', { text: o.items.join('; ') }),
          )))
          : h('p', { class: 'hint', style: 'color:var(--cocoa)', text: 'Nothing yet.' }),
      ),
    ].filter(Boolean), [edit]);
    edit.addEventListener('click', () => {
      close();
      openClientEditor(c);
    });
  }

  function openClientEditor(client) {
    const c = client || { name: '', phone: '', email: '', address: '', postcode: '', notes: '' };
    const input = (id, key, attrs = {}) => {
      const el = h(attrs.multiline ? 'textarea' : 'input', { id, rows: attrs.multiline ? 3 : undefined, type: attrs.type, inputmode: attrs.inputmode, autocomplete: 'off', maxlength: attrs.max || 200 });
      el.value = c[key] || '';
      return el;
    };
    const name = input('c-name', 'name', { max: 100 });
    const phoneIn = input('c-phone', 'phone', { type: 'tel', inputmode: 'tel', max: 30 });
    const email = input('c-email', 'email', { type: 'email', inputmode: 'email' });
    const address = input('c-address', 'address', { multiline: true, max: 300 });
    const postcode = input('c-postcode', 'postcode', { max: 10 });
    const notes = input('c-notes', 'notes', { multiline: true, max: 1000 });
    const error = h('p', { class: 'form-error', role: 'alert' });
    const save = h('button', { type: 'button', class: 'btn', text: client ? 'Save changes' : 'Add client' });
    const del = client && h('button', { type: 'button', class: 'btn btn-danger', text: 'Delete' });

    const close = openPanel(client ? `Edit ${c.name}` : 'Add a client', [
      field('Name', name),
      h('div', { class: 'two' }, field('Mobile', phoneIn), field('Postcode', postcode)),
      field('Email', email),
      field('Address', address),
      field('Notes', notes, 'Anything useful, e.g. regular order, favourite flavours.'),
      h('p', { class: 'hint', style: 'color:var(--cocoa);font-size:var(--step--1)', text: 'Add a mobile number or an email. Clients who order online are added automatically.' }),
      error,
    ], [save, del]);

    save.addEventListener('click', async () => {
      error.textContent = '';
      save.disabled = true;
      const body = { name: name.value, phone: phoneIn.value, email: email.value, address: address.value, postcode: postcode.value, notes: notes.value };
      try {
        const res = client
          ? await api(`/api/admin/clients/${client.id}`, { method: 'PUT', body })
          : await api('/api/admin/clients', { method: 'POST', body });
        close();
        toast(client ? 'Client saved' : `${res.client.name} added`);
        if (location.hash === '#clients') route();
        openClient(res.client.id);
      } catch (err) {
        error.textContent = err.message;
        save.disabled = false;
      }
    });

    del?.addEventListener('click', async () => {
      if (!window.confirm(`Delete ${c.name} from your clients? Their past orders stay in your records for your accounts.`)) return;
      try {
        await api(`/api/admin/clients/${client.id}`, { method: 'DELETE' });
        close();
        toast(`${c.name} deleted`);
        route();
      } catch (err) {
        error.textContent = err.message;
      }
    });
  }

  // ---------- Money ----------
  function taxYearStart(today) {
    const y = Number(today.slice(0, 4));
    const start = `${y}-04-06`;
    return today >= start ? start : `${y - 1}-04-06`;
  }

  function periodRange(key) {
    const today = ukToday();
    const [y, m] = today.split('-').map(Number);
    const pad = (n) => String(n).padStart(2, '0');
    switch (key) {
      case 'last-month': {
        const first = m === 1 ? `${y - 1}-12-01` : `${y}-${pad(m - 1)}-01`;
        return [first, addDays(`${y}-${pad(m)}-01`, -1)];
      }
      case 'this-tax-year':
        return [taxYearStart(today), today];
      case 'last-tax-year': {
        const start = taxYearStart(today);
        const prev = `${Number(start.slice(0, 4)) - 1}-04-06`;
        return [prev, addDays(start, -1)];
      }
      case 'last-12':
        return [addDays(today, -364), today];
      case 'custom':
        return [state.customFrom, state.customTo];
      case 'this-month':
      default:
        return [`${y}-${pad(m)}-01`, today];
    }
  }

  async function renderMoney() {
    const select = h('select', { id: 'period' },
      [
        ['this-month', 'This month'],
        ['last-month', 'Last month'],
        ['this-tax-year', 'This tax year (from 6 April)'],
        ['last-tax-year', 'Last tax year'],
        ['last-12', 'Last 12 months'],
        ['custom', 'Choose dates'],
      ].map(([v, l]) => h('option', { value: v, text: l, selected: state.period === v })),
    );
    select.addEventListener('change', () => {
      state.period = select.value;
      route();
    });
    const from = h('input', { type: 'date', id: 'from', value: state.customFrom });
    const to = h('input', { type: 'date', id: 'to', value: state.customTo });
    const applyCustom = () => {
      if (from.value && to.value) {
        state.customFrom = from.value;
        state.customTo = to.value;
        route();
      }
    };
    from.addEventListener('change', applyCustom);
    to.addEventListener('change', applyCustom);

    const content = h('div', {}, loading());
    view.replaceChildren(
      viewHead('Money'),
      h('div', { class: 'period' },
        field('Period', select),
        state.period === 'custom' && h('div', { class: 'two' }, field('From', from), field('To', to)),
      ),
      content,
    );

    const [start, end] = periodRange(state.period);
    const qs = `from=${start}&to=${end}`;
    const [f, { expenses }] = await Promise.all([api(`/api/admin/finance?${qs}`), api(`/api/admin/expenses?${qs}`)]);

    const line = (label, value, { note, cls } = {}) =>
      h('div', { class: cls }, h('dt', {}, label, note && h('small', { text: note })), h('dd', { text: money(value) }));

    const statement = h('dl', { class: 'statement' },
      line(`Sales`, f.sales, { note: `${f.orders} order${f.orders === 1 ? '' : 's'}${f.delivery ? `, including ${money(f.delivery)} delivery` : ''}` }),
      line('Cost of bakes', -f.cost, { note: 'Cost to make each item sold', cls: 'out' }),
      line('Card fees', -f.fees, { note: 'Kept by Stripe', cls: 'out' }),
      line('Other costs', -f.expenses, { note: 'Logged below', cls: 'out' }),
      line('Profit', f.profit, { cls: `profit${f.profit < 0 ? ' is-loss' : ''}` }),
    );

    const notes = h('div', { class: 'money-notes' },
      f.itemsWithoutCost > 0 && h('p', { class: 'notice notice-warn' },
        `${f.itemsWithoutCost} item${f.itemsWithoutCost === 1 ? ' has' : 's have'} no cost to make, so profit looks higher than it is. `,
        h('a', { href: '#menu', text: 'Add costs on the Menu tab' }), '.'),
      f.testOrders > 0 && h('p', { class: 'notice notice-warn', text: `Includes ${f.testOrders} test order${f.testOrders === 1 ? '' : 's'}. Delete test orders in Settings before you go live.` }),
      f.refunds.n > 0 && h('p', { class: 'notice notice-warn', text: `${f.refunds.n} refunded order${f.refunds.n === 1 ? '' : 's'} (${money(f.refunds.amount)}) left out of sales. Stripe keeps its card fee on refunds.` }),
    );

    const best = f.bestSellers.length
      ? h('div', { class: 'table-wrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Item', 'Sold', 'Sales', 'Profit'].map((t) => h('th', { scope: 'col', text: t })))),
        h('tbody', {}, f.bestSellers.map((b) => h('tr', {},
          h('td', { text: b.name }), h('td', { text: b.qty }), h('td', { text: money(b.sales) }), h('td', { text: money(b.sales - b.cost) }),
        ))),
      ))
      : h('p', { class: 'empty', text: 'No sales in this period yet.' });

    const months = f.byMonth.length < 2 ? '' : h('section', { class: 'block' },
      h('h3', { text: 'Month by month' }),
      h('div', { class: 'table-wrap' }, h('table', {},
        h('thead', {}, h('tr', {}, ['Month', 'Sales', 'Costs', 'Profit'].map((t) => h('th', { scope: 'col', text: t })))),
        h('tbody', {}, f.byMonth.map((m) => h('tr', {},
          h('td', { text: monthName(m.month) }),
          h('td', { text: money(m.sales) }),
          h('td', { text: money(m.cost + m.fees + m.expenses) }),
          h('td', { class: m.profit < 0 ? 'neg' : '', text: money(m.profit) }),
        ))),
      )),
    );

    // Other costs
    const eDate = h('input', { type: 'date', id: 'expense-date', value: ukToday() });
    const eCat = h('select', { id: 'expense-category' }, state.expenseCategories.map((c) => h('option', { value: c, text: c })));
    const eDesc = h('input', { id: 'expense-desc', maxlength: 200, placeholder: 'e.g. Cake boxes x 50' });
    const eAmount = h('input', { id: 'expense-amount', inputmode: 'decimal', placeholder: '0.00' });
    const eError = h('p', { class: 'form-error', role: 'alert' });
    const expenseForm = h('form', { class: 'expense-form' },
      h('div', { class: 'two' }, field('Date paid', eDate), field('Amount (£)', eAmount)),
      field('Type', eCat),
      field('What for', eDesc),
      eError,
      h('button', { type: 'submit', class: 'btn btn-small', text: 'Add cost' }),
    );
    expenseForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      eError.textContent = '';
      const amount = toPence(eAmount.value);
      if (!(amount > 0)) return (eError.textContent = 'Enter the amount, e.g. 12.99.');
      try {
        await api('/api/admin/expenses', { method: 'POST', body: { date: eDate.value, category: eCat.value, description: eDesc.value, amount_pence: amount } });
        toast('Cost added');
        route();
      } catch (err) {
        eError.textContent = err.message;
      }
    });

    const expenseList = expenses.length
      ? h('ul', { class: 'expense-list' }, expenses.map((x) => h('li', {},
        h('span', {}, h('strong', { text: x.category }), ` ${x.description ? `${x.description}, ` : ''}${niceDate(x.date)}`),
        h('span', { class: 'amount', text: money(x.amount_pence) }),
        h('button', {
          type: 'button',
          class: 'icon-button',
          'aria-label': `Delete ${x.category} cost of ${money(x.amount_pence)}`,
          text: '✕',
          onclick: async () => {
            if (!window.confirm(`Delete this ${money(x.amount_pence)} cost?`)) return;
            try {
              await api(`/api/admin/expenses/${x.id}`, { method: 'DELETE' });
              toast('Cost deleted');
              route();
            } catch (err) {
              toast(err.message, true);
            }
          },
        }),
      )))
      : h('p', { class: 'hint', style: 'color:var(--cocoa)', text: 'No other costs logged in this period.' });

    content.replaceChildren(
      h('p', { class: 'hint', style: 'margin-bottom:0.7rem;color:var(--cocoa);font-size:var(--step--1)', text: `${niceDate(start)} to ${niceDate(end)}` }),
      statement,
      notes,
      h('section', { class: 'block' }, h('h3', { text: 'Best sellers' }), best),
      months,
      h('section', { class: 'block' },
        h('h3', { text: 'Other costs' }),
        h('p', { class: 'hint', style: 'margin-bottom:0.8rem;color:var(--cocoa);font-size:var(--step--1)', text: 'The cost to make each item already covers its ingredients and packaging. Log everything else here: equipment, ads, market pitches, website and insurance.' }),
        expenseForm,
        expenseList,
      ),
      h('section', { class: 'block' },
        h('h3', { text: 'Download for your accounts' }),
        h('div', { class: 'exports' },
          h('a', { class: 'btn btn-small btn-quiet', href: `/api/admin/export/orders.csv?${qs}`, text: 'Orders (CSV)' }),
          h('a', { class: 'btn btn-small btn-quiet', href: `/api/admin/export/expenses.csv?${qs}`, text: 'Other costs (CSV)' }),
        ),
      ),
    );
  }

  // ---------- Settings ----------
  async function renderSettings() {
    await loadSettings();
    const s = structuredClone(state.settings);

    const text = (id, label, key, hint, attrs = {}) => {
      const input = h(attrs.multiline ? 'textarea' : 'input', { id, maxlength: attrs.max || 200, rows: attrs.multiline ? 3 : undefined, type: attrs.type, inputmode: attrs.inputmode, autocomplete: 'off', placeholder: attrs.placeholder });
      input.value = s[key] ?? '';
      input.addEventListener('input', () => (s[key] = input.value));
      return field(label, input, hint);
    };
    const moneyField = (id, label, key, hint) => {
      const input = h('input', { id, inputmode: 'decimal', value: pounds(s[key] || 0) });
      input.addEventListener('input', () => (s[key] = toPence(input.value || 0)));
      return field(label, input, hint);
    };
    const numberField = (id, label, key, hint, { decimal = false } = {}) => {
      const input = h('input', { id, inputmode: decimal ? 'decimal' : 'numeric', value: String(s[key] ?? 0) });
      input.addEventListener('input', () => (s[key] = decimal ? parseFloat(input.value) : Number(input.value)));
      return field(label, input, hint);
    };
    const toggle = (label, key) => {
      const input = h('input', { type: 'checkbox', role: 'switch', checked: Boolean(s[key]) });
      input.addEventListener('change', () => (s[key] = input.checked));
      return h('label', { class: 'switch' }, h('span', { text: label }), input);
    };
    const hint = (t) => h('p', { class: 'hint', style: 'color:var(--cocoa);font-size:var(--step--1)', text: t });

    // Weekly opening times, Monday first
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const slotRow = (d, kind, label) => {
      const slot = s.schedule[d][kind];
      const from = h('input', { type: 'time', value: slot.from, step: 900, 'aria-label': `${dayNames[d]} ${label} from`, disabled: !slot.on });
      const to = h('input', { type: 'time', value: slot.to, step: 900, 'aria-label': `${dayNames[d]} ${label} until`, disabled: !slot.on });
      const on = h('input', { type: 'checkbox', checked: slot.on });
      on.addEventListener('change', () => {
        slot.on = on.checked;
        from.disabled = to.disabled = !on.checked;
      });
      from.addEventListener('change', () => (slot.from = from.value));
      to.addEventListener('change', () => (slot.to = to.value));
      return h('div', { class: 'slot' }, h('label', { class: 'toggle' }, on, label), from, h('span', { class: 'to', text: 'to' }), to);
    };
    const week = h('div', { class: 'week' },
      [1, 2, 3, 4, 5, 6, 0].map((d) => h('div', { class: 'weekday' },
        h('h4', { text: dayNames[d] }),
        slotRow(d, 'collect', 'Collection'),
        slotRow(d, 'deliver', 'Delivery'),
      )),
    );

    const blockedChips = h('div', { class: 'chips' });
    const renderBlocked = () => {
      blockedChips.replaceChildren(
        ...s.blocked_dates.map((d) => h('span', {},
          niceDate(d, { weekday: 'short', day: 'numeric', month: 'short' }),
          h('button', { type: 'button', 'aria-label': `Open ${niceDate(d)} again`, text: '✕', onclick: () => {
            s.blocked_dates = s.blocked_dates.filter((x) => x !== d);
            renderBlocked();
          } }),
        )),
      );
      if (!s.blocked_dates.length) blockedChips.append(hint('No days off set.'));
    };
    renderBlocked();
    const blockInput = h('input', { type: 'date', id: 'block-date', min: ukToday(), class: 'input' });
    const blockAdd = h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Add day off', onclick: () => {
      if (!blockInput.value) return;
      s.blocked_dates = [...new Set([...s.blocked_dates, blockInput.value])].sort();
      blockInput.value = '';
      renderBlocked();
    } });

    // Notices on the menu page
    const notices = structuredClone(s.notices || []);
    s.notices = notices;
    const noticeBox = h('div', { class: 'groups' });
    const noticeTitles = h('datalist', { id: 'notice-titles' },
      ['Coming soon', 'Special offer', 'Monthly specials', 'New', 'Christmas orders', 'Holiday notice'].map((x) => h('option', { value: x })));
    const renderNotices = () => {
      noticeBox.replaceChildren(...notices.map((n, i) => {
        const title = h('input', { id: `notice-title-${i}`, value: n.title, maxlength: 40, list: 'notice-titles', autocomplete: 'off', placeholder: 'e.g. Special offer' });
        title.addEventListener('input', () => (n.title = title.value));
        const body = h('textarea', { id: `notice-text-${i}`, rows: 2, maxlength: 300 });
        body.value = n.text;
        body.addEventListener('input', () => (n.text = body.value));
        const show = h('input', { type: 'checkbox', role: 'switch', checked: n.show });
        show.addEventListener('change', () => (n.show = show.checked));
        return h('div', { class: 'group-card' },
          h('label', { class: 'switch' }, h('span', { text: 'Show on the menu' }), show),
          field('Heading', title),
          field('Wording', body),
          h('button', { type: 'button', class: 'link-button', style: 'justify-self:start', text: 'Remove this notice', onclick: () => { notices.splice(i, 1); renderNotices(); } }),
        );
      }));
    };
    renderNotices();
    const addNotice = h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Add a notice', onclick: () => {
      if (notices.length >= 6) return toast('Keep it to 6 notices or fewer.', true);
      notices.push({ title: '', text: '', show: true });
      renderNotices();
      noticeBox.lastElementChild?.querySelector('input:not([type=checkbox])')?.focus();
    } });

    // Privacy notice and terms: start from the draft, Jess can reword
    function legalSection(key, title, url, draft) {
      if (!s[key]) s[key] = draft;
      const area = h('textarea', { id: `legal-${key}`, rows: 16, maxlength: 20000, style: 'font-size:15px;line-height:1.5' });
      area.value = s[key];
      area.addEventListener('input', () => (s[key] = area.value));
      return h('section', {},
        h('h3', { text: title }),
        hint('A starting draft for you to check. Save, then use View page to see it. ## starts a heading, - starts a bullet, **words** go bold. {business} and {contact} fill in from these settings.'),
        h('div', { class: 'field' }, h('label', { for: `legal-${key}`, text: `${title} wording` }), area),
        h('div', { class: 'exports' },
          h('a', { class: 'btn btn-small btn-quiet', href: url, target: '_blank', rel: 'noopener', text: 'View page' }),
          h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Go back to the draft', onclick: () => {
            if (!window.confirm(`Replace your ${title.toLowerCase()} wording with the original draft? Save settings afterwards to keep it.`)) return;
            area.value = draft;
            s[key] = draft;
          } }),
        ),
      );
    }

    // Box flavours: lists customers fill boxes from
    const flavourSets = structuredClone(s.box_flavour_sets || []);
    s.box_flavour_sets = flavourSets;
    const setsBox = h('div', { class: 'groups' });
    const renderSets = () => {
      setsBox.replaceChildren(...flavourSets.map((set, i) => {
        const nameIn = h('input', { id: `set-name-${i}`, value: set.name, maxlength: 40 });
        nameIn.addEventListener('input', () => (set.name = nameIn.value));
        const basesIn = h('input', { id: `set-bases-${i}`, value: set.bases.join(', '), maxlength: 300 });
        basesIn.addEventListener('input', () => (set.bases = basesIn.value.split(',').map((x) => x.trim()).filter(Boolean)));
        const rows = set.flavours.map((fl, j) => {
          const n = h('input', { value: fl.name, maxlength: 60, placeholder: 'Flavour', 'aria-label': `Flavour ${j + 1}` });
          n.addEventListener('input', () => (fl.name = n.value));
          const k = h('select', { 'aria-label': `Is ${fl.name || 'this flavour'} classic or loaded` },
            h('option', { value: 'classic', text: 'Classic', selected: fl.kind !== 'loaded' }),
            h('option', { value: 'loaded', text: 'Loaded', selected: fl.kind === 'loaded' }),
          );
          k.addEventListener('change', () => (fl.kind = k.value));
          return h('div', { class: 'flavour-edit' }, n, k,
            h('button', { type: 'button', class: 'icon-button', 'aria-label': `Remove ${fl.name || 'this flavour'}`, text: '✕', onclick: () => { set.flavours.splice(j, 1); renderSets(); } }));
        });
        return h('div', { class: 'group-card' },
          field('List name', nameIn),
          field('Bases for classic bakes', basesIn, 'Separate with commas. Customers pick one when their box has classic bakes.'),
          h('p', { class: 'flavour-head', text: 'Flavours' }),
          h('div', { class: 'flavour-edits' }, rows),
          h('div', { class: 'exports' },
            h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Add a flavour', onclick: () => {
              set.flavours.push({ name: '', kind: 'classic' });
              renderSets();
              setsBox.children[i]?.querySelectorAll('.flavour-edit input')?.[set.flavours.length - 1]?.focus();
            } }),
            h('button', { type: 'button', class: 'link-button', text: 'Remove this list', onclick: () => {
              if (!window.confirm(`Remove the ${set.name || 'unnamed'} flavour list? Boxes using it need another list first.`)) return;
              flavourSets.splice(i, 1);
              renderSets();
            } }),
          ),
        );
      }));
    };
    renderSets();
    const addSet = h('button', { type: 'button', class: 'btn btn-small btn-quiet', text: 'Add a flavour list', onclick: () => {
      flavourSets.push({ id: '', name: '', bases: ['Chocolate brownie', 'White chocolate blondie'], flavours: [{ name: '', kind: 'classic' }] });
      renderSets();
      setsBox.lastElementChild?.querySelector('input')?.focus();
    } });

    const statusLine = (label, on, onText, offText) =>
      h('p', {}, h('span', { text: label }), h('span', { class: on ? 'status-on' : 'status-off', text: on ? onText : offText }));

    const error = h('p', { class: 'form-error', role: 'alert' });
    const saveButton = h('button', { type: 'submit', class: 'btn', text: 'Save settings' });

    const form = h('form', { class: 'settings' },
      h('section', {},
        h('h3', { text: 'Opening days and times' }),
        hint('Tick the days you offer collection or delivery, and the times. Customers only see days that are ticked. Times are shown to customers with their order.'),
        week,
        h('div', { class: 'two' },
          numberField('lead', "Days' notice needed", 'lead_days', 'e.g. 2 means orders today are for the day after tomorrow at the earliest.'),
          numberField('window', 'Book up to (days ahead)', 'booking_window_days'),
        ),
        numberField('cap', 'Most orders per day', 'daily_order_cap', '0 means no limit.'),
        h('fieldset', {},
          h('legend', { text: 'Days off' }),
          hint('Holidays or busy days. These dates close even if the weekday is ticked.'),
          blockedChips,
          h('div', { class: 'inline-add' }, blockInput, blockAdd),
        ),
      ),
      h('section', {},
        h('h3', { text: 'Notices on the menu' }),
        hint('Boxes at the top of the menu, e.g. Coming soon or Special offer. Pick a heading or type your own.'),
        noticeTitles,
        noticeBox,
        h('div', {}, addNotice),
      ),
      h('section', {},
        h('h3', { text: 'Box flavours' }),
        hint('The flavours customers pick from when they fill a box. Classic flavours go on the base they choose; loaded are the filled bakes. Any change here applies to every box using that list. Save settings when you are done.'),
        setsBox,
        h('div', {}, addSet),
      ),
      h('section', {},
        h('h3', { text: 'Shop' }),
        toggle('Taking orders', 'shop_open'),
        text('closed', 'Message when not taking orders', 'closed_message'),
        text('tagline', 'Line under the logo', 'tagline', null, { max: 140 }),
        moneyField('minorder', 'Minimum order (£)', 'min_order_pence', '0 means no minimum.'),
        text('phone', 'Phone for customer questions', 'contact_phone', 'Shown on the menu and order page. Leave blank to hide.', { max: 30, type: 'tel' }),
        text('cemail', 'Email for customer questions', 'contact_email', 'Shown on the menu, privacy notice and terms. Leave blank to hide.', { type: 'email', inputmode: 'email' }),
        text('owner', 'Email for new order alerts', 'owner_email', state.meta.email ? 'Private: only used to tell you about new orders.' : 'Private. Alerts send once emails are switched on.', { type: 'email', inputmode: 'email' }),
        h('div', { class: 'two' },
          text('insta', 'Instagram name', 'instagram', null, { max: 40, placeholder: 'velvet_x_crumbs' }),
          text('fb', 'Facebook link', 'facebook_url', null, { max: 200, type: 'url' }),
        ),
      ),
      h('section', {},
        h('h3', { text: 'Collection' }),
        text('carea', 'What customers see before ordering', 'collection_area', 'Keep your address out of this one.'),
        text('caddr', 'Collection address', 'collection_address', 'Only shown to customers after they have paid.', { multiline: true, max: 300 }),
      ),
      h('section', {},
        h('h3', { text: 'Local delivery' }),
        h('div', { class: 'two' },
          moneyField('dfee', 'Delivery fee (£)', 'delivery_fee_pence'),
          moneyField('dfree', 'Free delivery over (£)', 'delivery_free_over_pence', '0 means never free.'),
        ),
        text('dpost', 'Postcodes you deliver to', 'delivery_postcodes', 'Separate with commas, e.g. S70, S71, S75. A whole area works too, e.g. S. Leave blank to accept any.', { max: 300 }),
        text('dnote', 'Delivery note for customers', 'delivery_note'),
      ),
      h('section', {},
        h('h3', { text: 'Allergens' }),
        text('allergen', 'Allergen note on the menu and at checkout', 'allergen_notice', 'Customers must tick to confirm they have read this before paying.', { multiline: true, max: 600 }),
      ),
      h('section', {},
        h('h3', { text: 'Payments and emails' }),
        h('div', { class: 'status-list' },
          statusLine('Card payments (Stripe)', state.meta.stripe, 'Connected', 'Test mode'),
          statusLine('Order emails', state.meta.email, 'On', 'Off'),
        ),
        h('div', { class: 'two' },
          numberField('feepc', 'Card fee (%)', 'stripe_fee_percent', null, { decimal: true }),
          numberField('feefix', 'Plus per payment (p)', 'stripe_fee_fixed_pence'),
        ),
        hint('Used to estimate card fees until Stripe reports the exact fee for each payment.'),
      ),
      legalSection('privacy_text', 'Privacy notice', '/privacy', state.legalDefaults.privacy),
      legalSection('terms_text', 'Terms of sale', '/terms', state.legalDefaults.terms),
      h('section', {},
        h('h3', { text: 'Test orders' }),
        hint('Before going live, clear out any test orders and unpaid baskets so the Money tab starts at zero.'),
        h('button', { type: 'button', class: 'btn btn-small btn-danger', text: 'Delete test orders', onclick: async () => {
          if (!window.confirm('Delete all test orders and unpaid orders? Real paid orders are kept.')) return;
          try {
            const { deleted } = await api('/api/admin/delete-test-orders', { method: 'POST', body: {} });
            toast(`${deleted} order${deleted === 1 ? '' : 's'} deleted`);
            refreshOverview();
          } catch (err) {
            toast(err.message, true);
          }
        } }),
      ),
      h('div', { class: 'save-bar' }, error, saveButton),
    );

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      error.textContent = '';
      for (const key of ['min_order_pence', 'delivery_fee_pence', 'delivery_free_over_pence']) {
        if (Number.isNaN(s[key])) return (error.textContent = 'Check the money amounts: use numbers like 3.00.');
      }
      saveButton.disabled = true;
      try {
        const data = await api('/api/admin/settings', { method: 'PUT', body: s });
        state.settings = data.settings;
        toast('Settings saved');
        refreshOverview();
      } catch (err) {
        error.textContent = err.message;
      } finally {
        saveButton.disabled = false;
      }
    });

    view.replaceChildren(viewHead('Settings'), form);
  }

  // ---------- Start ----------
  setInterval(() => {
    if ($('#app').hidden || document.hidden) return;
    refreshOverview();
    if ((location.hash || '#orders') === '#orders' && !state.panelOpen) route();
  }, 60_000);

  api('/api/admin/session')
    .then((s) => {
      if (s.signedIn) start();
      else showLogin(s.passwordSet ? '' : 'Set ADMIN_PASSWORD on the server before signing in.');
    })
    .catch((err) => showLogin(err.message));
})();
