// Small Stripe client using the REST API directly (no SDK needed).
import crypto from 'node:crypto';
import { config } from './config.js';

// Stripe expects form encoding with bracketed keys: line_items[0][quantity]=2
export function formEncode(value, prefix = '', out = []) {
  if (value === undefined || value === null) return out;
  if (typeof value === 'object') {
    for (const [key, inner] of Object.entries(value)) {
      formEncode(inner, prefix ? `${prefix}[${key}]` : key, out);
    }
  } else {
    out.push(`${encodeURIComponent(prefix)}=${encodeURIComponent(String(value))}`);
  }
  return out;
}

export async function stripeRequest(method, path, params) {
  const body = params ? formEncode(params).join('&') : '';
  const url = `${config.stripeApiBase}${path}${method === 'GET' && body ? `?${body}` : ''}`;
  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${config.stripeSecretKey}`,
      ...(method === 'GET' ? {} : { 'Content-Type': 'application/x-www-form-urlencoded' }),
    },
    body: method === 'GET' ? undefined : body,
    signal: AbortSignal.timeout(20_000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error?.message || `Stripe returned ${res.status}`);
  }
  return data;
}

export function createCheckoutSession({ order, items, baseUrl, businessName }) {
  // Stripe can show photos, but not SVG clip art.
  const imageUrl = (image) =>
    image && image.startsWith('/uploads/') && baseUrl.startsWith('https://') ? [`${baseUrl}${image}`] : undefined;

  const lineItems = items.map((item) => ({
    quantity: item.qty,
    price_data: {
      currency: 'gbp',
      unit_amount: item.price_pence,
      product_data: {
        name: item.name,
        description: [item.options, item.note && `Note: ${item.note}`].filter(Boolean).join('. ').slice(0, 300) || undefined,
        images: imageUrl(item.image),
      },
    },
  }));
  if (order.delivery_pence > 0) {
    lineItems.push({
      quantity: 1,
      price_data: {
        currency: 'gbp',
        unit_amount: order.delivery_pence,
        product_data: { name: 'Local delivery' },
      },
    });
  }

  return stripeRequest('POST', '/v1/checkout/sessions', {
    mode: 'payment',
    success_url: `${baseUrl}/order/${order.token}?paid=1`,
    cancel_url: `${baseUrl}/?basket=1`,
    customer_email: order.email,
    client_reference_id: order.ref,
    expires_at: Math.floor(Date.now() / 1000) + config.checkoutHoldMinutes * 60,
    metadata: { order_token: order.token, order_ref: order.ref },
    payment_intent_data: {
      description: `${businessName} order ${order.ref}`,
      metadata: { order_ref: order.ref },
    },
    line_items: lineItems,
  });
}

export function getCheckoutSession(id) {
  return stripeRequest('GET', `/v1/checkout/sessions/${encodeURIComponent(id)}`);
}

// The actual Stripe fee for a payment, in pence, or null if not available yet.
export async function getPaymentFee(paymentIntentId) {
  const pi = await stripeRequest(
    'GET',
    `/v1/payment_intents/${encodeURIComponent(paymentIntentId)}`,
    { expand: ['latest_charge.balance_transaction'] },
  );
  const fee = pi?.latest_charge?.balance_transaction?.fee;
  return Number.isInteger(fee) ? fee : null;
}

export function refundPayment(paymentIntentId) {
  return stripeRequest('POST', '/v1/refunds', { payment_intent: paymentIntentId });
}

// Checks the Stripe-Signature header on a webhook.
export function verifyWebhookSignature(rawBody, header, secret, toleranceSeconds = 300, nowMs = Date.now()) {
  if (!header || !secret) return false;
  let timestamp = null;
  const signatures = [];
  for (const part of String(header).split(',')) {
    const [key, value] = part.split('=');
    if (key === 't') timestamp = value;
    if (key === 'v1' && value) signatures.push(value);
  }
  if (!timestamp || !signatures.length) return false;
  if (Math.abs(nowMs / 1000 - Number(timestamp)) > toleranceSeconds) return false;
  const expected = crypto.createHmac('sha256', secret).update(`${timestamp}.${rawBody}`).digest();
  return signatures.some((sig) => {
    const given = Buffer.from(sig, 'hex');
    return given.length === expected.length && crypto.timingSafeEqual(given, expected);
  });
}

export function signWebhookPayload(rawBody, secret, timestamp = Math.floor(Date.now() / 1000)) {
  const sig = crypto.createHmac('sha256', secret).update(`${timestamp}.${rawBody}`).digest('hex');
  return `t=${timestamp},v1=${sig}`;
}
