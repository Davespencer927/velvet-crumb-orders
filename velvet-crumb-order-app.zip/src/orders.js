// Customer-facing shop: menu, placing orders, payment and the order page.
import crypto from 'node:crypto';
import { config, stripeEnabled } from './config.js';
import { db, getSettings, nowIso, parseList, transaction } from './db.js';
import { orderableDates, ukDate, longDate, scheduleIsSet } from './dates.js';
import { HttpError, text } from './http.js';
import {
  createCheckoutSession,
  getCheckoutSession,
  getPaymentFee,
  refundPayment,
} from './stripe.js';
import { sendOrderConfirmed, sendOrderRefunded } from './email.js';
import { saveClientFromOrder } from './clients.js';
import { parseBox, publicBox, priceBox } from './boxes.js';

export const ACTIVE_STATUSES = ['paid', 'ready', 'completed'];

const productsForShop = db.prepare(
  "SELECT * FROM products WHERE status IN ('on', 'soon', 'soldout') ORDER BY sort, id",
);
const productById = db.prepare('SELECT * FROM products WHERE id = ?');
const orderByToken = db.prepare('SELECT * FROM orders WHERE token = ?');
const orderById = db.prepare('SELECT * FROM orders WHERE id = ?');
const itemsForOrder = db.prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');
const refExists = db.prepare('SELECT 1 FROM orders WHERE ref = ?');

export function productOptions(p) {
  return parseList(p.options);
}

export function publicProduct(p, settings = getSettings()) {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    category: p.category,
    price_pence: p.price_pence,
    allergens: parseList(p.allergens),
    allergens_set: Boolean(p.allergens_set),
    image: p.image,
    status: p.status,
    badge: p.badge,
    was_price_pence: p.was_price_pence > p.price_pence ? p.was_price_pence : 0,
    // Choices without Jess's costs
    options: productOptions(p).map((g) => ({
      name: g.name,
      type: g.type,
      required: g.required,
      max: g.max,
      choices: g.choices.map((c) => ({ name: c.name, price_pence: c.price_pence })),
    })),
    note_label: p.note_label,
    note_required: Boolean(p.note_required),
    box: publicBox(p, settings),
  };
}

// Orders that take up a slot on a date: paid ones, plus anyone still at the
// payment page.
export function ordersPerDate(fromDate) {
  const holdCutoff = new Date(Date.now() - config.checkoutHoldMinutes * 60_000).toISOString();
  const rows = db
    .prepare(
      `SELECT date, COUNT(*) AS n FROM orders
       WHERE date >= ? AND (status IN ('paid', 'ready', 'completed') OR (status = 'pending' AND created_at > ?))
       GROUP BY date`,
    )
    .all(fromDate, holdCutoff);
  return Object.fromEntries(rows.map((r) => [r.date, r.n]));
}

export function postcodeAllowed(postcode, list) {
  const allowed = String(list || '')
    .split(/[,\n]/)
    .map((s) => s.trim().toUpperCase().replace(/\s+/g, ''))
    .filter(Boolean);
  if (!allowed.length) return true;
  // Each entry is a postcode district ("S70", "WF4") or a whole area ("S").
  // "S7" must not match S70: compare the full outward code, not a prefix.
  const pc = String(postcode).toUpperCase().replace(/\s+/g, '');
  const outward = pc.slice(0, -3);
  const area = (outward.match(/^[A-Z]+/) || [''])[0];
  return allowed.some((entry) => (/^[A-Z]+$/.test(entry) ? area === entry : outward === entry));
}

export function shopData() {
  const settings = getSettings();
  const today = ukDate();
  const dates = orderableDates(settings, ordersPerDate(today), today);
  return {
    testMode: !stripeEnabled(),
    shop: {
      name: settings.business_name,
      tagline: settings.tagline,
      open: Boolean(settings.shop_open),
      closedMessage: settings.closed_message,
      contactPhone: settings.contact_phone,
      contactEmail: settings.contact_email,
      instagram: settings.instagram,
      facebookUrl: /^https:\/\//.test(settings.facebook_url) ? settings.facebook_url : '',
      allergenNotice: settings.allergen_notice,
      minOrder: settings.min_order_pence,
      scheduleSet: scheduleIsSet(settings.schedule),
      notices: (settings.notices || []).filter((n) => n.show && (n.title || n.text)).map((n) => ({ title: n.title, text: n.text })),
      collection: {
        enabled: dates.some((d) => d.collect),
        area: settings.collection_area,
      },
      delivery: {
        enabled: dates.some((d) => d.deliver),
        fee: settings.delivery_fee_pence,
        freeOver: settings.delivery_free_over_pence,
        note: settings.delivery_note,
        postcodes: settings.delivery_postcodes,
      },
    },
    products: productsForShop.all().map((p) => publicProduct(p, settings)),
    dates,
  };
}

function newRef() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    const bytes = crypto.randomBytes(5);
    const ref = 'VC-' + [...bytes].map((b) => alphabet[b % alphabet.length]).join('');
    if (!refExists.get(ref)) return ref;
  }
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const POSTCODE_RE = /^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/i;

// Works out one basket line: checks the customer's choices against the
// item's options and adds any extra price and cost.
export function priceLine(p, line, settings = getSettings()) {
  const groups = productOptions(p);
  const given = Array.isArray(line?.options) ? line.options : [];
  let extraPrice = 0;
  let extraCost = 0;
  const parts = [];
  for (const g of groups) {
    const picked = given.find((o) => o && o.group === g.name);
    const names = [...new Set((Array.isArray(picked?.choices) ? picked.choices : []).map(String))];
    const chosen = names.map((n) => g.choices.find((c) => c.name === n));
    if (chosen.some((c) => !c)) throw new HttpError(409, `The choices for ${p.name} have changed. Remove it from your basket and add it again.`);
    if (g.required && !chosen.length) throw new HttpError(400, `Choose the ${g.name.toLowerCase()} for ${p.name}.`);
    const max = g.type === 'one' ? 1 : g.max || g.choices.length;
    if (chosen.length > max) throw new HttpError(400, `Choose up to ${max} for ${g.name.toLowerCase()} on ${p.name}.`);
    for (const c of chosen) {
      extraPrice += c.price_pence;
      extraCost += c.cost_pence;
    }
    if (chosen.length) parts.push(`${g.name}: ${chosen.map((c) => c.name).join(', ')}`);
  }
  const note = text(line?.note, 300);
  if (p.note_required && !note) throw new HttpError(400, `${p.name}: ${p.note_label || 'add a note for Jess'}`);
  // Boxes: the flavours picked decide the price (all classic, mix or all loaded).
  const box = parseBox(p.box);
  let basePrice = p.price_pence;
  let baseCost = p.cost_pence;
  if (box) {
    const priced = priceBox(p, box, settings, line?.box);
    basePrice = priced.price;
    baseCost = priced.cost;
    parts.unshift(priced.text);
  } else if (line?.box) {
    throw new HttpError(409, `${p.name} has changed. Remove it from your basket and add it again.`);
  }
  return {
    product_id: p.id,
    name: p.name,
    options: parts.join('. '),
    note: p.note_label ? note : '',
    price_pence: basePrice + extraPrice,
    cost_pence: baseCost + extraCost,
    allergens: p.allergens_set ? parseList(p.allergens) : null,
    image: p.image,
  };
}

export async function placeOrder(body, baseUrl) {
  const settings = getSettings();
  if (!settings.shop_open) throw new HttpError(409, settings.closed_message);

  // Basket: the server works out every price itself.
  const lines = Array.isArray(body.items) ? body.items.slice(0, 100) : [];
  const merged = new Map();
  for (const line of lines) {
    const id = Number(line?.id);
    const qty = Number(line?.qty);
    if (!Number.isInteger(id) || !Number.isInteger(qty) || qty < 1) continue;
    const p = productById.get(id);
    if (!p || p.status === 'hidden') throw new HttpError(409, 'Something in your basket is no longer on the menu. Remove it and try again.');
    if (p.status === 'soldout') throw new HttpError(409, `${p.name} has just sold out. Remove it and try again.`);
    if (p.status === 'soon') throw new HttpError(409, `${p.name} isn't available to order yet.`);
    const item = priceLine(p, line, settings);
    const key = `${id}|${item.options}|${item.note}`;
    const existing = merged.get(key);
    if (existing) existing.qty = Math.min(config.maxQtyPerItem, existing.qty + qty);
    else merged.set(key, { ...item, qty: Math.min(config.maxQtyPerItem, qty) });
  }
  const items = [...merged.values()];
  if (!items.length) throw new HttpError(400, 'Your basket is empty.');
  const subtotal = items.reduce((sum, i) => sum + i.price_pence * i.qty, 0);
  const cost = items.reduce((sum, i) => sum + i.cost_pence * i.qty, 0);
  if (subtotal < (settings.min_order_pence || 0)) {
    throw new HttpError(400, `The minimum order is £${(settings.min_order_pence / 100).toFixed(2)}.`);
  }

  // Collection or delivery
  const method = body.method === 'delivery' ? 'delivery' : body.method === 'collection' ? 'collection' : '';
  if (!method) throw new HttpError(400, 'Choose collection or delivery.');

  let address = '';
  let postcode = '';
  let deliveryFee = 0;
  if (method === 'delivery') {
    address = text(body.address, 300);
    postcode = text(body.postcode, 10).toUpperCase();
    if (address.length < 5) throw new HttpError(400, 'Enter the delivery address.');
    if (!POSTCODE_RE.test(postcode)) throw new HttpError(400, 'Enter a full UK postcode.');
    if (!postcodeAllowed(postcode, settings.delivery_postcodes)) {
      throw new HttpError(400, `Sorry, ${postcode} is outside the delivery area. Collection is still available.`);
    }
    const freeOver = settings.delivery_free_over_pence || 0;
    deliveryFee = freeOver > 0 && subtotal >= freeOver ? 0 : settings.delivery_fee_pence || 0;
  }

  // Date
  const today = ukDate();
  const date = String(body.date || '');
  const choice = orderableDates(settings, ordersPerDate(today), today).find((d) => d.date === date);
  if (!choice) throw new HttpError(400, 'Choose a date from the list.');
  const slot = method === 'collection' ? choice.collect : choice.deliver;
  if (!slot) throw new HttpError(400, `${method === 'collection' ? 'Collection' : 'Delivery'} isn't available on ${choice.label}. Choose another day.`);
  if (choice.full) throw new HttpError(409, `${choice.label} is now fully booked. Choose another date.`);

  // Customer
  const name = text(body.name, 100);
  const email = text(body.email, 200).toLowerCase();
  const phone = text(body.phone, 30);
  const notes = text(body.notes, 500);
  if (name.length < 2) throw new HttpError(400, 'Enter your name.');
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'Enter a valid email address.');
  if (phone.replace(/\D/g, '').length < 10) throw new HttpError(400, 'Enter a mobile number so Jess can reach you.');
  if (body.allergensChecked !== true) throw new HttpError(400, 'Tick the box to confirm you have checked the allergens.');

  const order = transaction(() => {
    const now = nowIso();
    const record = {
      token: crypto.randomBytes(16).toString('base64url'),
      ref: newRef(),
      status: 'pending',
      name,
      email,
      phone,
      method,
      date,
      address,
      postcode,
      notes,
      subtotal_pence: subtotal,
      delivery_pence: deliveryFee,
      total_pence: subtotal + deliveryFee,
      cost_pence: cost,
      time_window: slot.label,
      created_at: now,
      updated_at: now,
    };
    const cols = Object.keys(record);
    const { lastInsertRowid } = db
      .prepare(`INSERT INTO orders (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`)
      .run(...Object.values(record));
    const addItem = db.prepare(
      'INSERT INTO order_items (order_id, product_id, name, options, note, price_pence, cost_pence, qty, allergens) VALUES (?,?,?,?,?,?,?,?,?)',
    );
    for (const i of items) {
      addItem.run(lastInsertRowid, i.product_id, i.name, i.options, i.note, i.price_pence, i.cost_pence, i.qty, JSON.stringify(i.allergens));
    }
    return { ...record, id: Number(lastInsertRowid) };
  });

  if (!stripeEnabled()) {
    return { ref: order.ref, url: `/order/${order.token}` };
  }

  try {
    const session = await createCheckoutSession({ order, items, baseUrl, businessName: settings.business_name });
    db.prepare('UPDATE orders SET stripe_session = ?, updated_at = ? WHERE id = ?').run(session.id, nowIso(), order.id);
    return { ref: order.ref, url: session.url };
  } catch (err) {
    console.error('Stripe checkout failed:', err.message);
    db.prepare("UPDATE orders SET status = 'cancelled', updated_at = ? WHERE id = ?").run(nowIso(), order.id);
    throw new HttpError(502, 'Card payment is not available right now. Please try again in a few minutes.');
  }
}

function estimatedFee(total, settings) {
  return Math.round((total * Number(settings.stripe_fee_percent || 0)) / 100) + Number(settings.stripe_fee_fixed_pence || 0);
}

// allergens is null when Jess hadn't set them for that item.
export function orderItems(orderId) {
  return itemsForOrder.all(orderId).map((i) => ({ ...i, allergens: i.allergens === 'null' ? null : parseList(i.allergens) }));
}

// Marks an order paid once. Safe to call again for the same order.
export function markPaid(orderId, { paymentIntent = '', method = 'stripe', baseUrl = config.baseUrl } = {}) {
  const settings = getSettings();
  const order = orderById.get(orderId);
  if (!order) return null;
  const now = nowIso();
  const result = db
    .prepare(
      `UPDATE orders SET status = 'paid', paid_at = ?, paid_date = ?, payment_intent = ?, payment_method = ?,
       fee_pence = ?, updated_at = ? WHERE id = ? AND status IN ('pending', 'expired')`,
    )
    .run(now, ukDate(), paymentIntent, method, estimatedFee(order.total_pence, settings), now, orderId);
  const updated = orderById.get(orderId);
  if (result.changes !== 1) return updated;

  // Side effects only happen the first time.
  try {
    saveClientFromOrder(updated);
  } catch (err) {
    console.error('Could not save client:', err.message);
  }
  const items = orderItems(orderId);
  sendOrderConfirmed(updated, items, settings, baseUrl).catch((err) => console.error(err));
  if (method === 'stripe' && paymentIntent) recordActualFee(orderId, paymentIntent);
  return updated;
}

async function recordActualFee(orderId, paymentIntent, attempt = 1) {
  try {
    const fee = await getPaymentFee(paymentIntent);
    if (fee !== null) {
      db.prepare('UPDATE orders SET fee_pence = ? WHERE id = ?').run(fee, orderId);
      return;
    }
  } catch (err) {
    console.error('Could not read Stripe fee:', err.message);
  }
  if (attempt < 3) setTimeout(() => recordActualFee(orderId, paymentIntent, attempt + 1), 15_000 * attempt).unref();
}

export function handleStripeEvent(event, baseUrl) {
  const session = event?.data?.object;
  const token = session?.metadata?.order_token;
  if (!token) return;
  const order = orderByToken.get(token);
  if (!order) return;
  if (
    (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') &&
    session.payment_status === 'paid'
  ) {
    if (session.amount_total !== order.total_pence) {
      console.warn(`Order ${order.ref}: Stripe charged ${session.amount_total}, order total ${order.total_pence}`);
    }
    markPaid(order.id, { paymentIntent: session.payment_intent || '', method: 'stripe', baseUrl });
  } else if (event.type === 'checkout.session.expired' && order.status === 'pending') {
    db.prepare("UPDATE orders SET status = 'expired', updated_at = ? WHERE id = ? AND status = 'pending'").run(nowIso(), order.id);
  }
}

// What the customer sees on their order page.
export async function orderForCustomer(token, baseUrl) {
  let order = orderByToken.get(token);
  if (!order) throw new HttpError(404, 'We could not find that order.');

  // If the webhook hasn't arrived yet, ask Stripe directly.
  if (order.status === 'pending' && order.stripe_session && stripeEnabled()) {
    try {
      const session = await getCheckoutSession(order.stripe_session);
      if (session.payment_status === 'paid') {
        order = markPaid(order.id, { paymentIntent: session.payment_intent || '', method: 'stripe', baseUrl });
      }
    } catch (err) {
      console.error('Could not check Stripe session:', err.message);
    }
  }

  const settings = getSettings();
  const confirmed = ACTIVE_STATUSES.includes(order.status);
  return {
    ref: order.ref,
    status: order.status,
    firstName: order.name.split(' ')[0],
    method: order.method,
    date: order.date,
    dateLabel: longDate(order.date),
    address: order.method === 'delivery' ? order.address : '',
    postcode: order.method === 'delivery' ? order.postcode : '',
    collectionAddress: confirmed && order.method === 'collection' ? settings.collection_address : '',
    timeWindow: order.time_window,
    contactPhone: settings.contact_phone,
    allergenNotice: settings.allergen_notice,
    items: orderItems(order.id).map((i) => ({ name: i.name, options: i.options, note: i.note, qty: i.qty, price_pence: i.price_pence, allergens: i.allergens })),
    subtotal_pence: order.subtotal_pence,
    delivery_pence: order.delivery_pence,
    total_pence: order.total_pence,
    testMode: !stripeEnabled(),
  };
}

// Test mode only: lets you walk through an order without Stripe.
export function testPay(token) {
  if (stripeEnabled()) throw new HttpError(403, 'Test payments are switched off because Stripe is connected.');
  const order = orderByToken.get(token);
  if (!order) throw new HttpError(404, 'We could not find that order.');
  markPaid(order.id, { method: 'test' });
}

export async function cancelOrder(orderId) {
  const order = orderById.get(orderId);
  if (!order) throw new HttpError(404, 'Order not found.');
  const settings = getSettings();
  if (order.status === 'pending' || order.status === 'expired') {
    db.prepare("UPDATE orders SET status = 'cancelled', updated_at = ? WHERE id = ?").run(nowIso(), orderId);
    return orderById.get(orderId);
  }
  if (!['paid', 'ready'].includes(order.status)) {
    throw new HttpError(409, 'Only orders that are paid or ready can be cancelled.');
  }
  if (order.payment_method === 'stripe') {
    if (!order.payment_intent) throw new HttpError(409, 'This payment has no Stripe reference. Refund it in the Stripe dashboard.');
    try {
      await refundPayment(order.payment_intent);
    } catch (err) {
      throw new HttpError(502, `Stripe could not refund this order: ${err.message}`);
    }
  }
  db.prepare("UPDATE orders SET status = 'refunded', updated_at = ? WHERE id = ?").run(nowIso(), orderId);
  const updated = orderById.get(orderId);
  sendOrderRefunded(updated, settings);
  return updated;
}

// Runs at start-up and every few minutes:
// - unpaid orders stop holding their date once the payment page has closed
// - unpaid orders are deleted after 30 days
// - clients with no orders for 2 years are deleted
// - names and contact details are removed from orders older than 6 years
// (the privacy notice promises these periods).
export function housekeeping(now = Date.now()) {
  const iso = (ms) => new Date(ms).toISOString();
  const day = 86_400_000;
  db.prepare("UPDATE orders SET status = 'expired', updated_at = ? WHERE status = 'pending' AND created_at < ?")
    .run(nowIso(), iso(now - (config.checkoutHoldMinutes + 5) * 60_000));
  db.prepare("DELETE FROM orders WHERE (status = 'expired' OR (status = 'cancelled' AND paid_at IS NULL)) AND created_at < ?")
    .run(iso(now - 30 * day));
  const twoYears = iso(now - 730 * day);
  db.prepare(
    `DELETE FROM clients WHERE updated_at < ?
     AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.client_id = clients.id AND o.created_at >= ?)`,
  ).run(twoYears, twoYears);
  db.prepare('UPDATE orders SET client_id = NULL WHERE client_id IS NOT NULL AND client_id NOT IN (SELECT id FROM clients)').run();
  db.prepare(
    `UPDATE orders SET name = 'Removed after 6 years', email = '', phone = '', address = '', postcode = '', notes = '', client_id = NULL
     WHERE created_at < ? AND email != ''`,
  ).run(iso(now - (6 * 365 + 2) * day));
}

// Kept for older callers.
export const expireStaleOrders = housekeeping;
