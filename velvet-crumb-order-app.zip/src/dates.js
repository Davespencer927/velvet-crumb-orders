// Dates are handled as plain YYYY-MM-DD strings in UK time.

const ukFormat = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Europe/London',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

export function ukDate(when = new Date()) {
  return ukFormat.format(when instanceof Date ? when : new Date(when));
}

export function addDays(iso, n) {
  const d = new Date(`${iso}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function weekday(iso) {
  return new Date(`${iso}T00:00:00Z`).getUTCDay();
}

export function isIsoDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

export function longDate(iso) {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    timeZone: 'UTC',
  });
}

export function shortDate(iso) {
  return new Date(`${iso}T00:00:00Z`).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    timeZone: 'UTC',
  });
}

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// "16:30" → "4:30pm", "10:00" → "10am"
export function niceTime(hhmm) {
  const m = /^(\d{2}):(\d{2})$/.exec(String(hhmm || ''));
  if (!m) return '';
  const h = Number(m[1]);
  const suffix = h >= 12 ? 'pm' : 'am';
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${h12}${m[2] === '00' ? '' : `:${m[2]}`}${suffix}`;
}

export function timeWindow(slot) {
  if (!slot) return '';
  const from = niceTime(slot.from);
  const to = niceTime(slot.to);
  return from && to ? `${from} to ${to}` : from || to;
}

export function scheduleIsSet(schedule) {
  return Object.values(schedule || {}).some((d) => d?.collect?.on || d?.deliver?.on);
}

// Dates a customer can choose, given Jess's weekly opening times, days off,
// notice needed and how many orders each date already has.
export function orderableDates(settings, ordersPerDate = {}, today = ukDate()) {
  const out = [];
  const blocked = new Set(settings.blocked_dates);
  const cap = Number(settings.daily_order_cap) || 0;
  const first = addDays(today, Math.max(0, Number(settings.lead_days) || 0));
  const last = addDays(today, Math.max(1, Number(settings.booking_window_days) || 28));
  for (let d = first; d <= last; d = addDays(d, 1)) {
    const day = settings.schedule?.[weekday(d)] || {};
    const collect = day.collect?.on ? { from: day.collect.from, to: day.collect.to, label: timeWindow(day.collect) } : null;
    const deliver = day.deliver?.on ? { from: day.deliver.from, to: day.deliver.to, label: timeWindow(day.deliver) } : null;
    if ((!collect && !deliver) || blocked.has(d)) continue;
    out.push({
      date: d,
      label: longDate(d),
      short: shortDate(d),
      full: cap > 0 && (ordersPerDate[d] || 0) >= cap,
      collect,
      deliver,
    });
  }
  return out;
}
