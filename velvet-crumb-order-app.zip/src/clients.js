// Clients: everyone who has ordered, plus anyone Jess adds herself.
import { db, nowIso } from './db.js';
import { HttpError, text } from './http.js';
import { longDate } from './dates.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// UK numbers compared on digits only: "+44 7700 900123" matches "07700900123".
export function phoneKey(phone) {
  let digits = String(phone || '').replace(/\D/g, '');
  if (digits.startsWith('44')) digits = `0${digits.slice(2)}`;
  return digits.length >= 10 ? digits : '';
}

function findClient(email, phone) {
  if (email) {
    const byEmail = db.prepare('SELECT * FROM clients WHERE email = ? ORDER BY id LIMIT 1').get(email.toLowerCase());
    if (byEmail) return byEmail;
  }
  const key = phoneKey(phone);
  if (key) return db.prepare('SELECT * FROM clients WHERE phone_key = ? ORDER BY id LIMIT 1').get(key) || null;
  return null;
}

// Saves (or updates) the client for a paid order and links the order to them.
export function saveClientFromOrder(order) {
  const existing = findClient(order.email, order.phone);
  const now = nowIso();
  let id;
  if (existing) {
    id = existing.id;
    const delivery = order.method === 'delivery';
    db.prepare(
      `UPDATE clients SET name = ?, email = CASE WHEN email = '' THEN ? ELSE email END, phone = ?, phone_key = ?,
       address = ?, postcode = ?, updated_at = ? WHERE id = ?`,
    ).run(
      order.name,
      order.email,
      order.phone,
      phoneKey(order.phone),
      delivery ? order.address : existing.address,
      delivery ? order.postcode : existing.postcode,
      now,
      id,
    );
  } else {
    id = Number(
      db
        .prepare(
          `INSERT INTO clients (name, email, phone, phone_key, address, postcode, source, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, 'online', ?, ?)`,
        )
        .run(order.name, order.email, order.phone, phoneKey(order.phone), order.address, order.postcode, now, now).lastInsertRowid,
    );
  }
  db.prepare('UPDATE orders SET client_id = ? WHERE id = ?').run(id, order.id);
  return id;
}

// Links any paid orders that don't have a client yet (e.g. from before this feature).
export function linkUnlinkedOrders() {
  const orders = db
    .prepare("SELECT * FROM orders WHERE client_id IS NULL AND status IN ('paid', 'ready', 'completed', 'refunded') ORDER BY id")
    .all();
  for (const o of orders) saveClientFromOrder(o);
  return orders.length;
}

const STATS = `
  (SELECT COUNT(*) FROM orders o WHERE o.client_id = c.id AND o.status IN ('paid', 'ready', 'completed')) AS orders,
  (SELECT COALESCE(SUM(total_pence), 0) FROM orders o WHERE o.client_id = c.id AND o.status IN ('paid', 'ready', 'completed')) AS spent,
  (SELECT MAX(date) FROM orders o WHERE o.client_id = c.id AND o.status IN ('paid', 'ready', 'completed')) AS last_order`;

export function listClients(query = '') {
  const q = text(query, 60);
  const like = `%${q.replace(/[%_]/g, '')}%`;
  const rows = q
    ? db
        .prepare(
          `SELECT c.*, ${STATS} FROM clients c
           WHERE c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR c.postcode LIKE ? OR c.phone_key LIKE ?
           ORDER BY c.name COLLATE NOCASE LIMIT 300`,
        )
        .all(like, like, like, like, `%${q.replace(/\D/g, '') || '~'}%`)
    : db.prepare(`SELECT c.*, ${STATS} FROM clients c ORDER BY c.name COLLATE NOCASE LIMIT 300`).all();
  return rows.map(publicClient);
}

function publicClient(c) {
  const { phone_key: _ignored, ...rest } = c;
  return rest;
}

export function getClient(id) {
  const c = db.prepare(`SELECT c.*, ${STATS} FROM clients c WHERE c.id = ?`).get(id);
  if (!c) throw new HttpError(404, 'Client not found.');
  const orders = db
    .prepare('SELECT * FROM orders WHERE client_id = ? AND status != \'pending\' ORDER BY date DESC, id DESC LIMIT 100')
    .all(id)
    .map((o) => ({
      id: o.id,
      ref: o.ref,
      status: o.status,
      date: o.date,
      dateLabel: longDate(o.date),
      method: o.method,
      total_pence: o.total_pence,
      items: db
        .prepare('SELECT name, qty, options FROM order_items WHERE order_id = ? ORDER BY id')
        .all(o.id)
        .map((i) => `${i.qty} × ${i.name}${i.options ? ` (${i.options})` : ''}`),
    }));
  return { client: publicClient(c), orders };
}

function clientFields(body) {
  const name = text(body.name, 100);
  const email = text(body.email, 200).toLowerCase();
  const phone = text(body.phone, 30);
  if (name.length < 2) throw new HttpError(400, 'Enter the client’s name.');
  if (email && !EMAIL_RE.test(email)) throw new HttpError(400, 'That email address doesn’t look right.');
  if (!email && !phoneKey(phone)) throw new HttpError(400, 'Add a mobile number or an email so you can reach them.');
  if (phone && !phoneKey(phone)) throw new HttpError(400, 'That phone number looks too short.');
  return {
    name,
    email,
    phone,
    phone_key: phoneKey(phone),
    address: text(body.address, 300),
    postcode: text(body.postcode, 10).toUpperCase(),
    notes: text(body.notes, 1000),
  };
}

function checkDuplicate(fields, exceptId = 0) {
  const clash = findClient(fields.email, fields.phone);
  if (clash && clash.id !== exceptId) {
    throw new HttpError(409, `${clash.name} already has that ${clash.email && clash.email === fields.email ? 'email' : 'phone number'}.`);
  }
}

export function addClient(body) {
  const fields = clientFields(body);
  checkDuplicate(fields);
  const now = nowIso();
  const row = { ...fields, source: 'added', created_at: now, updated_at: now };
  const cols = Object.keys(row);
  const { lastInsertRowid } = db
    .prepare(`INSERT INTO clients (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`)
    .run(...Object.values(row));
  return getClient(Number(lastInsertRowid));
}

export function updateClient(id, body) {
  if (!db.prepare('SELECT 1 FROM clients WHERE id = ?').get(id)) throw new HttpError(404, 'Client not found.');
  const fields = clientFields(body);
  checkDuplicate(fields, id);
  const sets = Object.keys(fields).map((k) => `${k} = ?`).join(', ');
  db.prepare(`UPDATE clients SET ${sets}, updated_at = ? WHERE id = ?`).run(...Object.values(fields), nowIso(), id);
  return getClient(id);
}

// Removes the client's record. Their past orders stay for the accounts.
export function deleteClient(id) {
  const { changes } = db.prepare('DELETE FROM clients WHERE id = ?').run(id);
  if (!changes) throw new HttpError(404, 'Client not found.');
  db.prepare('UPDATE orders SET client_id = NULL WHERE client_id = ?').run(id);
}

export function clientsRows() {
  return listClients('').map((c) => [
    c.name, c.email, c.phone, c.address, c.postcode, c.orders, (c.spent / 100).toFixed(2), c.last_order || '',
    c.source === 'added' ? 'Added by Jess' : 'Online order', c.notes,
  ]);
}
