// Privacy notice and terms of sale.
// Jess can edit both on the admin Settings tab. Until she does, the drafts
// below are used. Words in {curly brackets} are filled in from Settings.

export const DEFAULT_PRIVACY = `Last updated: 24 November 2026

{business} is a home bakery run by Jess Rowley. This notice explains what personal information we collect when you order from us, why we collect it, and your rights. Jess is responsible for your information (the "data controller"). You can contact her {contact}.

## What we collect

- Your name, email address and mobile number.
- Your delivery address and postcode, if you choose delivery.
- Your order: what you ordered, your choices, the day, and any notes you add.
- Confirmation of your payment from Stripe. We never see or store your full card details.
- Anything you choose to tell us about an allergy or other health need, so we can make your order safely.

We also keep a simple client record (your name, contact details, order history and any notes Jess adds) so we can look after repeat orders.

## Why we use it, and our legal basis

- **To take, make, collect or deliver your order, and to contact you about it.** This is needed to carry out our contract with you.
- **To keep records for tax and accounts.** This is a legal obligation.
- **To keep your client record and deal with questions or complaints.** This is in our legitimate interest in running the business well.
- **Allergy or health details you give us.** We use these only with your explicit consent, and only to make your order safely. You can withdraw your consent at any time, but we may then not be able to make your order.

We don't send marketing messages unless you have asked us to. We don't sell your information, and we don't make automated decisions about you.

## Who we share it with

We only share what's needed with the services that help us run the shop:

- **Stripe**, which takes card payments.
- **Fly.io**, which hosts this website. Your order details are stored on its servers in London.
- **Our email provider**, if we email you an order confirmation.
- **Google Fonts**, which supplies the lettering on this website. Your browser connects to Google to load it.

Some of these companies are based in the United States. Where your information is handled outside the UK, they protect it with safeguards recognised under UK data protection law. We may also share information if the law requires us to.

## How long we keep it

- **Orders and payments:** 6 years, because tax rules require it. After that, your name and contact details are removed from the order.
- **Client records:** while you keep ordering from us. If you haven't ordered for 2 years, your client record is deleted automatically, or sooner if you ask.
- **Orders that were never paid for:** deleted after 30 days.

## Information saved in your browser

This website saves your basket on your device, so it isn't lost if you leave the page. If you tick "Remember my details on this device" at checkout, it also saves your name, email, mobile and address there for next time. Untick it to remove them. We don't use advertising or tracking cookies. Jess's admin page uses one cookie to keep her signed in.

## Your rights

You can ask us to:

- give you a copy of your information
- correct it if it's wrong
- delete it
- restrict or object to how we use it
- send it to you in a format you can reuse.

Contact us {contact}. We'll reply within one month.

If you're unhappy with how we've handled your information, please tell us first so we can put it right. You can also complain to the Information Commissioner's Office (ICO) at [ico.org.uk](https://ico.org.uk) or on 0303 123 1113.

## Changes to this notice

If we change how we use your information, we'll update this notice and the date at the top.`;

export const DEFAULT_TERMS = `Last updated: 24 November 2026

These terms apply when you order from {business}, a home bakery run by Jess Rowley. You can contact us {contact}. Please read them before you pay.

## Your order

- Choose your bakes and a collection or delivery day, then pay in full online. Your order is confirmed once your payment goes through and you see your confirmation.
- If we can't make your order, for example through illness or because an ingredient isn't available, we'll tell you as soon as we can and refund you in full.
- Photos and pictures are a guide. Every bake is made by hand, so sizes, shapes and toppings vary a little.
- We sell to customers for their own use, not for resale.

## Prices and payment

- Prices are in pounds and are the prices shown when you order. Any delivery fee is shown before you pay.
- Card payments are taken securely by Stripe.

## Collection

- Please collect on the day and within the times you chose. The collection address is on your order confirmation.
- If you can't make it, message us as soon as possible and we'll try to help. Our bakes are made fresh for you, so we can't refund orders that aren't collected.

## Delivery

- We deliver to the postcodes shown at checkout, on the day you chose, and we'll message you with a time.
- Please make sure someone is in. If nobody is in, we'll try to contact you. If we can't deliver, we may ask you to collect or charge for a second delivery.

## Changes and cancellations

Our bakes are perishable and made to order, so the 14-day right to cancel for online shopping doesn't apply. Instead:

- Cancel at least 48 hours before your collection or delivery day for a full refund.
- With less than 48 hours' notice we'll usually have bought the ingredients or started baking, so we can't normally refund, but please ask and we'll do what we can.
- To change an order, message us as soon as possible.

## Allergens

- Each item lists the allergens it contains. Our kitchen also handles gluten, eggs, milk, tree nuts, peanuts and soya, so we can't guarantee any bake is free from allergens, including our gluten free and vegan range.
- If you have an allergy, please message us before you order. You must check the allergens for everything in your order before you pay.

## Storage

Storage advice and a best-before date come with your order. Please follow them.

## If something's wrong

Our bakes must be as described and of satisfactory quality. If there's a problem, message us as soon as possible, ideally on the day, with a photo, and we'll put it right with a replacement or a refund. This doesn't affect your legal rights.

## Our responsibility to you

We're responsible for loss or damage you suffer that is a foreseeable result of us breaking these terms or not using reasonable care and skill. We're not responsible for loss that wasn't foreseeable. Nothing in these terms limits our responsibility for death or personal injury caused by our negligence, for fraud, or for anything else the law doesn't allow us to limit.

## Your information

Our [privacy notice](/privacy) explains how we use your information.

## The law

These terms are governed by the law of England and Wales. If you live in Scotland or Northern Ireland, you can also bring a claim in your local courts.`;

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// How customers can reach Jess, built from Settings.
export function contactPhrase(settings) {
  const parts = [];
  if (settings.contact_email) parts.push(`by email at ${settings.contact_email}`);
  if (settings.contact_phone) parts.push(`by text or phone on ${settings.contact_phone}`);
  if (settings.instagram) parts.push(`on Instagram @${settings.instagram}`);
  if (!parts.length) return 'through our Instagram or Facebook page';
  if (parts.length === 1) return parts[0];
  return `${parts.slice(0, -1).join(', ')} or ${parts[parts.length - 1]}`;
}

export function fillTokens(text, settings) {
  return String(text)
    .replace(/\{business\}/g, settings.business_name || 'Velvet Crumb')
    .replace(/\{contact\}/g, contactPhrase(settings));
}

// Inline formatting: **bold** and [text](link). Links must be https:// or a page on this site.
function inline(s) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\(((?:https:\/\/|\/(?!\/))[^\s)]*)\)/g, (_, label, url) => `<a href="${url}">${label}</a>`);
}

// A small, safe subset of Markdown: ## headings, - lists and paragraphs.
export function renderMarkdown(text) {
  const out = [];
  let list = null;
  let para = [];
  const flushPara = () => {
    if (para.length) out.push(`<p>${inline(para.join(' '))}</p>`);
    para = [];
  };
  const flushList = () => {
    if (list) out.push(`<ul>${list.map((li) => `<li>${inline(li)}</li>`).join('')}</ul>`);
    list = null;
  };
  for (const raw of String(text).replace(/\r/g, '').split('\n')) {
    const line = raw.trim();
    if (!line) {
      flushPara();
      flushList();
    } else if (line.startsWith('### ')) {
      flushPara();
      flushList();
      out.push(`<h3>${inline(line.slice(4))}</h3>`);
    } else if (line.startsWith('## ')) {
      flushPara();
      flushList();
      out.push(`<h2>${inline(line.slice(3))}</h2>`);
    } else if (/^[-*] /.test(line)) {
      flushPara();
      (list ||= []).push(line.slice(2));
    } else {
      flushList();
      para.push(line);
    }
  }
  flushPara();
  flushList();
  return out.join('\n');
}

export function legalPage(kind, settings) {
  const isPrivacy = kind === 'privacy';
  const title = isPrivacy ? 'Privacy notice' : 'Terms of sale';
  const text = (isPrivacy ? settings.privacy_text : settings.terms_text) || (isPrivacy ? DEFAULT_PRIVACY : DEFAULT_TERMS);
  const name = esc(settings.business_name || 'Velvet Crumb');
  return `<!doctype html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <title>${title} | ${name}</title>
    <meta name="theme-color" content="#d1c3b6" />
    <link rel="icon" href="/icon-64.png" type="image/png" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Libre+Caslon+Text:wght@400;700&display=swap" />
    <link rel="stylesheet" href="/styles.css" />
    <link rel="stylesheet" href="/shop.css" />
  </head>
  <body>
    <header class="hero hero-small">
      <div class="hero-inner">
        <p class="logo logo-small"><a href="/"><img src="/logo.svg" alt="${name}. Back to the menu." width="2328" height="480" /></a></p>
      </div>
    </header>
    <main class="legal">
      <h1>${title}</h1>
      ${renderMarkdown(fillTokens(text, settings))}
      <p class="legal-links"><a href="/">Back to the menu</a> <a href="${isPrivacy ? '/terms' : '/privacy'}">${isPrivacy ? 'Terms of sale' : 'Privacy notice'}</a></p>
    </main>
  </body>
</html>
`;
}
