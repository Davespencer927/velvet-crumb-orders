# Velvet Crumb order app

Customers pick brownies and blondies from a picture menu, make their choices (base, topping, box type, flavours), choose collection or local delivery and a day, and pay by card, Apple Pay or Google Pay through Stripe. Jess runs everything from a separate admin page on her phone, branded with the Velvet Crumb logo.

It is built the same way as the ASPEN app: a Node.js app on Render, with Jess's own Stripe account. It has no outside packages to install, and its database is built into Node (Node 22.13 or later).

## What's in it

**Customer page** (`/`)
- Menu grouped by section (Classic, Loaded, Boxes, Gluten free and vegan…), each item with a picture, price, description and allergens
- + and − buttons on each picture. Items with choices open a picker: e.g. brownie or blondie base, a topping, box type (classic, mix or loaded, each with its own price), plus a question such as "Which flavours would you like in your box?"
- Notices at the top of the menu, worded by Jess (e.g. "Coming soon", "Special offer", "Monthly specials")
- Items can carry a label on the picture (e.g. "Special offer", "New") and a crossed-out "was" price
- "Coming soon" items show on the menu with their label but can't be ordered yet
- Basket bar and a checkout sheet
- Collection (free) or local delivery (fee, optional free-delivery threshold, optional postcode list)
- Day picker driven by Jess's weekly opening times, with separate collection and delivery days and times, notice needed, days off and a daily order limit. The time window goes on the confirmation
- Allergens shown on every item, at checkout (customer must tick to confirm) and on the confirmation
- Payment taken there and then by Stripe Checkout; the order only counts once paid
- Order page with the collection address (only shown after payment) and a receipt email

**Admin page** (`/admin`, password protected)
- **Orders**: coming up by day, a "to bake" list per day (with each choice), Mark ready, Mark collected/delivered, Cancel and refund (refunds through Stripe), Call/Text/Email buttons
- **Clients**: everyone who pays is saved automatically (matched by email or mobile, so repeat customers aren't duplicated). Search, add clients by hand (e.g. a café or a Facebook regular), edit, add notes, see their order history and total spend, delete, download as CSV
- **Menu**: add, edit, delete, reorder; upload a photo (resized on the phone first) or pick a clip-art picture; price and cost to make with live profit per item; sets of choices with extra price and extra cost per choice; a question for the customer; a label on the picture and a "was" price for offers; 14 allergens or "contains none"; On sale / Coming soon / Sold out / Hidden
- **Money**: sales, cost of bakes, card fees, other costs and profit for this month, last month, this or last tax year, or any dates; best sellers; month by month; log other costs; CSV downloads for the accounts
- **Settings**: notices on the menu (heading and wording, show or hide, up to 6), opening days and times (collection and delivery separately, all closed until Jess ticks them), notice, limits, days off, pause orders, collection and delivery details, allergen note, alert email, Instagram and Facebook links, card fee rates, delete test orders

## The starter menu

The first time the app starts it loads Jess's menu from both menu sheets: Classic, Loaded, Boxes of 4, 6 and 9, and the gluten free and vegan range with boxes of 2, 4, 6 and 9, all at the menu prices. Each has a clip-art picture until Jess uploads photos. The Monthly special is there but hidden, for Jess to rename and show each month. The gluten free and vegan range starts as **Coming soon**: on the menu but not orderable until Jess switches each item to On sale. Two notices are set up from the menu sheet, "Coming soon" and "Monthly specials", for Jess to reword, hide or replace (e.g. with a special offer).

Left for Jess to fill in on the Menu tab:
- **Cost to make** for each item (and extra cost for loaded or mixed boxes), so the Money tab shows real profit
- **Allergens** from her allergen register. Until she does, customers see "Allergens: ask Jess before ordering" and the Menu tab flags each item

Once loaded, the starter menu never comes back: anything Jess deletes stays deleted.

## How the money page works

- **Sales**: every paid order, including delivery fees, by the day it was paid.
- **Cost of bakes**: each item's *cost to make* (from the pricing calculator), plus any extra cost for the choices picked, × how many sold. It's saved with each order, so changing a cost later doesn't rewrite the past.
- **Card fees**: the real Stripe fee for each payment (estimated from the % in Settings until Stripe reports it). Stripe keeps the fee on refunds, so those still count.
- **Other costs**: anything Jess logs by hand: equipment, ads, market pitches, Render and the domain. Ingredients and packaging are already covered by the cost to make, so don't log them twice.
- Refunded orders are left out of sales.

## Run it on a computer

```
ADMIN_PASSWORD=pick-one npm start
```

Open http://localhost:3000 for the shop and http://localhost:3000/admin for the admin. With no Stripe key it runs in **test mode**: orders can be "paid" with a test button and nothing is charged.

Run the tests with `npm test`.

## Go-live steps

1. **GitHub**: put this folder in a new repo (e.g. `velvet-crumb-orders`).
2. **Render**: New → Blueprint → the repo. It creates a Starter web service in Frankfurt with a 1 GB disk at `/var/data`. Set `ADMIN_PASSWORD` to something long and unique.
3. **Menu and settings**: sign in at `/admin`. On the Menu tab, add the cost to make and allergens for each item, and photos when ready. On Settings, tick the opening days and times, then set notice needed, the collection address, delivery fee and postcodes, alert email and phone.
4. **Stripe** (Jess, as the business owner): open and verify a Stripe account. Add `STRIPE_SECRET_KEY` (test key first, `sk_test_…`). In Stripe → Developers → Webhooks, add an endpoint at `https://<your address>/api/stripe/webhook` for these events:
   - `checkout.session.completed`
   - `checkout.session.async_payment_succeeded`
   - `checkout.session.expired`

   Copy its signing secret into `STRIPE_WEBHOOK_SECRET`.
5. **Domain** (optional): add it in Render, add the CNAME record where the domain was bought, set `BASE_URL` to the full address and update the Stripe webhook address.
6. **Emails** (optional): with Resend, verify the domain, then set `RESEND_API_KEY` and `EMAIL_FROM` (e.g. `Velvet Crumb <orders@yourdomain>`). Customers get a confirmation and Jess gets a new-order alert. Without this, orders still work and Jess sees them in the admin.
7. **Test**: place orders with Stripe test cards (4242 4242 4242 4242), check the confirmation, mark ready and collected, cancel and refund one.
8. **Go live**: Settings → Delete test orders, then switch to the live Stripe keys (`sk_live_…` and a live webhook). Share the link and a QR code on Facebook.

## Settings on the server (Render → Environment)

| Name | What it's for |
| --- | --- |
| `ADMIN_PASSWORD` | Admin sign-in. Changing it signs everyone out |
| `DATA_DIR` | Where the database and photos live (`/var/data` on Render) |
| `BASE_URL` | The app's public address, used in Stripe and email links |
| `STRIPE_SECRET_KEY` | Jess's Stripe secret key. Blank = test mode |
| `STRIPE_WEBHOOK_SECRET` | Signing secret for the Stripe webhook |
| `RESEND_API_KEY`, `EMAIL_FROM` | Order emails (optional) |
| `SESSION_SECRET` | Signs admin sign-ins (Render generates it) |

Everything Jess might change day to day is on the admin Settings tab instead.

## Still to do before launch

- Privacy notice and terms page (the app collects names, emails, phone numbers and addresses)
- Allergens and costs for every item (see The starter menu)
- Real photos to replace the clip art
- Check Render's disk snapshots and test a restore

## Files

```
src/server.js     routes and start-up
src/orders.js     menu, choices, placing orders, payment, order page
src/admin.js      admin: orders, menu, money, settings
src/clients.js    clients list, saved from paid orders
src/starter-menu.js  Jess's menu, loaded on first start
src/stripe.js     Stripe Checkout, webhooks, refunds, fees
src/email.js      confirmation and alert emails (Resend)
src/db.js         database tables, allergens list, default settings
public/           customer page, order page and admin page, logo and icons
public/clipart/   clip-art pictures for the menu
test/             end-to-end tests
```
