// Order page: shows payment status and the order details.
(() => {
  'use strict';
  const token = location.pathname.split('/').pop();
  const root = document.getElementById('receipt');
  const money = (p) => `£${(p / 100).toFixed(2)}`;

  function h(tag, attrs = {}, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') el.className = value;
      else if (key === 'text') el.textContent = value;
      else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
      else el.setAttribute(key, value === true ? '' : value);
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false) continue;
      el.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return el;
  }

  async function fetchOrder(path = `/api/orders/${encodeURIComponent(token)}`, options) {
    const res = await fetch(path, options);
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || 'We could not load this order.');
    return body;
  }

  function itemsBlock(o) {
    return h('div', { class: 'receipt-block' },
      h('h3', { text: 'Your bakes' }),
      h('ul', { class: 'lines' },
        o.items.map((i) =>
          h('li', { class: 'line' },
            h('span', { class: 'line-name', text: `${i.qty} × ${i.name}` }),
            h('span', { class: 'line-total', text: money(i.qty * i.price_pence) }),
            (i.options || i.note) && h('span', { class: 'line-options', text: [i.options, i.note && `Note: ${i.note}`].filter(Boolean).join('. ') }),
            h('span', {
              class: 'line-allergens',
              text: i.allergens === null ? 'Allergens: ask Jess' : i.allergens.length ? `Contains: ${i.allergens.join(', ')}` : 'Contains none of the 14 main allergens',
            }),
          ),
        ),
      ),
      h('div', { class: 'sums', style: 'margin-top:0.6rem' },
        o.delivery_pence > 0 && [h('span', { text: 'Delivery' }), h('span', { text: money(o.delivery_pence) })],
        h('span', { class: 'total', text: o.status === 'pending' ? 'To pay' : 'Paid' }),
        h('span', { class: 'total', text: money(o.total_pence) }),
      ),
    );
  }

  function whenBlock(o) {
    if (o.method === 'delivery') {
      return h('div', { class: 'receipt-block' },
        h('h3', { text: `Delivery on ${o.dateLabel}` }),
        o.timeWindow && h('p', { text: o.timeWindow }),
        h('p', { class: 'address', text: `${o.address}\n${o.postcode}` }),
        h('p', { text: 'Jess will message you with a delivery time.' }),
      );
    }
    return h('div', { class: 'receipt-block' },
      h('h3', { text: `Collect on ${o.dateLabel}` }),
      o.timeWindow && h('p', { text: o.timeWindow }),
      o.collectionAddress
        ? h('p', { class: 'address', text: o.collectionAddress })
        : h('p', { text: 'The collection address is shown here once your payment is confirmed.' }),
    );
  }

  function contactLine(o) {
    if (!o.contactPhone) return null;
    return h('p', {}, 'Need to change something? Message Jess on ', h('a', { href: `tel:${o.contactPhone.replace(/\s+/g, '')}`, text: o.contactPhone }), '.');
  }

  // Like append, but skips the empty slots left by conditions.
  const put = (...nodes) => root.append(...nodes.flat().filter((n) => n !== null && n !== undefined && n !== false));

  // Empty the shop basket once the order is paid for.
  function clearBasket() {
    try {
      localStorage.removeItem('vc-basket-v2');
      localStorage.removeItem('vc-basket');
    } catch {
      /* nothing to clear */
    }
  }
  // Stripe only sends customers here with ?paid=1 after a successful payment,
  // which can be a few seconds before the payment is confirmed to the app.
  if (new URLSearchParams(location.search).has('paid')) clearBasket();

  let polls = 0;
  function render(o) {
    root.replaceChildren();
    document.title = `Order ${o.ref} | Velvet Crumb`;

    if (['paid', 'ready', 'completed'].includes(o.status)) {
      clearBasket();
      put(
        h('h2', { text: `Thank you, ${o.firstName}. Your order is confirmed.` }),
        h('p', {}, 'Your order number is ', h('strong', { text: o.ref }), '. A receipt is on its way to your email.'),
        o.testMode && h('p', { class: 'notice notice-warn', text: 'Test mode: this order was not charged.' }),
        o.status === 'ready' && h('p', { class: 'notice notice-ok', text: 'Your order is baked and ready.' }),
        whenBlock(o),
        itemsBlock(o),
        h('p', { class: 'hint', style: 'color:var(--cocoa);font-size:var(--step--1)', text: o.allergenNotice }),
        contactLine(o),
        h('p', { class: 'foot-links' }, h('a', { href: '/', text: 'Back to the menu' }), h('a', { href: '/terms', text: 'Terms of sale' }), h('a', { href: '/privacy', text: 'Privacy notice' })),
      );
      return;
    }

    if (o.status === 'pending') {
      if (o.testMode) {
        put(
          h('h2', { text: 'Almost done' }),
          h('p', { class: 'notice notice-warn', text: 'Test mode: card payments are not switched on yet. Use the button below to pretend the payment went through.' }),
          h('button', {
            class: 'btn',
            type: 'button',
            onclick: async (e) => {
              const button = e.currentTarget;
              button.disabled = true;
              try {
                render(await fetchOrder(`/api/orders/${encodeURIComponent(token)}/test-pay`, { method: 'POST' }));
              } catch (err) {
                button.disabled = false;
                alertBox(err.message);
              }
            },
            text: `Mark ${money(o.total_pence)} as paid (test)`,
          }),
          whenBlock(o),
          itemsBlock(o),
        );
        return;
      }
      put(
        h('div', { class: 'spinner', role: 'status', 'aria-label': 'Checking payment' }),
        h('h2', { text: 'Confirming your payment' }),
        h('p', { text: 'This usually takes a few seconds. Keep this page open.' }),
      );
      if (polls < 20) {
        polls += 1;
        setTimeout(() => fetchOrder().then(render).catch(showError), 3000);
      } else {
        put(
          h('p', { class: 'notice notice-warn', text: 'We have not had confirmation from the card payment yet. If you paid, your confirmation email will follow shortly.' }),
          contactLine(o),
        );
      }
      return;
    }

    const messages = {
      expired: 'This order was not paid in time, so it has not been placed. Your basket is still saved.',
      cancelled: 'This order was cancelled.',
      refunded: 'This order was cancelled and refunded to your card. Refunds usually show within 5 to 10 working days.',
    };
    put(
      h('h2', { text: `Order ${o.ref}` }),
      h('p', { class: 'notice notice-bad', text: messages[o.status] || 'This order is not active.' }),
      contactLine(o),
      h('p', {}, h('a', { class: 'btn', href: o.status === 'expired' ? '/?basket=1' : '/', text: o.status === 'expired' ? 'Back to your basket' : 'Back to the menu' })),
    );
  }

  function alertBox(message) {
    root.prepend(h('p', { class: 'notice notice-bad', role: 'alert', text: message }));
  }

  function showError(err) {
    root.replaceChildren(
      h('h2', { text: 'Order not found' }),
      h('p', { text: err.message }),
      h('p', {}, h('a', { href: '/', text: 'Back to the menu' })),
    );
  }

  fetchOrder().then(render).catch(showError);
})();
