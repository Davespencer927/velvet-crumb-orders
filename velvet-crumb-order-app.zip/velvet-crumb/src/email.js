// Order emails through Resend. Switched off until RESEND_API_KEY and
// EMAIL_FROM are set; the app works without them.
import { config, emailEnabled } from './config.js';
import { longDate } from './dates.js';

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const money = (p) => `£${(p / 100).toFixed(2)}`;

export async function sendEmail({ to, subject, html, replyTo }) {
  if (!emailEnabled() || !to) return;
  const res = await fetch(`${config.resendApiBase}/emails`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${config.resendApiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: config.emailFrom, to: [to], subject, html, reply_to: replyTo || undefined }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`Resend returned ${res.status}: ${await res.text()}`);
}

function itemsTable(items) {
  const rows = items
    .map(
      (i) => `<tr><td style="padding:6px 0">${i.qty} × ${esc(i.name)}${
        i.options ? `<br><span style="font-size:14px">${esc(i.options)}</span>` : ''
      }${i.note ? `<br><span style="font-size:14px">Note: ${esc(i.note)}</span>` : ''}<br><span style="color:#7d6354;font-size:13px">${
        i.allergens === null
          ? 'Allergens: ask Jess'
          : i.allergens.length
            ? `Contains: ${esc(i.allergens.join(', '))}`
            : 'Contains none of the 14 main allergens'
      }</span></td><td style="padding:6px 0;text-align:right;vertical-align:top">${money(i.price_pence * i.qty)}</td></tr>`,
    )
    .join('');
  return `<table style="width:100%;border-collapse:collapse;font-size:15px">${rows}</table>`;
}

function fulfilment(order, settings) {
  if (order.method === 'delivery') {
    return `<p><strong>Delivery on ${esc(longDate(order.date))}${order.time_window ? `, ${esc(order.time_window)}` : ''}</strong><br>${esc(order.address)}<br>${esc(order.postcode)}</p>`;
  }
  const address = settings.collection_address
    ? `<br>${esc(settings.collection_address).replace(/\n/g, '<br>')}`
    : '';
  return `<p><strong>Collection on ${esc(longDate(order.date))}${order.time_window ? `, ${esc(order.time_window)}` : ''}</strong>${address}</p>`;
}

const PAYMENTS = { cash: 'cash', card_reader: 'card' };

function paidLine(order) {
  const due = order.to_pay_pence
    ? `To pay ${money(order.to_pay_pence)}${PAYMENTS[order.payment_method] ? ` by ${PAYMENTS[order.payment_method]}` : ''} on ${order.method === 'delivery' ? 'delivery' : 'collection'}`
    : `Paid ${money(order.total_pence)}`;
  return `<p style="text-align:right;font-size:17px"><strong>${due}</strong></p>`;
}

function sums(order) {
  return [
    order.discount_pence ? `<p style="text-align:right;margin:4px 0">Discount ${esc(order.discount_code)} −${money(order.discount_pence)}</p>` : '',
    order.delivery_pence ? `<p style="text-align:right;margin:4px 0">Delivery ${money(order.delivery_pence)}</p>` : '',
  ].join('');
}

const firstName = (order) => esc(order.name.split(' ')[0]);
const wrap = (inner) => `<div style="font-family:Georgia,serif;color:#3a2114;max-width:520px">${inner}</div>`;
const contact = (settings) => (settings.contact_phone ? `<p>Questions? Message Jess on ${esc(settings.contact_phone)}.</p>` : '');
const orderLink = (order, baseUrl) => `<p><a href="${esc(baseUrl)}/order/${esc(order.token)}" style="color:#57321d">View your order</a></p>`;

export async function sendOrderConfirmed(order, items, settings, baseUrl, { alertOwner = true } = {}) {
  const shop = settings.business_name;
  const customerHtml = `
    <div style="font-family:Georgia,serif;color:#3a2114;max-width:520px">
      <h1 style="font-size:24px;margin:0 0 12px">Thank you, ${esc(order.name.split(' ')[0])}</h1>
      <p>Your ${esc(shop)} order <strong>${esc(order.ref)}</strong> is confirmed${order.to_pay_pence ? '' : ' and paid'}.</p>
      ${fulfilment(order, settings)}
      ${itemsTable(items)}
      ${sums(order)}
      ${paidLine(order)}
      <p style="font-size:13px;color:#7d6354">${esc(settings.allergen_notice)}</p>
      <p><a href="${esc(baseUrl)}/order/${esc(order.token)}" style="color:#57321d">View your order</a></p>
      ${settings.contact_phone ? `<p>Questions? Message Jess on ${esc(settings.contact_phone)}.</p>` : ''}
    </div>`;

  const ownerHtml = `
    <div style="font-family:Arial,sans-serif;color:#3a2114">
      <h2 style="margin:0 0 8px">New order ${esc(order.ref)}: ${money(order.total_pence)}</h2>
      ${order.discount_code ? `<p>Discount code ${esc(order.discount_code)}: −${money(order.discount_pence)}</p>` : ''}
      <p><strong>${esc(order.name)}</strong><br>${esc(order.phone)}<br>${esc(order.email)}</p>
      <p>${order.method === 'delivery' ? 'Delivery' : 'Collection'} on ${esc(longDate(order.date))}
      ${order.method === 'delivery' ? `<br>${esc(order.address)}, ${esc(order.postcode)}` : ''}</p>
      ${itemsTable(items)}
      ${order.notes ? `<p><strong>Notes:</strong> ${esc(order.notes)}</p>` : ''}
      <p><a href="${esc(baseUrl)}/admin">Open the admin page</a></p>
    </div>`;

  await Promise.allSettled([
    sendEmail({ to: order.email, subject: `Your ${shop} order ${order.ref}`, html: customerHtml, replyTo: settings.owner_email }),
    alertOwner ? sendEmail({ to: settings.owner_email, subject: `New order ${order.ref} for ${longDate(order.date)}`, html: ownerHtml }) : null,
  ]).then((results) => {
    for (const r of results) if (r.status === 'rejected') console.error('Email failed:', r.reason.message);
  });
}

export async function sendOrderRefunded(order, settings) {
  const html = `
    <div style="font-family:Georgia,serif;color:#3a2114;max-width:520px">
      <p>Hi ${esc(order.name.split(' ')[0])},</p>
      <p>Your ${esc(settings.business_name)} order <strong>${esc(order.ref)}</strong> for ${esc(longDate(order.date))} has been cancelled
      and ${money(order.total_pence)} refunded to your card. Refunds usually show within 5 to 10 working days.</p>
      ${settings.contact_phone ? `<p>Questions? Message Jess on ${esc(settings.contact_phone)}.</p>` : ''}
    </div>`;
  try {
    await sendEmail({ to: order.email, subject: `Order ${order.ref} cancelled and refunded`, html, replyTo: settings.owner_email });
  } catch (err) {
    console.error('Email failed:', err.message);
  }
}

// ---------- Updates to the customer ----------

// kind: 'ready' (collection), 'out' (delivery on its way), 'reminder' (day before), 'thanks' (after).
export function statusEmail(kind, order, items, settings, baseUrl) {
  const shop = esc(settings.business_name);
  const when = order.time_window ? `, ${esc(order.time_window)}` : '';
  const review = /^https:\/\//.test(settings.review_url || '') ? settings.review_url : /^https:\/\//.test(settings.facebook_url || '') ? settings.facebook_url : '';
  const due = order.to_pay_pence ? paidLine(order) : '';
  switch (kind) {
    case 'ready':
      return {
        subject: `Your ${settings.business_name} order is ready to collect`,
        html: wrap(`
          <h1 style="font-size:24px;margin:0 0 12px">It's ready, ${firstName(order)}</h1>
          <p>Your order <strong>${esc(order.ref)}</strong> is baked, boxed and ready to collect.</p>
          ${fulfilment(order, settings)}
          ${due}
          ${orderLink(order, baseUrl)}
          ${contact(settings)}`),
      };
    case 'out':
      return {
        subject: `Your ${settings.business_name} order is on its way`,
        html: wrap(`
          <h1 style="font-size:24px;margin:0 0 12px">On its way, ${firstName(order)}</h1>
          <p>Jess is out delivering your order <strong>${esc(order.ref)}</strong> now.</p>
          <p>${esc(order.address)}<br>${esc(order.postcode)}</p>
          ${due}
          ${contact(settings)}`),
      };
    case 'reminder':
      return {
        subject: order.method === 'delivery' ? `Your ${settings.business_name} delivery is tomorrow` : `See you tomorrow: your ${settings.business_name} collection`,
        html: wrap(`
          <h1 style="font-size:24px;margin:0 0 12px">See you tomorrow, ${firstName(order)}</h1>
          <p>A reminder about your order <strong>${esc(order.ref)}</strong>.</p>
          ${fulfilment(order, settings)}
          ${itemsTable(items)}
          ${due}
          ${orderLink(order, baseUrl)}
          ${contact(settings)}`),
      };
    case 'thanks':
      return {
        subject: `Thank you from ${settings.business_name}`,
        html: wrap(`
          <h1 style="font-size:24px;margin:0 0 12px">Thank you, ${firstName(order)}</h1>
          <p>Thank you for ordering from ${shop}. We hope you enjoyed every crumb.</p>
          ${review ? `<p>If you did, a review would mean a lot to a small home bakery: <a href="${esc(review)}" style="color:#57321d">leave a review</a>.</p>` : ''}
          ${settings.instagram ? `<p>Share a picture and tag <a href="https://www.instagram.com/${encodeURIComponent(settings.instagram)}/" style="color:#57321d">@${esc(settings.instagram)}</a>.</p>` : ''}
          <p><a href="${esc(baseUrl)}/" style="color:#57321d">Order again</a></p>`),
      };
    default:
      return null;
  }
}

export async function sendStatusEmail(kind, order, items, settings, baseUrl) {
  const mail = statusEmail(kind, order, items, settings, baseUrl);
  if (!mail || !order.email) return false;
  await sendEmail({ to: order.email, subject: mail.subject, html: mail.html, replyTo: settings.owner_email });
  return true;
}

// Settings → Send a test email. Throws with a plain reason if it can't send.
export async function sendTestEmail(settings) {
  if (!emailEnabled()) throw new Error('Emails are not set up yet. Add RESEND_API_KEY and EMAIL_FROM in Fly.io → Secrets, then Deploy secrets.');
  if (!settings.owner_email) throw new Error('Add your email address for order alerts first, then save settings.');
  await sendEmail({
    to: settings.owner_email,
    subject: `Test email from the ${settings.business_name} app`,
    html: wrap('<p>This is a test. Emails from the order app are working.</p>'),
  });
  return settings.owner_email;
}
