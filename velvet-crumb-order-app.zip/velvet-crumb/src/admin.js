// Admin API: orders, menu, money and settings. Every route here is behind
// the admin sign-in (checked in server.js).
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { stripeEnabled, emailEnabled } from './config.js';
import {
  db,
  uploadsDir,
  getSettings,
  saveSettings,
  DEFAULT_SETTINGS,
  ALLERGENS,
  EXPENSE_CATEGORIES,
  nowIso,
  parseList,
  transaction,
} from './db.js';
import { ukDate, isIsoDate, longDate, addDays, scheduleIsSet } from './dates.js';
import { HttpError, text, pence } from './http.js';
import { ACTIVE_STATUSES, orderItems, cancelOrder } from './orders.js';
import { DEFAULT_PRIVACY, DEFAULT_TERMS } from './legal.js';

// ---------- Orders ----------

export function listOrders(view) {
  const today = ukDate();
  const queries = {
    upcoming: [`status IN ('paid', 'ready') AND date >= ? ORDER BY date, paid_at`, [addDays(today, -7)]],
    past: [`status = 'completed' OR (status IN ('paid', 'ready') AND date < ?) ORDER BY date DESC, paid_at DESC LIMIT 200`, [addDays(today, -7)]],
    cancelled: [`status IN ('refunded', 'cancelled') ORDER BY updated_at DESC LIMIT 200`, []],
    unpaid: [`status IN ('pending', 'expired') ORDER BY created_at DESC LIMIT 100`, []],
  };
  const [where, params] = queries[view] || queries.upcoming;
  const orders = db.prepare(`SELECT * FROM orders WHERE ${where}`).all(...params);
  return orders.map((o) => adminOrder(o));
}

function adminOrder(o) {
  return {
    id: o.id,
    ref: o.ref,
    status: o.status,
    name: o.name,
    email: o.email,
    phone: o.phone,
    method: o.method,
    date: o.date,
    dateLabel: longDate(o.date),
    address: o.address,
    postcode: o.postcode,
    notes: o.notes,
    subtotal_pence: o.subtotal_pence,
    delivery_pence: o.delivery_pence,
    total_pence: o.total_pence,
    payment_method: o.payment_method,
    time_window: o.time_window,
    client_id: o.client_id,
    paid_at: o.paid_at,
    created_at: o.created_at,
    items: orderItems(o.id).map((i) => ({ name: i.name, options: i.options, note: i.note, qty: i.qty, price_pence: i.price_pence })),
  };
}

const STATUS_MOVES = {
  paid: ['ready', 'completed'],
  ready: ['paid', 'completed'],
  completed: ['ready'],
};

export function setOrderStatus(id, status) {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!order) throw new HttpError(404, 'Order not found.');
  if (!(STATUS_MOVES[order.status] || []).includes(status)) {
    throw new HttpError(409, `An order that is ${order.status} cannot be marked ${status}.`);
  }
  db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(status, nowIso(), id);
  return adminOrder(db.prepare('SELECT * FROM orders WHERE id = ?').get(id));
}

export async function cancelAndRefund(id) {
  return adminOrder(await cancelOrder(id));
}

export function orderCounts() {
  const today = ukDate();
  const row = db
    .prepare(
      `SELECT
         SUM(CASE WHEN status = 'paid' AND date >= ? THEN 1 ELSE 0 END) AS to_bake,
         SUM(CASE WHEN status IN ('paid', 'ready') AND date = ? THEN 1 ELSE 0 END) AS today
       FROM orders`,
    )
    .get(addDays(today, -7), today);
  return { toBake: row.to_bake || 0, today: row.today || 0, scheduleSet: scheduleIsSet(getSettings().schedule) };
}

// What needs baking: item totals for each upcoming date.
export function bakeList() {
  const today = ukDate();
  return db
    .prepare(
      `SELECT o.date, i.name, i.options, SUM(i.qty) AS qty
       FROM order_items i JOIN orders o ON o.id = i.order_id
       WHERE o.status = 'paid' AND o.date >= ?
       GROUP BY o.date, i.name, i.options ORDER BY o.date, i.name, i.options`,
    )
    .all(addDays(today, -7))
    .map((r) => ({ ...r, dateLabel: longDate(r.date) }));
}

// ---------- Menu ----------

function adminProduct(p) {
  return {
    ...p,
    allergens: parseList(p.allergens),
    allergens_set: Boolean(p.allergens_set),
    options: parseList(p.options),
    note_required: Boolean(p.note_required),
  };
}

// Choices customers make, e.g. Base: brownie or blondie; Box type: classic, mix or loaded.
function optionGroups(raw) {
  const groups = Array.isArray(raw) ? raw.slice(0, 8) : [];
  return groups.map((g) => {
    const name = text(g?.name, 40);
    if (!name) throw new HttpError(400, 'Give every set of choices a name, e.g. Topping.');
    const seen = new Set();
    const choices = (Array.isArray(g.choices) ? g.choices.slice(0, 60) : [])
      .map((c) => ({ name: text(c?.name, 60), price_pence: pence(c?.price_pence ?? 0), cost_pence: pence(c?.cost_pence ?? 0) }))
      .filter((c) => c.name);
    for (const c of choices) {
      if (c.price_pence === null || c.cost_pence === null) throw new HttpError(400, `Check the prices in ${name}: use £0 or more.`);
      if (seen.has(c.name)) throw new HttpError(400, `${name} has "${c.name}" twice.`);
      seen.add(c.name);
    }
    if (!choices.length) throw new HttpError(400, `Add at least one choice to ${name}, or remove it.`);
    const type = g.type === 'many' ? 'many' : 'one';
    const max = type === 'one' ? 1 : Math.min(choices.length, Math.max(1, Number.parseInt(g.max, 10) || choices.length));
    return { name, type, required: Boolean(g.required), max, choices };
  }).filter((g, i, all) => {
    if (all.findIndex((x) => x.name === g.name) !== i) throw new HttpError(400, `There are two sets of choices called ${g.name}.`);
    return true;
  });
}

export function listProducts() {
  return db.prepare('SELECT * FROM products ORDER BY sort, id').all().map(adminProduct);
}

function productFields(body) {
  const name = text(body.name, 80);
  if (!name) throw new HttpError(400, 'Give the item a name.');
  const price = pence(body.price_pence);
  if (!price) throw new HttpError(400, 'Set a price above £0.');
  const cost = pence(body.cost_pence ?? 0);
  if (cost === null) throw new HttpError(400, 'The cost to make must be £0 or more.');
  const status = ['on', 'soon', 'soldout', 'hidden'].includes(body.status) ? body.status : 'on';
  const was = pence(body.was_price_pence ?? 0);
  if (was === null) throw new HttpError(400, 'The "was" price must be £0 or more.');
  if (was && was <= price) throw new HttpError(400, 'The "was" price must be higher than the price, or blank.');
  const allergens = (Array.isArray(body.allergens) ? body.allergens : []).filter((a) => ALLERGENS.includes(a));
  const image = String(body.image || '');
  if (image && !/^\/uploads\/[a-f0-9]{24}\.(jpg|png|webp)$/.test(image) && !/^\/clipart\/[a-z0-9-]+\.svg$/.test(image)) {
    throw new HttpError(400, 'That photo could not be used.');
  }
  const noteLabel = text(body.note_label, 120);
  return {
    name,
    description: text(body.description, 400),
    category: text(body.category, 40),
    price_pence: price,
    cost_pence: cost,
    allergens: JSON.stringify(allergens),
    // Set once Jess has ticked allergens, or confirmed the item has none.
    allergens_set: allergens.length > 0 || body.allergens_none === true ? 1 : 0,
    image,
    status,
    badge: text(body.badge, 30),
    was_price_pence: was,
    options: JSON.stringify(optionGroups(body.options)),
    note_label: noteLabel,
    note_required: noteLabel && body.note_required ? 1 : 0,
  };
}

export function createProduct(body) {
  const fields = productFields(body);
  const nextSort = (db.prepare('SELECT MAX(sort) AS m FROM products').get().m ?? 0) + 1;
  const row = { ...fields, sort: nextSort, created_at: nowIso() };
  const cols = Object.keys(row);
  const { lastInsertRowid } = db
    .prepare(`INSERT INTO products (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`)
    .run(...Object.values(row));
  return adminProduct(db.prepare('SELECT * FROM products WHERE id = ?').get(lastInsertRowid));
}

export function updateProduct(id, body) {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!existing) throw new HttpError(404, 'Item not found.');
  const fields = productFields(body);
  const sets = Object.keys(fields).map((k) => `${k} = ?`).join(', ');
  db.prepare(`UPDATE products SET ${sets} WHERE id = ?`).run(...Object.values(fields), id);
  if (existing.image && existing.image !== fields.image) removeImageIfUnused(existing.image);
  return adminProduct(db.prepare('SELECT * FROM products WHERE id = ?').get(id));
}

export function deleteProduct(id) {
  const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!existing) throw new HttpError(404, 'Item not found.');
  db.prepare('DELETE FROM products WHERE id = ?').run(id);
  if (existing.image) removeImageIfUnused(existing.image);
}

export function reorderProducts(ids) {
  if (!Array.isArray(ids)) throw new HttpError(400, 'Send the item order as a list.');
  transaction(() => {
    const stmt = db.prepare('UPDATE products SET sort = ? WHERE id = ?');
    ids.forEach((id, index) => stmt.run(index + 1, Number(id)));
  });
  return listProducts();
}

function removeImageIfUnused(image) {
  if (!image.startsWith('/uploads/')) return;
  const inUse = db.prepare('SELECT 1 FROM products WHERE image = ?').get(image);
  if (inUse) return;
  const file = path.join(uploadsDir, path.basename(image));
  fs.rm(file, { force: true }, () => {});
}

const IMAGE_TYPES = {
  'image/jpeg': { ext: 'jpg', magic: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  'image/png': { ext: 'png', magic: (b) => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  'image/webp': { ext: 'webp', magic: (b) => b.subarray(0, 4).toString() === 'RIFF' && b.subarray(8, 12).toString() === 'WEBP' },
};

export function saveUpload(body) {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(body.dataUrl || ''));
  if (!match) throw new HttpError(400, 'Upload a JPEG, PNG or WebP photo.');
  const type = IMAGE_TYPES[match[1]];
  const buffer = Buffer.from(match[2], 'base64');
  if (buffer.length > 4 * 1024 * 1024) throw new HttpError(413, 'That photo is over 4 MB. Try a smaller one.');
  if (!type.magic(buffer)) throw new HttpError(400, 'That file is not a photo the app can use.');
  const name = `${crypto.randomBytes(12).toString('hex')}.${type.ext}`;
  fs.writeFileSync(path.join(uploadsDir, name), buffer);
  return { image: `/uploads/${name}` };
}

// ---------- Money ----------

function range(from, to) {
  if (!isIsoDate(from) || !isIsoDate(to) || from > to) throw new HttpError(400, 'Choose a valid date range.');
  return [from, to];
}

export function finance(fromRaw, toRaw) {
  const [from, to] = range(fromRaw, toRaw);
  const active = ACTIVE_STATUSES.map((s) => `'${s}'`).join(',');

  const sales = db
    .prepare(
      `SELECT COUNT(*) AS orders, COALESCE(SUM(total_pence), 0) AS sales, COALESCE(SUM(subtotal_pence), 0) AS bakes,
              COALESCE(SUM(delivery_pence), 0) AS delivery, COALESCE(SUM(cost_pence), 0) AS cost
       FROM orders WHERE status IN (${active}) AND paid_date BETWEEN ? AND ?`,
    )
    .get(from, to);

  // Card fees are kept by Stripe even when an order is refunded.
  const fees = db
    .prepare(
      `SELECT COALESCE(SUM(fee_pence), 0) AS fees FROM orders
       WHERE status IN (${active}, 'refunded') AND paid_date BETWEEN ? AND ?`,
    )
    .get(from, to).fees;

  const refunds = db
    .prepare(
      `SELECT COUNT(*) AS n, COALESCE(SUM(total_pence), 0) AS amount FROM orders
       WHERE status = 'refunded' AND paid_date BETWEEN ? AND ?`,
    )
    .get(from, to);

  const expensesByCategory = db
    .prepare(
      `SELECT category, COALESCE(SUM(amount_pence), 0) AS amount FROM expenses
       WHERE date BETWEEN ? AND ? GROUP BY category ORDER BY amount DESC`,
    )
    .all(from, to);
  const expenses = expensesByCategory.reduce((s, r) => s + r.amount, 0);

  const bestSellers = db
    .prepare(
      `SELECT i.name, SUM(i.qty) AS qty, SUM(i.qty * i.price_pence) AS sales, SUM(i.qty * i.cost_pence) AS cost
       FROM order_items i JOIN orders o ON o.id = i.order_id
       WHERE o.status IN (${active}) AND o.paid_date BETWEEN ? AND ?
       GROUP BY i.name ORDER BY qty DESC, sales DESC LIMIT 10`,
    )
    .all(from, to);

  // Month by month, for the chosen range.
  const monthlySales = db
    .prepare(
      `SELECT substr(paid_date, 1, 7) AS month, COALESCE(SUM(total_pence), 0) AS sales, COALESCE(SUM(cost_pence), 0) AS cost
       FROM orders WHERE status IN (${active}) AND paid_date BETWEEN ? AND ? GROUP BY month`,
    )
    .all(from, to);
  const monthlyFees = db
    .prepare(
      `SELECT substr(paid_date, 1, 7) AS month, COALESCE(SUM(fee_pence), 0) AS fees
       FROM orders WHERE status IN (${active}, 'refunded') AND paid_date BETWEEN ? AND ? GROUP BY month`,
    )
    .all(from, to);
  const monthlyExpenses = db
    .prepare(
      `SELECT substr(date, 1, 7) AS month, COALESCE(SUM(amount_pence), 0) AS expenses
       FROM expenses WHERE date BETWEEN ? AND ? GROUP BY month`,
    )
    .all(from, to);
  const months = new Map();
  const month = (m) => {
    if (!months.has(m)) months.set(m, { month: m, sales: 0, cost: 0, fees: 0, expenses: 0 });
    return months.get(m);
  };
  monthlySales.forEach((r) => Object.assign(month(r.month), { sales: r.sales, cost: r.cost }));
  monthlyFees.forEach((r) => (month(r.month).fees = r.fees));
  monthlyExpenses.forEach((r) => (month(r.month).expenses = r.expenses));
  const byMonth = [...months.values()]
    .sort((a, b) => a.month.localeCompare(b.month))
    .map((m) => ({ ...m, profit: m.sales - m.cost - m.fees - m.expenses }));

  const itemsWithoutCost = db.prepare("SELECT COUNT(*) AS n FROM products WHERE cost_pence = 0 AND status != 'hidden'").get().n;
  const testOrders = db
    .prepare(`SELECT COUNT(*) AS n FROM orders WHERE payment_method = 'test' AND status IN (${active}) AND paid_date BETWEEN ? AND ?`)
    .get(from, to).n;

  return {
    from,
    to,
    orders: sales.orders,
    sales: sales.sales,
    bakes: sales.bakes,
    delivery: sales.delivery,
    cost: sales.cost,
    fees,
    expenses,
    expensesByCategory,
    profit: sales.sales - sales.cost - fees - expenses,
    refunds,
    bestSellers,
    byMonth,
    itemsWithoutCost,
    testOrders,
  };
}

export function listExpenses(fromRaw, toRaw) {
  const [from, to] = range(fromRaw, toRaw);
  return db.prepare('SELECT * FROM expenses WHERE date BETWEEN ? AND ? ORDER BY date DESC, id DESC').all(from, to);
}

export function addExpense(body) {
  const date = String(body.date || '');
  if (!isIsoDate(date)) throw new HttpError(400, 'Choose the date you paid.');
  const category = EXPENSE_CATEGORIES.includes(body.category) ? body.category : 'Other';
  const amount = pence(body.amount_pence);
  if (!amount) throw new HttpError(400, 'Enter an amount above £0.');
  const { lastInsertRowid } = db
    .prepare('INSERT INTO expenses (date, category, description, amount_pence, created_at) VALUES (?,?,?,?,?)')
    .run(date, category, text(body.description, 200), amount, nowIso());
  return db.prepare('SELECT * FROM expenses WHERE id = ?').get(lastInsertRowid);
}

export function deleteExpense(id) {
  const { changes } = db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
  if (!changes) throw new HttpError(404, 'Cost not found.');
}

const csvCell = (value) => {
  let s = String(value ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // stop spreadsheets running it as a formula
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const csv = (rows) => rows.map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
const pounds = (p) => (p / 100).toFixed(2);

export function ordersCsv(fromRaw, toRaw) {
  const [from, to] = range(fromRaw, toRaw);
  const rows = db
    .prepare(
      `SELECT * FROM orders WHERE paid_date BETWEEN ? AND ? AND status IN ('paid','ready','completed','refunded') ORDER BY paid_at`,
    )
    .all(from, to);
  return csv([
    ['Ref', 'Paid on', 'Status', 'Customer', 'Method', 'For date', 'Items', 'Bakes £', 'Delivery £', 'Total £', 'Cost to make £', 'Card fee £', 'Payment'],
    ...rows.map((o) => [
      o.ref,
      o.paid_date,
      o.status,
      o.name,
      o.method,
      o.date,
      orderItems(o.id).map((i) => `${i.qty} x ${i.name}${i.options ? ` (${i.options})` : ''}`).join('; '),
      pounds(o.subtotal_pence),
      pounds(o.delivery_pence),
      pounds(o.total_pence),
      pounds(o.cost_pence),
      pounds(o.fee_pence),
      o.payment_method === 'test' ? 'Test' : 'Stripe',
    ]),
  ]);
}

export function clientsCsv(rows) {
  return csv([['Name', 'Email', 'Phone', 'Address', 'Postcode', 'Orders', 'Spent £', 'Last order', 'How added', 'Notes'], ...rows]);
}

export function expensesCsv(fromRaw, toRaw) {
  return csv([
    ['Date', 'Category', 'Description', 'Amount £'],
    ...listExpenses(fromRaw, toRaw).map((e) => [e.date, e.category, e.description, pounds(e.amount_pence)]),
  ]);
}

// ---------- Settings ----------

export function adminSettings() {
  return {
    settings: getSettings(),
    allergens: ALLERGENS,
    expenseCategories: EXPENSE_CATEGORIES,
    status: { stripe: stripeEnabled(), email: emailEnabled() },
    legalDefaults: { privacy: DEFAULT_PRIVACY, terms: DEFAULT_TERMS },
  };
}

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

function scheduleFrom(raw, current) {
  const out = {};
  for (let d = 0; d <= 6; d += 1) {
    const day = raw?.[d] || raw?.[String(d)] || current[d];
    out[d] = {};
    for (const kind of ['collect', 'deliver']) {
      const slot = day?.[kind] || current[d][kind];
      const from = String(slot.from || '');
      const to = String(slot.to || '');
      if (!TIME_RE.test(from) || !TIME_RE.test(to)) throw new HttpError(400, 'Use times like 10:00 and 16:30.');
      if (slot.on && from >= to) throw new HttpError(400, 'Each closing time must be after the opening time.');
      out[d][kind] = { on: Boolean(slot.on), from, to };
    }
  }
  return out;
}

export function updateSettings(body) {
  const current = getSettings();
  const next = { ...current };
  const textFields = {
    business_name: 60,
    tagline: 140,
    closed_message: 200,
    owner_email: 200,
    contact_email: 200,
    contact_phone: 30,
    privacy_text: 20000,
    terms_text: 20000,
    instagram: 40,
    facebook_url: 200,
    collection_area: 200,
    collection_address: 300,
    delivery_postcodes: 300,
    delivery_note: 200,
    allergen_notice: 600,
  };
  for (const [key, max] of Object.entries(textFields)) {
    if (key in body) next[key] = text(body[key], max);
  }
  next.instagram = next.instagram.replace(/^@/, '');
  if (next.facebook_url && !/^https:\/\//.test(next.facebook_url)) throw new HttpError(400, 'The Facebook link must start with https://');
  if ('shop_open' in body) next.shop_open = Boolean(body.shop_open);
  if ('schedule' in body) next.schedule = scheduleFrom(body.schedule, current.schedule);
  const whole = (key, min, max) => {
    if (!(key in body)) return;
    const n = Number(body[key]);
    if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, `${key.replace(/_/g, ' ')} must be a whole number from ${min} to ${max}.`);
    next[key] = n;
  };
  whole('lead_days', 0, 30);
  whole('booking_window_days', 1, 120);
  whole('daily_order_cap', 0, 500);
  whole('min_order_pence', 0, 100_000);
  whole('delivery_fee_pence', 0, 10_000);
  whole('delivery_free_over_pence', 0, 100_000);
  whole('stripe_fee_fixed_pence', 0, 200);
  if ('stripe_fee_percent' in body) {
    const n = Number(body.stripe_fee_percent);
    if (!Number.isFinite(n) || n < 0 || n > 10) throw new HttpError(400, 'Card fee percent must be from 0 to 10.');
    next.stripe_fee_percent = n;
  }
  if ('notices' in body) {
    const list = Array.isArray(body.notices) ? body.notices : [];
    if (list.length > 6) throw new HttpError(400, 'Keep it to 6 notices or fewer.');
    next.notices = list
      .map((n) => ({ title: text(n?.title, 40), text: text(n?.text, 300), show: Boolean(n?.show) }))
      .filter((n) => n.title || n.text);
  }
  if ('blocked_dates' in body) {
    const dates = (Array.isArray(body.blocked_dates) ? body.blocked_dates : []).filter(isIsoDate);
    next.blocked_dates = [...new Set(dates)].filter((d) => d >= addDays(ukDate(), -1)).sort();
  }
  if (next.owner_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.owner_email)) {
    throw new HttpError(400, 'Enter a valid email for order alerts.');
  }
  if (next.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(next.contact_email)) {
    throw new HttpError(400, 'Enter a valid email for customer questions.');
  }
  // Saving the standard wording unchanged keeps following future updates to it.
  if (next.privacy_text.trim() === DEFAULT_PRIVACY.trim()) next.privacy_text = '';
  if (next.terms_text.trim() === DEFAULT_TERMS.trim()) next.terms_text = '';
  next.starter_menu_loaded = current.starter_menu_loaded;
  for (const key of Object.keys(next)) if (!(key in DEFAULT_SETTINGS)) delete next[key];
  return saveSettings(next);
}

export function deleteTestOrders() {
  const { changes } = db
    .prepare("DELETE FROM orders WHERE payment_method = 'test' OR status = 'expired' OR (status = 'cancelled' AND paid_at IS NULL)")
    .run();
  return { deleted: changes };
}
