// All settings that come from the server environment (Render → Environment).
// Shop settings Jess can change herself (prices, dates, delivery fee…) live in
// the database and are edited on the admin Settings tab instead.
import { fileURLToPath } from 'node:url';

const env = process.env;

export const config = {
  port: Number(env.PORT) || 3000,
  dataDir: env.DATA_DIR || fileURLToPath(new URL('../data', import.meta.url)),
  baseUrl: (env.BASE_URL || '').replace(/\/+$/, ''),
  adminPassword: env.ADMIN_PASSWORD || '',
  sessionSecret: env.SESSION_SECRET || '',

  stripeSecretKey: env.STRIPE_SECRET_KEY || '',
  stripeWebhookSecret: env.STRIPE_WEBHOOK_SECRET || '',
  stripeApiBase: env.STRIPE_API_BASE || 'https://api.stripe.com',

  resendApiKey: env.RESEND_API_KEY || '',
  resendApiBase: env.RESEND_API_BASE || 'https://api.resend.com',
  emailFrom: env.EMAIL_FROM || '',

  // Stripe's minimum checkout lifetime is 30 minutes.
  checkoutHoldMinutes: 31,
  maxQtyPerItem: 50,
};

export const stripeEnabled = () => Boolean(config.stripeSecretKey);
export const emailEnabled = () => Boolean(config.resendApiKey && config.emailFrom);
