// Emails sent without Jess doing anything: the reminder the day before and
// the thank you after. Run every few minutes from server.js.
import { config, emailEnabled } from './config.js';
import { db, getSettings } from './db.js';
import { ukDate, addDays } from './dates.js';
import { orderItems } from './orders.js';
import { sendStatusEmail } from './email.js';

const HOUR = 3_600_000;

export function ukHour(now = Date.now()) {
  return Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hourCycle: 'h23', timeZone: 'Europe/London' }).format(new Date(now)));
}

async function sendEach(rows, kind, column, now, settings, baseUrl) {
  let sent = 0;
  for (const o of rows) {
    // Claim the order first so a slow or failed send is never repeated.
    const claimed = db.prepare(`UPDATE orders SET ${column} = ? WHERE id = ? AND ${column} IS NULL`).run(new Date(now).toISOString(), o.id);
    if (claimed.changes !== 1) continue;
    try {
      if (await sendStatusEmail(kind, o, orderItems(o.id), settings, baseUrl)) sent += 1;
    } catch (err) {
      console.error(`Could not send the ${kind} email for ${o.ref}:`, err.message);
    }
  }
  return sent;
}

export async function sendScheduledEmails(now = Date.now(), baseUrl = config.baseUrl) {
  const result = { reminders: 0, thanks: 0 };
  if (!emailEnabled()) return result;
  const settings = getSettings();
  const hour = ukHour(now);
  const iso = (ms) => new Date(ms).toISOString();

  // Reminders: from 10am the day before, for orders placed at least 6 hours earlier.
  if (settings.email_reminder && hour >= 10 && hour < 21) {
    const tomorrow = addDays(ukDate(new Date(now)), 1);
    const rows = db
      .prepare(
        `SELECT * FROM orders WHERE status IN ('paid', 'ready') AND date = ? AND email != ''
         AND reminder_sent_at IS NULL AND created_at < ?`,
      )
      .all(tomorrow, iso(now - 6 * HOUR));
    result.reminders = await sendEach(rows, 'reminder', 'reminder_sent_at', now, settings, baseUrl);
  }

  // Thank you: about 2 hours after Jess marks it collected or delivered, in the daytime.
  if (settings.email_thanks && hour >= 9 && hour < 21) {
    const rows = db
      .prepare(
        `SELECT * FROM orders WHERE status = 'completed' AND email != '' AND thanks_sent_at IS NULL
         AND completed_at <= ? AND completed_at >= ?`,
      )
      .all(iso(now - 2 * HOUR), iso(now - 72 * HOUR));
    result.thanks = await sendEach(rows, 'thanks', 'thanks_sent_at', now, settings, baseUrl);
  }
  return result;
}
