import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { config, stripeEnabled, emailEnabled } from './config.js';
import { uploadsDir } from './db.js';
import { HttpError, json, send, readBody, readJson, serveFile, baseUrlFor } from './http.js';
import { checkPassword, clearCookie, isAdmin, loginAllowed, loginSucceeded, passwordConfigured, rateLimit, sessionCookie } from './auth.js';
import { shopData, placeOrder, orderForCustomer, testPay, handleStripeEvent, housekeeping } from './orders.js';
import { checkCode, listDiscounts, createDiscount, updateDiscount, deleteDiscount } from './discounts.js';
import { sendScheduledEmails } from './messages.js';
import { sendTestEmail } from './email.js';
import { legalPage } from './legal.js';
import { getSettings } from './db.js';
import { verifyWebhookSignature } from './stripe.js';
import * as admin from './admin.js';
import * as clients from './clients.js';
import { loadStarterMenu, migrateBoxes, addLoadedBuilder } from './starter-menu.js';

const publicDir = fileURLToPath(new URL('../public', import.meta.url));

const routes = [];
const route = (method, pattern, handler, { adminOnly = false } = {}) => {
  const keys = [];
  const regex = new RegExp(
    '^' + pattern.replace(/\./g, '\\.').replace(/:(\w+)/g, (_, k) => (keys.push(k), '([^/]+)')) + '$',
  );
  routes.push({ method, regex, keys, handler, adminOnly });
};

// ---------- Customer API ----------

route('GET', '/api/shop', (req, res) => json(res, 200, { ...shopData(), jess: isAdmin(req) }));

route('POST', '/api/orders', async (req, res) => {
  const body = await readJson(req, 50_000);
  const hand = body.hand === true;
  if (hand && !isAdmin(req)) throw new HttpError(401, 'Sign in to the admin page again to add orders.');
  json(res, 201, await placeOrder(body, baseUrlFor(req, config.baseUrl), { hand }));
});

route('POST', '/api/discount', async (req, res) => {
  if (!rateLimit(req, 'discount', 30, 10 * 60_000)) throw new HttpError(429, 'Too many tries. Wait a few minutes and try again.');
  json(res, 200, checkCode(await readJson(req, 1_000)));
});

route('GET', '/api/orders/:token', async (req, res, { token }) => {
  json(res, 200, await orderForCustomer(token, baseUrlFor(req, config.baseUrl)));
});

route('POST', '/api/orders/:token/test-pay', async (req, res, { token }) => {
  testPay(token);
  json(res, 200, await orderForCustomer(token, baseUrlFor(req, config.baseUrl)));
});

route('POST', '/api/stripe/webhook', async (req, res) => {
  const raw = (await readBody(req, 1_000_000)).toString('utf8');
  if (!verifyWebhookSignature(raw, req.headers['stripe-signature'], config.stripeWebhookSecret)) {
    return json(res, 400, { error: 'Invalid signature' });
  }
  let event;
  try {
    event = JSON.parse(raw);
  } catch {
    return json(res, 400, { error: 'Invalid JSON' });
  }
  handleStripeEvent(event, baseUrlFor(req, config.baseUrl));
  json(res, 200, { received: true });
});

// ---------- Admin sign-in ----------

route('GET', '/api/admin/session', (req, res) =>
  json(res, 200, { signedIn: isAdmin(req), passwordSet: passwordConfigured() }),
);

route('POST', '/api/admin/login', async (req, res) => {
  const body = await readJson(req, 2_000);
  if (!passwordConfigured()) throw new HttpError(503, 'The admin password has not been set up yet. Add the ADMIN_PASSWORD secret in Fly.io.');
  if (!loginAllowed(req)) throw new HttpError(429, 'Too many tries. Wait 15 minutes and try again.');
  if (!checkPassword(body.password)) throw new HttpError(401, 'That password is not right.');
  loginSucceeded(req);
  json(res, 200, { signedIn: true }, { 'Set-Cookie': sessionCookie(req) });
});

route('POST', '/api/admin/logout', (req, res) => json(res, 200, { signedIn: false }, { 'Set-Cookie': clearCookie() }));

// ---------- Admin API ----------

const A = { adminOnly: true };
const q = (req) => new URL(req.url, 'http://x').searchParams;

route('GET', '/api/admin/overview', (req, res) => json(res, 200, { counts: admin.orderCounts(), stripe: stripeEnabled(), email: emailEnabled() }), A);
route('GET', '/api/admin/orders', (req, res) => json(res, 200, { orders: admin.listOrders(q(req).get('view')) }), A);
route('GET', '/api/admin/bake-list', (req, res) => json(res, 200, { rows: admin.bakeList() }), A);
route('POST', '/api/admin/orders/:id/status', async (req, res, { id }) => {
  const body = await readJson(req, 1_000);
  json(res, 200, admin.setOrderStatus(Number(id), String(body.status), baseUrlFor(req, config.baseUrl)));
}, A);
route('POST', '/api/admin/orders/:id/paid', async (req, res, { id }) => {
  const body = await readJson(req, 1_000);
  json(res, 200, admin.markPaid(Number(id), String(body.payment || '')));
}, A);

route('GET', '/api/admin/discounts', (req, res) => json(res, 200, { discounts: listDiscounts() }), A);
route('POST', '/api/admin/discounts', async (req, res) => json(res, 201, createDiscount(await readJson(req, 2_000))), A);
route('PUT', '/api/admin/discounts/:id', async (req, res, { id }) => json(res, 200, updateDiscount(Number(id), await readJson(req, 2_000))), A);
route('DELETE', '/api/admin/discounts/:id', (req, res, { id }) => {
  deleteDiscount(Number(id));
  json(res, 200, { deleted: true });
}, A);
route('POST', '/api/admin/test-email', async (req, res) => {
  await readJson(req, 1_000);
  try {
    json(res, 200, { sentTo: await sendTestEmail(getSettings()) });
  } catch (err) {
    throw new HttpError(400, err.message.startsWith('Resend returned') ? `The email service said no: ${err.message.replace(/^Resend returned /, '')}` : err.message);
  }
}, A);
route('POST', '/api/admin/orders/:id/cancel', async (req, res, { id }) => {
  await readJson(req, 1_000);
  json(res, 200, await admin.cancelAndRefund(Number(id)));
}, A);

route('GET', '/api/admin/products', (req, res) => json(res, 200, { products: admin.listProducts() }), A);
route('POST', '/api/admin/products', async (req, res) => json(res, 201, admin.createProduct(await readJson(req, 20_000))), A);
route('PUT', '/api/admin/products/:id', async (req, res, { id }) => json(res, 200, admin.updateProduct(Number(id), await readJson(req, 20_000))), A);
route('DELETE', '/api/admin/products/:id', (req, res, { id }) => {
  admin.deleteProduct(Number(id));
  json(res, 200, { deleted: true });
}, A);
route('POST', '/api/admin/products-order', async (req, res) => json(res, 200, { products: admin.reorderProducts((await readJson(req, 20_000)).ids) }), A);
route('POST', '/api/admin/uploads', async (req, res) => json(res, 201, admin.saveUpload(await readJson(req, 6_000_000))), A);

route('GET', '/api/admin/finance', (req, res) => json(res, 200, admin.finance(q(req).get('from'), q(req).get('to'))), A);
route('GET', '/api/admin/expenses', (req, res) => json(res, 200, { expenses: admin.listExpenses(q(req).get('from'), q(req).get('to')) }), A);
route('POST', '/api/admin/expenses', async (req, res) => json(res, 201, admin.addExpense(await readJson(req, 5_000))), A);
route('DELETE', '/api/admin/expenses/:id', (req, res, { id }) => {
  admin.deleteExpense(Number(id));
  json(res, 200, { deleted: true });
}, A);
route('GET', '/api/admin/export/orders.csv', (req, res) => {
  const p = q(req);
  send(res, 200, admin.ordersCsv(p.get('from'), p.get('to')), {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="velvet-crumb-orders-${p.get('from')}-to-${p.get('to')}.csv"`,
    'Cache-Control': 'no-store',
  });
}, A);
route('GET', '/api/admin/export/expenses.csv', (req, res) => {
  const p = q(req);
  send(res, 200, admin.expensesCsv(p.get('from'), p.get('to')), {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="velvet-crumb-costs-${p.get('from')}-to-${p.get('to')}.csv"`,
    'Cache-Control': 'no-store',
  });
}, A);

route('GET', '/api/admin/clients', (req, res) => json(res, 200, { clients: clients.listClients(q(req).get('q') || '') }), A);
route('GET', '/api/admin/clients/:id', (req, res, { id }) => json(res, 200, clients.getClient(Number(id))), A);
route('POST', '/api/admin/clients', async (req, res) => json(res, 201, clients.addClient(await readJson(req, 10_000))), A);
route('PUT', '/api/admin/clients/:id', async (req, res, { id }) => json(res, 200, clients.updateClient(Number(id), await readJson(req, 10_000))), A);
route('DELETE', '/api/admin/clients/:id', (req, res, { id }) => {
  clients.deleteClient(Number(id));
  json(res, 200, { deleted: true });
}, A);
route('GET', '/api/admin/export/clients.csv', (req, res) => {
  send(res, 200, admin.clientsCsv(clients.clientsRows()), {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': 'attachment; filename="velvet-crumb-clients.csv"',
    'Cache-Control': 'no-store',
  });
}, A);

route('GET', '/api/admin/settings', (req, res) => json(res, 200, admin.adminSettings()), A);
route('PUT', '/api/admin/settings', async (req, res) => {
  admin.updateSettings(await readJson(req, 100_000));
  json(res, 200, admin.adminSettings());
}, A);
route('POST', '/api/admin/delete-test-orders', async (req, res) => {
  await readJson(req, 1_000);
  json(res, 200, admin.deleteTestOrders());
}, A);

// ---------- Pages and files ----------

function servePage(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return false;
  if (pathname === '/') return serveFile(res, publicDir, 'index.html');
  if (pathname === '/admin' || pathname === '/admin/') return serveFile(res, publicDir, 'admin.html');
  if (pathname === '/privacy' || pathname === '/terms') {
    send(res, 200, legalPage(pathname.slice(1), getSettings()), { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
    return true;
  }
  if (/^\/order\/[A-Za-z0-9_-]+$/.test(pathname)) return serveFile(res, publicDir, 'order.html');
  if (pathname.startsWith('/uploads/')) {
    return serveFile(res, uploadsDir, pathname.slice('/uploads/'.length), 'public, max-age=31536000, immutable');
  }
  if (pathname === '/healthz') {
    json(res, 200, { ok: true });
    return true;
  }
  return serveFile(res, publicDir, pathname.slice(1));
}

export const server = http.createServer(async (req, res) => {
  const pathname = new URL(req.url, 'http://x').pathname;
  try {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.regex.exec(pathname);
      if (!m) continue;
      if (r.adminOnly && !isAdmin(req)) throw new HttpError(401, 'Sign in again to carry on.');
      const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
      await r.handler(req, res, params);
      return;
    }
    if (pathname.startsWith('/api/')) throw new HttpError(404, 'Not found.');
    if (!servePage(req, res, pathname)) send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
  } catch (err) {
    const status = err instanceof HttpError ? err.status : 500;
    if (status === 500) console.error(err);
    if (!res.headersSent) json(res, status, { error: status === 500 ? 'Something went wrong. Please try again.' : err.message });
    else res.end();
  }
});

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  if (loadStarterMenu()) console.log('Loaded the starter menu');
  const boxesChanged = migrateBoxes();
  if (boxesChanged) console.log(`Turned ${boxesChanged} boxes into flavour pickers`);
  const builder = addLoadedBuilder();
  if (builder.added || builder.linked) console.log(`Build your own loaded: ${builder.added ? 'added' : 'already there'}, ${builder.linked} topping lists linked`);
  clients.linkUnlinkedOrders();
  housekeeping();
  setInterval(() => {
    housekeeping();
    sendScheduledEmails().catch((err) => console.error('Scheduled emails:', err.message));
  }, 5 * 60_000).unref();
  server.listen(config.port, () => {
    console.log(`Velvet Crumb orders running on port ${server.address().port}`);
    console.log(`Payments: ${stripeEnabled() ? 'Stripe connected' : 'TEST MODE (no STRIPE_SECRET_KEY)'}`);
    console.log(`Emails: ${emailEnabled() ? 'on' : 'off (no RESEND_API_KEY / EMAIL_FROM)'}`);
    if (!passwordConfigured()) console.log('Admin: set ADMIN_PASSWORD to sign in to /admin');
  });
}
