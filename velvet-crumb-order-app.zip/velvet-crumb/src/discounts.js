// Discount codes Jess creates: a percentage or an amount off the bakes
// (never the delivery fee), with an optional minimum spend.
import { db, nowIso } from './db.js';
import { HttpError, text } from './http.js';

const money = (p) => `£${(p / 100).toFixed(2).replace(/\.00$/, '')}`;
const CODE_RE = /^[A-Z0-9]{3,20}$/;

export const cleanCode = (raw) => text(raw, 40).toUpperCase().replace(/\s+/g, '');

const byCode = db.prepare('SELECT * FROM discounts WHERE code = ?');
const byId = db.prepare('SELECT * FROM discounts WHERE id = ?');

export function describe(d) {
  const off = d.kind === 'percent' ? `${d.value}% off` : `${money(d.value)} off`;
  return d.min_spend_pence > 0 ? `${off} orders of ${money(d.min_spend_pence)} or more` : off;
}

function publicDiscount(d) {
  return {
    id: d.id,
    code: d.code,
    kind: d.kind,
    value: d.value,
    min_spend_pence: d.min_spend_pence,
    active: Boolean(d.active),
    uses: d.uses,
    label: describe(d),
  };
}

// The amount off a bakes subtotal, in pence.
export function amountOff(d, subtotal) {
  const off = d.kind === 'percent' ? Math.round((subtotal * d.value) / 100) : d.value;
  return Math.max(0, Math.min(off, subtotal));
}

// Checks a code against the bakes subtotal. Returns null for no code.
export function applyDiscount(rawCode, subtotal) {
  const code = cleanCode(rawCode);
  if (!code) return null;
  const d = byCode.get(code);
  if (!d || !d.active) throw new HttpError(400, `${code} isn't a code we recognise. Check it and try again.`);
  if (subtotal < d.min_spend_pence) {
    throw new HttpError(400, `${code} is for orders of ${money(d.min_spend_pence)} or more.`);
  }
  return { code: d.code, pence: amountOff(d, subtotal), label: describe(d) };
}

// What the shop needs to work out the discount as the basket changes.
export function checkCode(body) {
  const code = cleanCode(body?.code);
  if (!code) throw new HttpError(400, 'Enter a discount code.');
  const d = byCode.get(code);
  if (!d || !d.active) throw new HttpError(400, `${code} isn't a code we recognise. Check it and try again.`);
  return { code: d.code, kind: d.kind, value: d.value, min_spend_pence: d.min_spend_pence, label: describe(d) };
}

export function countUse(code) {
  if (code) db.prepare('UPDATE discounts SET uses = uses + 1 WHERE code = ?').run(code);
}

// ---------- Admin ----------

export function listDiscounts() {
  return db.prepare('SELECT * FROM discounts ORDER BY active DESC, code').all().map(publicDiscount);
}

function fields(body) {
  const code = cleanCode(body.code);
  if (!CODE_RE.test(code)) throw new HttpError(400, 'Codes are 3 to 20 letters or numbers, e.g. XMAS10.');
  const kind = body.kind === 'amount' ? 'amount' : body.kind === 'percent' ? 'percent' : '';
  if (!kind) throw new HttpError(400, 'Choose percentage off or money off.');
  const value = Number(body.value);
  if (kind === 'percent' && !(Number.isInteger(value) && value >= 1 && value <= 90)) {
    throw new HttpError(400, 'Enter a percentage from 1 to 90.');
  }
  if (kind === 'amount' && !(Number.isInteger(value) && value >= 10 && value <= 100_000)) {
    throw new HttpError(400, 'Enter the money off, e.g. 5.00.');
  }
  const min = Number(body.min_spend_pence || 0);
  if (!Number.isInteger(min) || min < 0 || min > 1_000_000) throw new HttpError(400, 'Enter the minimum spend, e.g. 30.00, or leave it blank.');
  if (kind === 'amount' && min && min <= value) throw new HttpError(400, 'Make the minimum spend more than the money off.');
  return { code, kind, value, min_spend_pence: min, active: body.active === false ? 0 : 1 };
}

export function createDiscount(body) {
  const f = fields(body);
  if (byCode.get(f.code)) throw new HttpError(409, `There's already a code called ${f.code}.`);
  const now = nowIso();
  const { lastInsertRowid } = db
    .prepare('INSERT INTO discounts (code, kind, value, min_spend_pence, active, created_at, updated_at) VALUES (?,?,?,?,?,?,?)')
    .run(f.code, f.kind, f.value, f.min_spend_pence, f.active, now, now);
  return publicDiscount(byId.get(Number(lastInsertRowid)));
}

export function updateDiscount(id, body) {
  const existing = byId.get(id);
  if (!existing) throw new HttpError(404, 'Discount code not found.');
  const f = fields(body);
  const clash = byCode.get(f.code);
  if (clash && clash.id !== id) throw new HttpError(409, `There's already a code called ${f.code}.`);
  db.prepare('UPDATE discounts SET code = ?, kind = ?, value = ?, min_spend_pence = ?, active = ?, updated_at = ? WHERE id = ?')
    .run(f.code, f.kind, f.value, f.min_spend_pence, f.active, nowIso(), id);
  return publicDiscount(byId.get(id));
}

export function deleteDiscount(id) {
  if (!byId.get(id)) throw new HttpError(404, 'Discount code not found.');
  db.prepare('DELETE FROM discounts WHERE id = ?').run(id);
}
