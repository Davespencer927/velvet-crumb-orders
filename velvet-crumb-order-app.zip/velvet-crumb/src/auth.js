// Admin sign-in: one password (ADMIN_PASSWORD), kept in a signed cookie.
// Changing the password signs everyone out.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { clientIp, isHttps } from './http.js';

const COOKIE = 'vc_admin';
const MAX_AGE_SECONDS = 30 * 24 * 60 * 60;

function loadSecret() {
  if (config.sessionSecret) return config.sessionSecret;
  const file = path.join(config.dataDir, '.session-secret');
  try {
    return fs.readFileSync(file, 'utf8').trim();
  } catch {
    const secret = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(file, secret, { mode: 0o600 });
    return secret;
  }
}

const secret = loadSecret();
const sha256 = (s) => crypto.createHash('sha256').update(s).digest();

function signature(expires) {
  return crypto
    .createHmac('sha256', secret)
    .update(`${expires}.${sha256(config.adminPassword).toString('hex')}`)
    .digest('hex');
}

export function passwordConfigured() {
  return config.adminPassword.length > 0;
}

export function checkPassword(given) {
  if (!passwordConfigured()) return false;
  return crypto.timingSafeEqual(sha256(String(given ?? '')), sha256(config.adminPassword));
}

export function sessionCookie(req) {
  const expires = Math.floor(Date.now() / 1000) + MAX_AGE_SECONDS;
  const secure = isHttps(req) ? '; Secure' : '';
  return `${COOKIE}=${expires}.${signature(expires)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${MAX_AGE_SECONDS}${secure}`;
}

export function clearCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`;
}

export function isAdmin(req) {
  if (!passwordConfigured()) return false;
  const cookies = String(req.headers.cookie || '').split(';');
  for (const c of cookies) {
    const [name, ...rest] = c.trim().split('=');
    if (name !== COOKIE) continue;
    const [expires, sig] = rest.join('=').split('.');
    if (!expires || !sig || Number(expires) < Date.now() / 1000) return false;
    const expected = Buffer.from(signature(expires), 'hex');
    const given = Buffer.from(sig, 'hex');
    return given.length === expected.length && crypto.timingSafeEqual(given, expected);
  }
  return false;
}

// Slows down password guessing: 8 tries per 15 minutes per address.
const attempts = new Map();
export function loginAllowed(req) {
  const ip = clientIp(req);
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.reset < now) {
    attempts.set(ip, { count: 1, reset: now + 15 * 60 * 1000 });
    return true;
  }
  entry.count += 1;
  return entry.count <= 8;
}
export function loginSucceeded(req) {
  attempts.delete(clientIp(req));
}

// A simple per-address limit for other things worth slowing down (e.g. guessing discount codes).
const buckets = new Map();
export function rateLimit(req, name, max, windowMs) {
  const key = `${name}|${clientIp(req)}`;
  const now = Date.now();
  const entry = buckets.get(key);
  if (!entry || entry.reset < now) {
    if (buckets.size > 5_000) buckets.clear();
    buckets.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  entry.count += 1;
  return entry.count <= max;
}
