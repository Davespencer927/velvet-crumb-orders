// Jess's menu, loaded once on first start so the shop isn't empty.
// The gluten free and vegan range starts as "Coming soon": on the menu, not orderable yet.
// Costs to make and allergens are left for Jess to fill in on the Menu tab.
// After the first start she can change or delete anything here.
import { db, getSettings, saveSettings, nowIso, transaction } from './db.js';
import { flavourSet, toppingsOf } from './boxes.js';

const BASE_CHOICES = ['Chocolate brownie', 'White chocolate blondie'];
const choice = (name, price = 0) => ({ name, price_pence: price, cost_pence: 0 });

const pickBase = (choices = BASE_CHOICES) => ({
  name: 'Base',
  type: 'one',
  required: true,
  max: 1,
  choices: choices.map((c) => choice(c)),
});

const brownieOrBlondie = {
  name: 'Brownie or blondie',
  type: 'one',
  required: true,
  max: 1,
  choices: [choice('Brownie'), choice('Blondie')],
};

// Choices taken from a flavour list's toppings in Settings, so there is one list to keep up to date.
const fromToppings = (name, list) => ({ name, type: 'one', required: true, max: 1, list, choices: [] });

export const LOADED_BUILDER = {
  name: 'Build your own loaded',
  description: 'A brownie or blondie with your choice of flavour filled inside, and a topping on top.',
  category: 'Loaded',
  price_pence: 400,
  image: '/clipart/special.svg',
  options: [pickBase(), fromToppings('Filled inside with', 'main'), fromToppings('Topped with', 'main')],
};

// A box the customer fills: size, flavour list, and the mix and all-loaded prices.
const box = (size, set, mixPence, loadedPence) => ({ size, set, mix_pence: mixPence, loaded_pence: loadedPence, mix_cost_pence: 0, loaded_cost_pence: 0 });

export const BOX_NOTE = 'Anything else Jess should know about your box?';
const OLD_FLAVOURS_QUESTION = 'Which flavours would you like in your box?';

export const STARTER_MENU = [
  // Main menu
  {
    name: 'Classic brownie or blondie',
    description: 'A plain base, decorated and topped with your choice.',
    category: 'Classic',
    price_pence: 350,
    image: '/clipart/classic.svg',
    options: [pickBase(), fromToppings('Topping', 'main')],
    note_label: 'Want a topping that isn’t listed? Ask Jess here.',
  },
  {
    name: 'Triple chocolate brownie',
    description: 'White, milk and dark chocolate chunks mixed through, finished with a three-chocolate drizzle.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/triple-chocolate.svg',
  },
  {
    name: 'Lotus Biscoff brownie or blondie',
    description: 'Biscoff spread swirled through, Biscoff pieces in the middle, a Biscoff drizzle and a Lotus biscuit on top.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/biscuit.svg',
    options: [brownieOrBlondie],
  },
  {
    name: 'Jammy Dodger blondie',
    description: 'Raspberry jam swirled inside, a jam drizzle on top and finished with a biscuit.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/jam-blondie.svg',
  },
  {
    name: 'Kinder brownie or blondie',
    description: 'Kinder chocolate and spread mixed inside and on top.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/choc-chunk.svg',
    options: [brownieOrBlondie],
  },
  LOADED_BUILDER,
  {
    name: 'Monthly special',
    description: 'A new limited-edition flavour every month.',
    category: 'Monthly special',
    price_pence: 400,
    image: '/clipart/special.svg',
    status: 'hidden',
  },
  {
    name: 'Box of 4',
    description: '4 classic £14, a mix £15, or 4 loaded £16.',
    category: 'Boxes',
    price_pence: 1400,
    image: '/clipart/box-4.svg',
    box: box(4, 'main', 1500, 1600),
    note_label: BOX_NOTE,
  },
  {
    name: 'Box of 6 (most popular)',
    description: '6 classic £21, a mix £22.50, or 6 loaded £24.',
    category: 'Boxes',
    price_pence: 2100,
    image: '/clipart/box-6.svg',
    box: box(6, 'main', 2250, 2400),
    note_label: BOX_NOTE,
  },
  {
    name: 'Box of 9 (best value)',
    description: '9 classic £31, a mix £33, or 9 loaded £34.',
    category: 'Boxes',
    price_pence: 3100,
    image: '/clipart/box-9.svg',
    box: box(9, 'main', 3300, 3400),
    note_label: BOX_NOTE,
  },

  // Gluten free and vegan menu
  {
    name: 'Gluten free and vegan classic',
    description: 'A plain gluten free and vegan base, decorated and topped with your choice.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 350,
    image: '/clipart/gf-classic.svg',
    options: [pickBase(['Chocolate brownie', 'White chocolate blondie']), fromToppings('Topping', 'gf')],
  },
  {
    name: 'White chocolate and raspberry blondie',
    description: 'Gluten free and vegan. Stuffed with white chocolate and raspberries, with more on top.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-raspberry-blondie.svg',
  },
  {
    name: 'Dark chocolate and cherry brownie',
    description: 'Gluten free and vegan. Cherries inside, topped with chocolate and more cherries.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-cherry-brownie.svg',
  },
  {
    name: 'Gluten free and vegan triple chocolate brownie',
    description: 'Milk, dark and white chocolate, topped with chocolate and chocolate shavings.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-triple-chocolate.svg',
  },
  {
    name: 'Gluten free and vegan box of 2',
    description: '2 classic £7, a mix £7.50, or 2 loaded £8.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 700,
    image: '/clipart/gf-box-2.svg',
    box: box(2, 'gf', 750, 800),
    note_label: BOX_NOTE,
  },
  {
    name: 'Gluten free and vegan box of 4',
    description: '4 classic £14, a mix £15, or 4 loaded £16.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 1400,
    image: '/clipart/gf-box-4.svg',
    box: box(4, 'gf', 1500, 1600),
    note_label: BOX_NOTE,
  },
  {
    name: 'Gluten free and vegan box of 6',
    description: '6 classic £21, a mix £22.50, or 6 loaded £24.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 2100,
    image: '/clipart/gf-box-6.svg',
    box: box(6, 'gf', 2250, 2400),
    note_label: BOX_NOTE,
  },
  {
    name: 'Gluten free and vegan box of 9',
    description: '9 classic £32, a mix £34, or 9 loaded £36.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 3200,
    image: '/clipart/gf-box-9.svg',
    box: box(9, 'gf', 3400, 3600),
    note_label: BOX_NOTE,
  },
];

export function loadStarterMenu() {
  const settings = getSettings();
  if (settings.starter_menu_loaded) return false;
  const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
  if (count === 0) {
    transaction(() => {
      const insert = db.prepare(
        `INSERT INTO products (name, description, category, price_pence, cost_pence, allergens, allergens_set, image, status, sort,
          options, note_label, note_required, box, created_at)
         VALUES (?, ?, ?, ?, 0, '[]', 0, ?, ?, ?, ?, ?, ?, ?, ?)`,
      );
      STARTER_MENU.forEach((p, i) => {
        insert.run(
          p.name, p.description, p.category, p.price_pence, p.image, p.status || 'on', i + 1,
          JSON.stringify(p.options || []), p.note_label || '', p.note_required ? 1 : 0, p.box ? JSON.stringify(p.box) : '', nowIso(),
        );
      });
    });
  }
  saveSettings({ ...getSettings(), starter_menu_loaded: true });
  return count === 0;
}

// Boxes used to have a "Box type" choice and a typed flavours question.
// This turns them into boxes customers fill with flavours, once, keeping
// Jess's prices and any costs she has entered.
export function migrateBoxes() {
  const settings = getSettings();
  if (settings.boxes_migrated) return 0;
  let changed = 0;
  const rows = db.prepare('SELECT * FROM products').all();
  const update = db.prepare('UPDATE products SET box = ?, options = ?, note_label = ?, note_required = ? WHERE id = ?');
  for (const p of rows) {
    let groups;
    try {
      groups = JSON.parse(p.options || '[]');
    } catch {
      continue;
    }
    const type = groups.find((g) => g.name === 'Box type');
    const size = Number((/box of (\d+)/i.exec(p.name) || [])[1]);
    if (!type || !size || p.box) continue;
    const find = (re) => type.choices.find((c) => re.test(c.name)) || { price_pence: 0, cost_pence: 0 };
    const mix = find(/mix/i);
    const loaded = type.choices.find((c) => /loaded/i.test(c.name) && !/mix/i.test(c.name)) || { price_pence: 0, cost_pence: 0 };
    const set = /gluten free|vegan/i.test(`${p.name} ${p.category}`) ? 'gf' : 'main';
    const boxJson = JSON.stringify({
      size,
      set,
      mix_pence: p.price_pence + (mix.price_pence || 0),
      loaded_pence: p.price_pence + (loaded.price_pence || 0),
      mix_cost_pence: p.cost_pence + (mix.cost_pence || 0),
      loaded_cost_pence: p.cost_pence + (loaded.cost_pence || 0),
    });
    const rest = groups.filter((g) => g !== type);
    const noteLabel = p.note_label === OLD_FLAVOURS_QUESTION ? BOX_NOTE : p.note_label;
    const noteRequired = p.note_label === OLD_FLAVOURS_QUESTION ? 0 : p.note_required;
    update.run(boxJson, JSON.stringify(rest), noteLabel, noteRequired, p.id);
    changed += 1;
  }
  saveSettings({ ...getSettings(), boxes_migrated: true });
  return changed;
}

// Added after launch: the build-your-own loaded item, and the Classic toppings
// linked to the toppings list in Settings. Runs once. Leaves alone anything
// Jess has already changed.
export function addLoadedBuilder() {
  const settings = getSettings();
  if (settings.loaded_builder_added) return { added: false, linked: 0 };
  let added = false;
  let linked = 0;
  transaction(() => {
    const rows = db.prepare('SELECT * FROM products ORDER BY sort, id').all();
    if (!rows.some((p) => p.name === LOADED_BUILDER.name)) {
      const lastLoaded = [...rows].reverse().find((p) => p.category === 'Loaded');
      const sort = lastLoaded ? lastLoaded.sort + 1 : (rows.at(-1)?.sort || 0) + 1;
      db.prepare('UPDATE products SET sort = sort + 1 WHERE sort >= ?').run(sort);
      db.prepare(
        `INSERT INTO products (name, description, category, price_pence, cost_pence, allergens, allergens_set, image, status, sort,
          options, note_label, note_required, box, created_at)
         VALUES (?, ?, ?, ?, 0, '[]', 0, ?, 'on', ?, ?, '', 0, '', ?)`,
      ).run(LOADED_BUILDER.name, LOADED_BUILDER.description, LOADED_BUILDER.category, LOADED_BUILDER.price_pence,
        LOADED_BUILDER.image, sort, JSON.stringify(LOADED_BUILDER.options), nowIso());
      added = true;
    }
    // Classic toppings: link to the list only if they still match it exactly, with no extra prices or costs.
    for (const p of rows) {
      let groups;
      try {
        groups = JSON.parse(p.options || '[]');
      } catch {
        continue;
      }
      const listId = /gluten free|vegan/i.test(`${p.name} ${p.category}`) ? 'gf' : 'main';
      const tops = toppingsOf(flavourSet(settings, listId));
      let changed = false;
      const next = groups.map((g) => {
        if (g.list || g.name !== 'Topping' || g.type !== 'one' || !tops.length) return g;
        const names = (g.choices || []).map((c) => c.name);
        const same = names.length === tops.length && names.every((n) => tops.includes(n));
        const free = (g.choices || []).every((c) => !c.price_pence && !c.cost_pence);
        if (!same || !free) return g;
        changed = true;
        return { ...g, list: listId, choices: [] };
      });
      if (changed) {
        db.prepare('UPDATE products SET options = ? WHERE id = ?').run(JSON.stringify(next), p.id);
        linked += 1;
      }
    }
  });
  saveSettings({ ...getSettings(), loaded_builder_added: true });
  return { added, linked };
}
