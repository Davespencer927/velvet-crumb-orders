// Jess's menu, loaded once on first start so the shop isn't empty.
// The gluten free and vegan range starts as "Coming soon": on the menu, not orderable yet.
// Costs to make and allergens are left for Jess to fill in on the Menu tab.
// After the first start she can change or delete anything here.
import { db, getSettings, saveSettings, nowIso, transaction } from './db.js';

const BASE_CHOICES = ['Chocolate brownie', 'White chocolate blondie'];
const choice = (name, price = 0) => ({ name, price_pence: price, cost_pence: 0 });

const pickBase = (choices = BASE_CHOICES) => ({
  name: 'Base',
  type: 'one',
  required: true,
  max: 1,
  choices: choices.map((c) => choice(c)),
});

const brownieOrBlondie = {
  name: 'Brownie or blondie',
  type: 'one',
  required: true,
  max: 1,
  choices: [choice('Brownie'), choice('Blondie')],
};

const boxType = (mixExtra, loadedExtra) => ({
  name: 'Box type',
  type: 'one',
  required: true,
  max: 1,
  choices: [choice('All classic'), choice('Mix of classic and loaded', mixExtra), choice('All loaded', loadedExtra)],
});

const FLAVOURS_QUESTION = 'Which flavours would you like in your box?';

export const STARTER_MENU = [
  // Main menu
  {
    name: 'Classic brownie or blondie',
    description: 'A plain base, decorated and topped with your choice.',
    category: 'Classic',
    price_pence: 350,
    image: '/clipart/classic.svg',
    options: [
      pickBase(),
      {
        name: 'Topping',
        type: 'one',
        required: true,
        max: 1,
        choices: [
          'Chocolate orange', 'Strawberry', 'Oreo pieces', 'Pistachio', 'Salted caramel', 'Biscoff', 'Nutella',
          'Kinder', 'White chocolate', 'Milk chocolate', 'Ferrero Rocher', 'Fudge pieces',
        ].map((c) => choice(c)),
      },
    ],
    note_label: 'Want a topping that isn’t listed? Ask Jess here.',
  },
  {
    name: 'Triple chocolate brownie',
    description: 'White, milk and dark chocolate chunks mixed through, finished with a three-chocolate drizzle.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/triple-chocolate.svg',
  },
  {
    name: 'Lotus Biscoff brownie or blondie',
    description: 'Biscoff spread swirled through, Biscoff pieces in the middle, a Biscoff drizzle and a Lotus biscuit on top.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/biscuit.svg',
    options: [brownieOrBlondie],
  },
  {
    name: 'Jammy Dodger blondie',
    description: 'Raspberry jam swirled inside, a jam drizzle on top and finished with a biscuit.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/jam-blondie.svg',
  },
  {
    name: 'Kinder brownie or blondie',
    description: 'Kinder chocolate and spread mixed inside and on top.',
    category: 'Loaded',
    price_pence: 400,
    image: '/clipart/choc-chunk.svg',
    options: [brownieOrBlondie],
  },
  {
    name: 'Monthly special',
    description: 'A new limited-edition flavour every month.',
    category: 'Monthly special',
    price_pence: 400,
    image: '/clipart/special.svg',
    status: 'hidden',
  },
  {
    name: 'Box of 4',
    description: '4 classic £14, a mix £15, or 4 loaded £16.',
    category: 'Boxes',
    price_pence: 1400,
    image: '/clipart/box-4.svg',
    options: [boxType(100, 200)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
  {
    name: 'Box of 6 (most popular)',
    description: '6 classic £21, a mix £22.50, or 6 loaded £24.',
    category: 'Boxes',
    price_pence: 2100,
    image: '/clipart/box-6.svg',
    options: [boxType(150, 300)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
  {
    name: 'Box of 9 (best value)',
    description: '9 classic £31, a mix £33, or 9 loaded £34.',
    category: 'Boxes',
    price_pence: 3100,
    image: '/clipart/box-9.svg',
    options: [boxType(200, 300)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },

  // Gluten free and vegan menu
  {
    name: 'Gluten free and vegan classic',
    description: 'A plain gluten free and vegan base, decorated and topped with your choice.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 350,
    image: '/clipart/gf-classic.svg',
    options: [
      pickBase(['Chocolate brownie', 'White chocolate blondie']),
      {
        name: 'Topping',
        type: 'one',
        required: true,
        max: 1,
        choices: ['Strawberries', 'Cherries', 'Nuts', 'Chocolate orange pieces', 'White chocolate', 'Milk chocolate', 'Caramel', 'Fruit'].map((c) => choice(c)),
      },
    ],
  },
  {
    name: 'White chocolate and raspberry blondie',
    description: 'Gluten free and vegan. Stuffed with white chocolate and raspberries, with more on top.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-raspberry-blondie.svg',
  },
  {
    name: 'Dark chocolate and cherry brownie',
    description: 'Gluten free and vegan. Cherries inside, topped with chocolate and more cherries.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-cherry-brownie.svg',
  },
  {
    name: 'Gluten free and vegan triple chocolate brownie',
    description: 'Milk, dark and white chocolate, topped with chocolate and chocolate shavings.',
    status: 'soon',
    category: 'Gluten free and vegan',
    price_pence: 400,
    image: '/clipart/gf-triple-chocolate.svg',
  },
  {
    name: 'Gluten free and vegan box of 2',
    description: '2 classic £7, a mix £7.50, or 2 loaded £8.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 700,
    image: '/clipart/gf-box-2.svg',
    options: [boxType(50, 100)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
  {
    name: 'Gluten free and vegan box of 4',
    description: '4 classic £14, a mix £15, or 4 loaded £16.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 1400,
    image: '/clipart/gf-box-4.svg',
    options: [boxType(100, 200)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
  {
    name: 'Gluten free and vegan box of 6',
    description: '6 classic £21, a mix £22.50, or 6 loaded £24.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 2100,
    image: '/clipart/gf-box-6.svg',
    options: [boxType(150, 300)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
  {
    name: 'Gluten free and vegan box of 9',
    description: '9 classic £32, a mix £34, or 9 loaded £36.',
    status: 'soon',
    category: 'Gluten free and vegan boxes',
    price_pence: 3200,
    image: '/clipart/gf-box-9.svg',
    options: [boxType(200, 400)],
    note_label: FLAVOURS_QUESTION,
    note_required: true,
  },
];

export function loadStarterMenu() {
  const settings = getSettings();
  if (settings.starter_menu_loaded) return false;
  const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
  if (count === 0) {
    transaction(() => {
      const insert = db.prepare(
        `INSERT INTO products (name, description, category, price_pence, cost_pence, allergens, allergens_set, image, status, sort,
          options, note_label, note_required, created_at)
         VALUES (?, ?, ?, ?, 0, '[]', 0, ?, ?, ?, ?, ?, ?, ?)`,
      );
      STARTER_MENU.forEach((p, i) => {
        insert.run(
          p.name, p.description, p.category, p.price_pence, p.image, p.status || 'on', i + 1,
          JSON.stringify(p.options || []), p.note_label || '', p.note_required ? 1 : 0, nowIso(),
        );
      });
    });
  }
  saveSettings({ ...settings, starter_menu_loaded: true });
  return count === 0;
}
