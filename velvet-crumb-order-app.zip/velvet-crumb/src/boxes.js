// Boxes customers fill with flavours (Box of 4, 6, 9…).
//
// A box item stores its size, which flavour list it uses, and three prices
// from Jess's menu: all classic (the item's normal price), a mix, and all
// loaded. The flavour lists themselves live in Settings so Jess can edit
// them once for every box that uses them.
import { HttpError, text, pence } from './http.js';

const MAIN_CLASSIC = [
  'Chocolate orange', 'Strawberry', 'Oreo pieces', 'Pistachio', 'Salted caramel', 'Biscoff', 'Nutella', 'Kinder',
  'White chocolate', 'Milk chocolate', 'Ferrero Rocher', 'Fudge pieces',
];
const MAIN_LOADED = [
  'Triple chocolate brownie', 'Lotus Biscoff brownie', 'Lotus Biscoff blondie', 'Jammy Dodger blondie', 'Kinder brownie', 'Kinder blondie',
];
const GF_CLASSIC = ['Strawberries', 'Cherries', 'Nuts', 'Chocolate orange pieces', 'White chocolate', 'Milk chocolate', 'Caramel', 'Fruit'];
const GF_LOADED = ['White chocolate and raspberry blondie', 'Dark chocolate and cherry brownie', 'Triple chocolate brownie'];
const BASES = ['Chocolate brownie', 'White chocolate blondie', 'Some of each'];

const flavours = (classic, loaded) => [
  ...classic.map((name) => ({ name, kind: 'classic' })),
  ...loaded.map((name) => ({ name, kind: 'loaded' })),
];

// Classic flavours are the toppings. They are also what customers pick from to
// build their own loaded bake: one flavour filled inside, one on top.
export const DEFAULT_FLAVOUR_SETS = [
  { id: 'main', name: 'Main menu', bases: BASES, build_loaded: true, flavours: flavours(MAIN_CLASSIC, MAIN_LOADED) },
  { id: 'gf', name: 'Gluten free and vegan', bases: BASES, build_loaded: true, flavours: flavours(GF_CLASSIC, GF_LOADED) },
];

export const toppingsOf = (set) => (set?.flavours || []).filter((f) => f.kind === 'classic').map((f) => f.name);

// Bases for a single bake: "Some of each" only makes sense for a few classic bakes together.
export function loadedBases(set) {
  const single = (set?.bases || []).filter((b) => !/\beach\b|\bmix/i.test(b));
  return single.length ? single : ['Chocolate brownie', 'White chocolate blondie'];
}

export const canBuildLoaded = (set) => Boolean(set) && set.build_loaded !== false && toppingsOf(set).length > 0;

export const builtName = (b) => `${b.base} with ${b.filling} inside and ${b.topping} on top`;

export const TIER_LABELS = { classic: 'All classic', mix: 'Mix of classic and loaded', loaded: 'All loaded' };

export function parseBox(raw) {
  if (!raw) return null;
  try {
    const box = JSON.parse(raw);
    return box && Number.isInteger(box.size) && box.size > 0 ? box : null;
  } catch {
    return null;
  }
}

export function flavourSet(settings, id) {
  return (settings.box_flavour_sets || []).find((s) => s.id === id) || null;
}

// What customers see: sizes, prices and flavours, never Jess's costs.
export function publicBox(p, settings) {
  const box = parseBox(p.box);
  if (!box) return null;
  const set = flavourSet(settings, box.set);
  if (!set) return null;
  return {
    size: box.size,
    prices: { classic: p.price_pence, mix: box.mix_pence, loaded: box.loaded_pence },
    bases: set.bases,
    flavours: set.flavours,
    build: canBuildLoaded(set) ? { bases: loadedBases(set), flavours: toppingsOf(set) } : null,
  };
}

// Checks the customer's picks and works out the price, cost and description.
export function priceBox(p, box, settings, picks) {
  const set = flavourSet(settings, box.set);
  if (!set) throw new HttpError(409, `${p.name} isn't available right now.`);
  const counts = new Map();
  for (const pick of Array.isArray(picks?.flavours) ? picks.flavours.slice(0, 100) : []) {
    const name = String(pick?.name ?? '');
    const qty = Number(pick?.qty);
    if (!Number.isInteger(qty) || qty < 1) continue;
    if (!set.flavours.some((f) => f.name === name)) {
      throw new HttpError(409, `The flavours for ${p.name} have changed. Remove it from your basket and fill it again.`);
    }
    counts.set(name, (counts.get(name) || 0) + qty);
  }
  // Build-your-own loaded bakes: a base, a flavour inside and a flavour on top.
  const built = new Map();
  const customs = Array.isArray(picks?.custom) ? picks.custom.slice(0, 50) : [];
  if (customs.length) {
    const bases = loadedBases(set);
    const tops = toppingsOf(set);
    for (const c of customs) {
      const qty = Number(c?.qty);
      if (!Number.isInteger(qty) || qty < 1) continue;
      const b = { base: String(c?.base ?? ''), filling: String(c?.filling ?? ''), topping: String(c?.topping ?? '') };
      if (!canBuildLoaded(set) || !bases.includes(b.base) || !tops.includes(b.filling) || !tops.includes(b.topping)) {
        throw new HttpError(409, `The flavours for ${p.name} have changed. Remove it from your basket and fill it again.`);
      }
      const name = builtName(b);
      built.set(name, (built.get(name) || 0) + qty);
    }
  }

  const total = [...counts.values(), ...built.values()].reduce((a, b) => a + b, 0);
  if (total !== box.size) throw new HttpError(400, `Choose ${box.size} bakes for ${p.name}. You've chosen ${total}.`);

  const kindOf = (name) => set.flavours.find((f) => f.name === name).kind;
  const classic = [...counts].filter(([n]) => kindOf(n) === 'classic');
  const loaded = [...[...counts].filter(([n]) => kindOf(n) === 'loaded'), ...built];
  const tier = !loaded.length ? 'classic' : !classic.length ? 'loaded' : 'mix';

  let base = '';
  if (classic.length && set.bases.length) {
    base = String(picks?.base ?? '');
    if (!set.bases.includes(base)) throw new HttpError(400, `Choose the base for the classic bakes in ${p.name}.`);
  }

  const list = (entries) => entries.map(([n, q]) => `${q} ${n}`).join(', ');
  const parts = [TIER_LABELS[tier]];
  if (classic.length) parts.push(`Classic${base ? ` (base: ${base})` : ''}: ${list(classic)}`);
  if (loaded.length) parts.push(`Loaded: ${list(loaded)}`);

  const price = { classic: p.price_pence, mix: box.mix_pence, loaded: box.loaded_pence }[tier];
  const cost = { classic: p.cost_pence, mix: box.mix_cost_pence, loaded: box.loaded_cost_pence }[tier];
  return { price, cost, text: parts.join('. ') };
}

// Admin: the box part of an item.
export function boxFields(body, settings) {
  const b = body.box;
  if (!b || !b.size) return '';
  const size = Number(b.size);
  if (!Number.isInteger(size) || size < 1 || size > 48) throw new HttpError(400, 'Box size must be a whole number from 1 to 48.');
  if (!flavourSet(settings, String(b.set))) throw new HttpError(400, 'Choose which flavour list this box uses.');
  const money = (v, label) => {
    const n = pence(v ?? 0);
    if (n === null) throw new HttpError(400, `${label} must be £0 or more.`);
    return n;
  };
  const mix = money(b.mix_pence, 'The mix price');
  const loaded = money(b.loaded_pence, 'The all-loaded price');
  if (!mix || !loaded) throw new HttpError(400, 'Set the box prices for a mix and for all loaded.');
  return JSON.stringify({
    size,
    set: String(b.set),
    mix_pence: mix,
    loaded_pence: loaded,
    mix_cost_pence: money(b.mix_cost_pence, 'The mix cost'),
    loaded_cost_pence: money(b.loaded_cost_pence, 'The all-loaded cost'),
  });
}

// Admin: the flavour lists in Settings.
export function flavourSetsFrom(raw) {
  const list = Array.isArray(raw) ? raw : [];
  if (list.length > 8) throw new HttpError(400, 'Keep it to 8 flavour lists or fewer.');
  const ids = new Set();
  return list.map((s) => {
    const name = text(s?.name, 40);
    if (!name) throw new HttpError(400, 'Give every flavour list a name.');
    let id = String(s?.id || '').replace(/[^a-z0-9-]/g, '') || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'list';
    while (ids.has(id)) id += '-2';
    ids.add(id);
    const bases = [...new Set((Array.isArray(s.bases) ? s.bases : []).map((x) => text(x, 40)).filter(Boolean))].slice(0, 10);
    const seen = new Set();
    const fl = (Array.isArray(s.flavours) ? s.flavours.slice(0, 80) : [])
      .map((f) => ({ name: text(f?.name, 60), kind: f?.kind === 'loaded' ? 'loaded' : 'classic' }))
      .filter((f) => f.name);
    for (const f of fl) {
      if (seen.has(f.name)) throw new HttpError(400, `${name} has "${f.name}" twice.`);
      seen.add(f.name);
    }
    if (!fl.length) throw new HttpError(400, `Add at least one flavour to ${name}.`);
    return { id, name, bases, build_loaded: s?.build_loaded !== false, flavours: fl };
  });
}

// Item choices can come from a flavour list's toppings, so Jess edits them in one place.
export function resolveGroups(groups, settings) {
  return groups.map((g) => {
    if (!g.list) return g;
    const set = flavourSet(settings, g.list);
    return { ...g, choices: toppingsOf(set).map((name) => ({ name, price_pence: 0, cost_pence: 0 })) };
  });
}
