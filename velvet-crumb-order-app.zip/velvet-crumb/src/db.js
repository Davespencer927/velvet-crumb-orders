import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';

export const uploadsDir = path.join(config.dataDir, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

export const db = new DatabaseSync(path.join(config.dataDir, 'velvet-crumb.db'));

db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  price_pence INTEGER NOT NULL,
  cost_pence INTEGER NOT NULL DEFAULT 0,
  allergens TEXT NOT NULL DEFAULT '[]',
  image TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'on',
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL UNIQUE,
  ref TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  method TEXT NOT NULL,
  date TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  postcode TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  subtotal_pence INTEGER NOT NULL,
  delivery_pence INTEGER NOT NULL DEFAULT 0,
  total_pence INTEGER NOT NULL,
  cost_pence INTEGER NOT NULL DEFAULT 0,
  fee_pence INTEGER NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT '',
  stripe_session TEXT NOT NULL DEFAULT '',
  payment_intent TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  paid_at TEXT,
  paid_date TEXT,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS orders_by_date ON orders(date);
CREATE INDEX IF NOT EXISTS orders_by_paid_date ON orders(paid_date);
CREATE INDEX IF NOT EXISTS orders_by_status ON orders(status);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id INTEGER,
  name TEXT NOT NULL,
  price_pence INTEGER NOT NULL,
  cost_pence INTEGER NOT NULL DEFAULT 0,
  qty INTEGER NOT NULL,
  allergens TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS items_by_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  amount_pence INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS expenses_by_date ON expenses(date);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '',
  phone_key TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  postcode TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT 'online',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS clients_by_email ON clients(email);
CREATE INDEX IF NOT EXISTS clients_by_phone ON clients(phone_key);
`);

// Columns added after the first version. Safe to run every start.
function addColumn(table, column, definition) {
  const exists = db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column);
  if (!exists) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}
addColumn('products', 'options', "TEXT NOT NULL DEFAULT '[]'");
addColumn('products', 'note_label', "TEXT NOT NULL DEFAULT ''");
addColumn('products', 'note_required', 'INTEGER NOT NULL DEFAULT 0');
addColumn('products', 'allergens_set', 'INTEGER NOT NULL DEFAULT 0');
addColumn('products', 'badge', "TEXT NOT NULL DEFAULT ''");
addColumn('products', 'was_price_pence', 'INTEGER NOT NULL DEFAULT 0');
addColumn('order_items', 'options', "TEXT NOT NULL DEFAULT ''");
addColumn('order_items', 'note', "TEXT NOT NULL DEFAULT ''");
addColumn('orders', 'client_id', 'INTEGER');
addColumn('orders', 'time_window', "TEXT NOT NULL DEFAULT ''");
db.exec('CREATE INDEX IF NOT EXISTS orders_by_client ON orders(client_id)');

// The 14 allergens UK food law requires businesses to declare.
export const ALLERGENS = [
  'Celery',
  'Cereals containing gluten',
  'Crustaceans',
  'Eggs',
  'Fish',
  'Lupin',
  'Milk',
  'Molluscs',
  'Mustard',
  'Tree nuts',
  'Peanuts',
  'Sesame',
  'Soya',
  'Sulphites',
];

export const EXPENSE_CATEGORIES = [
  'Ingredients',
  'Packaging',
  'Equipment',
  'Marketing',
  'Delivery and fuel',
  'Website and fees',
  'Training and insurance',
  'Other',
];

const closedDay = () => ({
  collect: { on: false, from: '10:00', to: '16:00' },
  deliver: { on: false, from: '16:00', to: '19:00' },
});

export const DEFAULT_SETTINGS = {
  business_name: 'Velvet Crumb',
  tagline: 'Thick, gooey, bakery-style brownies and blondies.',
  shop_open: true,
  closed_message: 'Orders are paused for now. Check back soon.',
  owner_email: '',
  contact_phone: '',
  instagram: 'velvet_x_crumbs',
  facebook_url: 'https://www.facebook.com/share/1CjH8SiQb7/',

  // Weekly opening: 0 = Sunday … 6 = Saturday. All closed until Jess sets them.
  schedule: Object.fromEntries([0, 1, 2, 3, 4, 5, 6].map((d) => [d, closedDay()])),
  lead_days: 2,
  booking_window_days: 28,
  blocked_dates: [],
  daily_order_cap: 0,
  min_order_pence: 0,

  collection_area: "Collect from Jess's home. The address is sent with your order confirmation.",
  collection_address: '',

  delivery_fee_pence: 300,
  delivery_free_over_pence: 0,
  delivery_postcodes: '',
  delivery_note: 'Local delivery only.',

  allergen_notice:
    "Everything is baked in a home kitchen that handles gluten, eggs, milk, tree nuts, peanuts and soya, so no bake can be guaranteed free from any allergen. If you have an allergy, message Jess before you order.",

  stripe_fee_percent: 1.5,
  stripe_fee_fixed_pence: 20,

  // Boxes on the menu page; Jess chooses the wording.
  notices: [
    { title: 'Coming soon', text: 'Gluten free, dairy free and vegan range. Nostalgic boxes.', show: true },
    { title: 'Monthly specials', text: 'A new limited-edition flavour every month, £3.50 to £4.00.', show: true },
  ],

  starter_menu_loaded: false,
};

const getSettingsRow = db.prepare("SELECT value FROM settings WHERE key = 'shop'");
const putSettingsRow = db.prepare(
  "INSERT INTO settings (key, value) VALUES ('shop', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
);

export function getSettings() {
  const row = getSettingsRow.get();
  let saved = {};
  if (row) {
    try {
      saved = JSON.parse(row.value);
    } catch {
      saved = {};
    }
  }
  return { ...DEFAULT_SETTINGS, ...saved };
}

export function saveSettings(settings) {
  putSettingsRow.run(JSON.stringify(settings));
  return getSettings();
}

export function nowIso() {
  return new Date().toISOString();
}

export function parseList(value) {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function transaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}
