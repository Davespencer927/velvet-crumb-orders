// Emails to customers: ready, out for delivery, the reminder and the thank you.
// Runs in-process against a fake email service.
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';

const sent = [];
const fake = http.createServer((req, res) => {
  let body = '';
  req.on('data', (d) => (body += d));
  req.on('end', () => {
    const mail = JSON.parse(body);
    sent.push(mail);
    if (mail.to[0] === 'bounce@example.com') {
      res.writeHead(403, { 'Content-Type': 'application/json' });
      return res.end('{"message":"You can only send testing emails to your own email address"}');
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end('{"id":"email_1"}');
  });
});
await new Promise((r) => fake.listen(0, r));
after(() => fake.close());

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'vc-mail-'));
process.env.RESEND_API_KEY = 're_test';
process.env.EMAIL_FROM = 'Velvet Crumb <onboarding@resend.dev>';
process.env.RESEND_API_BASE = `http://127.0.0.1:${fake.address().port}`;
process.env.BASE_URL = 'https://orders.example.com';

const { db, getSettings, saveSettings } = await import('../src/db.js');
const { setOrderStatus } = await import('../src/admin.js');
const { sendScheduledEmails, ukHour } = await import('../src/messages.js');
const { sendTestEmail } = await import('../src/email.js');

const HOUR = 3_600_000;
// 12 noon on 10 December 2026 (UK time is UTC in winter).
const NOON = Date.UTC(2026, 11, 10, 12, 0);
const settle = () => new Promise((r) => setTimeout(r, 150));

function addOrder({ status = 'paid', method = 'collection', date = '2026-12-11', email = 'cat@example.com', created = NOON - 7 * HOUR, completed = null, ref }) {
  const iso = (ms) => (ms === null ? null : new Date(ms).toISOString());
  return Number(db.prepare(
    `INSERT INTO orders (token, ref, status, name, email, phone, method, date, address, postcode, subtotal_pence, total_pence,
       time_window, created_at, paid_at, updated_at, completed_at)
     VALUES (?, ?, ?, 'Cat Lee', ?, '07700900111', ?, ?, '5 Mill Lane', 'S70 2AA', 2100, 2100, '10am to 4pm', ?, ?, ?, ?)`,
  ).run(ref, ref, status, email, method, date, iso(created), iso(created), iso(created), iso(completed)).lastInsertRowid);
}
const mailsTo = (ref) => sent.filter((m) => m.html.includes(ref));

test('ready to collect and out for delivery emails', async () => {
  saveSettings({ ...getSettings(), owner_email: 'jess@example.com', contact_phone: '07700 900000', collection_address: '1 Bakery Row' });
  const collect = addOrder({ ref: 'VC-READY', date: '2026-12-01' });
  const res = setOrderStatus(collect, 'ready');
  assert.equal(res.emailed, true);
  await settle();
  const [ready] = mailsTo('VC-READY');
  assert.equal(ready.subject, 'Your Velvet Crumb order is ready to collect');
  assert.deepEqual(ready.to, ['cat@example.com']);
  assert.equal(ready.reply_to, 'jess@example.com');
  assert.match(ready.html, /1 Bakery Row/);

  const deliver = addOrder({ ref: 'VC-OUT', method: 'delivery', date: '2026-12-01' });
  setOrderStatus(deliver, 'ready');
  await settle();
  assert.equal(mailsTo('VC-OUT')[0].subject, 'Your Velvet Crumb order is on its way');
  assert.match(mailsTo('VC-OUT')[0].html, /5 Mill Lane/);

  // Undo and redo does not email again; switched off sends nothing
  setOrderStatus(deliver, 'paid');
  saveSettings({ ...getSettings(), email_out: false });
  assert.equal(setOrderStatus(deliver, 'ready').emailed, false);
  await settle();
  assert.equal(mailsTo('VC-OUT').length, 1);

  // No email address: nothing to send
  const noEmail = addOrder({ ref: 'VC-NOMAIL', email: '', date: '2026-12-01' });
  assert.equal(setOrderStatus(noEmail, 'ready').emailed, false);

  // Marking done records when, for the thank you
  setOrderStatus(collect, 'completed');
  assert.ok(db.prepare('SELECT completed_at FROM orders WHERE id = ?').get(collect).completed_at);
});

test('reminder the day before and thank you after', async () => {
  assert.equal(ukHour(NOON), 12);
  const due = addOrder({ ref: 'VC-REMIND' });
  const justOrdered = addOrder({ ref: 'VC-JUSTNOW', created: NOON - HOUR });
  const nextWeek = addOrder({ ref: 'VC-LATER', date: '2026-12-17' });
  const thanks = addOrder({ ref: 'VC-THANKS', status: 'completed', date: '2026-12-10', completed: NOON - 3 * HOUR });
  const tooSoon = addOrder({ ref: 'VC-TOOSOON', status: 'completed', date: '2026-12-10', completed: NOON - HOUR });
  const bounced = addOrder({ ref: 'VC-BOUNCE', email: 'bounce@example.com' });

  // Too early in the morning: nothing yet
  assert.deepEqual(await sendScheduledEmails(NOON - 4 * HOUR), { reminders: 0, thanks: 0 });

  const result = await sendScheduledEmails(NOON);
  assert.deepEqual(result, { reminders: 1, thanks: 1 });
  assert.equal(mailsTo('VC-REMIND')[0].subject, 'See you tomorrow: your Velvet Crumb collection');
  assert.equal(mailsTo('VC-JUSTNOW').length, 0);
  assert.equal(mailsTo('VC-LATER').length, 0);
  const thankYou = sent.filter((m) => m.subject === 'Thank you from Velvet Crumb');
  assert.equal(thankYou.length, 1);
  assert.match(thankYou[0].html, /facebook\.com/);
  assert.equal(mailsTo('VC-TOOSOON').length, 0);
  // A failed send is logged and not retried
  assert.equal(mailsTo('VC-BOUNCE').length, 1);
  assert.ok(db.prepare('SELECT reminder_sent_at FROM orders WHERE id = ?').get(bounced).reminder_sent_at);

  // Running again sends nothing twice
  assert.deepEqual(await sendScheduledEmails(NOON + 10 * 60_000), { reminders: 0, thanks: 0 });
  assert.ok(db.prepare('SELECT reminder_sent_at FROM orders WHERE id = ?').get(due).reminder_sent_at);
  assert.ok(db.prepare('SELECT thanks_sent_at FROM orders WHERE id = ?').get(thanks).thanks_sent_at);
  void justOrdered;
  void nextWeek;
  void tooSoon;

  // Switched off in Settings
  saveSettings({ ...getSettings(), email_reminder: false, email_thanks: false, review_url: 'https://g.page/r/velvet-crumb/review' });
  addOrder({ ref: 'VC-OFF' });
  assert.deepEqual(await sendScheduledEmails(NOON + 20 * 60_000), { reminders: 0, thanks: 0 });
});

test('test email goes to Jess', async () => {
  const before = sent.length;
  assert.equal(await sendTestEmail(getSettings()), 'jess@example.com');
  assert.equal(sent.length, before + 1);
  assert.deepEqual(sent.at(-1).to, ['jess@example.com']);
  await assert.rejects(() => sendTestEmail({ ...getSettings(), owner_email: '' }), /Add your email address/);
});
