// Data retention promised in the privacy notice.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'vc-house-'));
const { db } = await import('../src/db.js');
const { housekeeping } = await import('../src/orders.js');

const day = 86_400_000;
const ago = (days) => new Date(Date.now() - days * day).toISOString();

function addOrder({ status, created, paid = null, email = 'a@example.com', client = null }) {
  return Number(
    db
      .prepare(
        `INSERT INTO orders (token, ref, status, name, email, phone, method, date, subtotal_pence, total_pence, created_at, paid_at, updated_at, client_id)
         VALUES (?, ?, ?, 'Ann', ?, '07700900000', 'collection', '2020-01-01', 100, 100, ?, ?, ?, ?)`,
      )
      .run(Math.random().toString(36), `VC-${Math.random().toString(36).slice(2, 7)}`, status, email, created, paid, created, client).lastInsertRowid,
  );
}
function addClient(updated) {
  return Number(
    db
      .prepare("INSERT INTO clients (name, email, created_at, updated_at) VALUES ('C', ?, ?, ?)")
      .run(`${Math.random()}@example.com`, updated, updated).lastInsertRowid,
  );
}
const exists = (table, id) => Boolean(db.prepare(`SELECT 1 FROM ${table} WHERE id = ?`).get(id));

test('housekeeping applies the retention periods', () => {
  const freshPending = addOrder({ status: 'pending', created: ago(0) });
  const stalePending = addOrder({ status: 'pending', created: new Date(Date.now() - 60 * 60_000).toISOString() });
  const oldExpired = addOrder({ status: 'expired', created: ago(31) });
  const recentExpired = addOrder({ status: 'expired', created: ago(5) });
  const oldPaid = addOrder({ status: 'completed', created: ago(400), paid: ago(400) });
  const ancientPaid = addOrder({ status: 'completed', created: ago(6 * 365 + 10), paid: ago(6 * 365 + 10) });

  const idleClient = addClient(ago(800));
  addOrder({ status: 'completed', created: ago(800), paid: ago(800), client: idleClient });
  const activeClient = addClient(ago(800));
  addOrder({ status: 'completed', created: ago(100), paid: ago(100), client: activeClient });
  const recentClient = addClient(ago(10));

  housekeeping();

  const status = (id) => db.prepare('SELECT status FROM orders WHERE id = ?').get(id)?.status;
  assert.equal(status(freshPending), 'pending');
  assert.equal(status(stalePending), 'expired');
  assert.equal(exists('orders', oldExpired), false, 'unpaid orders go after 30 days');
  assert.equal(exists('orders', recentExpired), true);
  assert.equal(exists('orders', oldPaid), true, 'paid orders are kept');
  const anon = db.prepare('SELECT name, email, phone FROM orders WHERE id = ?').get(ancientPaid);
  assert.deepEqual({ ...anon }, { name: 'Removed after 6 years', email: '', phone: '' });
  assert.equal(exists('clients', idleClient), false, 'no orders for 2 years');
  assert.equal(exists('clients', activeClient), true);
  assert.equal(exists('clients', recentClient), true);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM orders WHERE client_id = ?').get(idleClient).n, 0);
});
