// Data retention promised in the privacy notice.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'vc-house-'));
const { db } = await import('../src/db.js');
const { housekeeping } = await import('../src/orders.js');

const day = 86_400_000;
const ago = (days) => new Date(Date.now() - days * day).toISOString();

function addOrder({ status, created, paid = null, email = 'a@example.com', client = null }) {
  return Number(
    db
      .prepare(
        `INSERT INTO orders (token, ref, status, name, email, phone, method, date, subtotal_pence, total_pence, created_at, paid_at, updated_at, client_id)
         VALUES (?, ?, ?, 'Ann', ?, '07700900000', 'collection', '2020-01-01', 100, 100, ?, ?, ?, ?)`,
      )
      .run(Math.random().toString(36), `VC-${Math.random().toString(36).slice(2, 7)}`, status, email, created, paid, created, client).lastInsertRowid,
  );
}
function addClient(updated) {
  return Number(
    db
      .prepare("INSERT INTO clients (name, email, created_at, updated_at) VALUES ('C', ?, ?, ?)")
      .run(`${Math.random()}@example.com`, updated, updated).lastInsertRowid,
  );
}
const exists = (table, id) => Boolean(db.prepare(`SELECT 1 FROM ${table} WHERE id = ?`).get(id));

test('housekeeping applies the retention periods', () => {
  const freshPending = addOrder({ status: 'pending', created: ago(0) });
  const stalePending = addOrder({ status: 'pending', created: new Date(Date.now() - 60 * 60_000).toISOString() });
  const oldExpired = addOrder({ status: 'expired', created: ago(31) });
  const recentExpired = addOrder({ status: 'expired', created: ago(5) });
  const oldPaid = addOrder({ status: 'completed', created: ago(400), paid: ago(400) });
  const ancientPaid = addOrder({ status: 'completed', created: ago(6 * 365 + 10), paid: ago(6 * 365 + 10) });

  const idleClient = addClient(ago(800));
  addOrder({ status: 'completed', created: ago(800), paid: ago(800), client: idleClient });
  const activeClient = addClient(ago(800));
  addOrder({ status: 'completed', created: ago(100), paid: ago(100), client: activeClient });
  const recentClient = addClient(ago(10));

  housekeeping();

  const status = (id) => db.prepare('SELECT status FROM orders WHERE id = ?').get(id)?.status;
  assert.equal(status(freshPending), 'pending');
  assert.equal(status(stalePending), 'expired');
  assert.equal(exists('orders', oldExpired), false, 'unpaid orders go after 30 days');
  assert.equal(exists('orders', recentExpired), true);
  assert.equal(exists('orders', oldPaid), true, 'paid orders are kept');
  const anon = db.prepare('SELECT name, email, phone FROM orders WHERE id = ?').get(ancientPaid);
  assert.deepEqual({ ...anon }, { name: 'Removed after 6 years', email: '', phone: '' });
  assert.equal(exists('clients', idleClient), false, 'no orders for 2 years');
  assert.equal(exists('clients', activeClient), true);
  assert.equal(exists('clients', recentClient), true);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM orders WHERE client_id = ?').get(idleClient).n, 0);
});

test('old-style boxes are turned into flavour pickers once', async () => {
  const { migrateBoxes } = await import('../src/starter-menu.js');
  const { getSettings, saveSettings } = await import('../src/db.js');
  saveSettings({ ...getSettings(), boxes_migrated: false });
  const options = JSON.stringify([{
    name: 'Box type', type: 'one', required: true, max: 1,
    choices: [
      { name: 'All classic', price_pence: 0, cost_pence: 0 },
      { name: 'Mix of classic and loaded', price_pence: 150, cost_pence: 60 },
      { name: 'All loaded', price_pence: 300, cost_pence: 120 },
    ],
  }]);
  const id = Number(db.prepare(
    `INSERT INTO products (name, category, price_pence, cost_pence, options, note_label, note_required, created_at)
     VALUES ('Gluten free and vegan box of 6', 'Gluten free and vegan boxes', 2100, 700, ?, 'Which flavours would you like in your box?', 1, ?)`,
  ).run(options, new Date().toISOString()).lastInsertRowid);
  assert.equal(migrateBoxes(), 1);
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  assert.deepEqual(JSON.parse(p.box), { size: 6, set: 'gf', mix_pence: 2250, loaded_pence: 2400, mix_cost_pence: 760, loaded_cost_pence: 820 });
  assert.equal(JSON.parse(p.options).length, 0);
  assert.equal(p.note_required, 0);
  assert.equal(p.note_label, 'Anything else Jess should know about your box?');
  assert.equal(migrateBoxes(), 0, 'only runs once');
});

test('build your own loaded is added once and classic toppings are linked if unchanged', async () => {
  const { addLoadedBuilder } = await import('../src/starter-menu.js');
  const { getSettings, saveSettings } = await import('../src/db.js');
  saveSettings({ ...getSettings(), loaded_builder_added: false });
  db.prepare('DELETE FROM products').run();
  const tops = getSettings().box_flavour_sets[0].flavours.filter((f) => f.kind === 'classic').map((f) => f.name);
  const topping = (names, price = 0) => ({ name: 'Topping', type: 'one', required: true, max: 1, choices: names.map((name) => ({ name, price_pence: price, cost_pence: 0 })) });
  const add = (name, category, sort, options = []) => Number(db.prepare(
    "INSERT INTO products (name, category, price_pence, sort, options, created_at) VALUES (?, ?, 400, ?, ?, '2026-01-01')",
  ).run(name, category, sort, JSON.stringify(options)).lastInsertRowid);
  const classic = add('Classic brownie or blondie', 'Classic', 1, [topping(tops)]);
  const edited = add('Classic special', 'Classic', 2, [topping(tops, 50)]);
  add('Triple chocolate brownie', 'Loaded', 3);
  add('Kinder brownie or blondie', 'Loaded', 4);
  const box = add('Box of 4', 'Boxes', 5);

  assert.deepEqual(addLoadedBuilder(), { added: true, linked: 1 });
  const opts = (id) => JSON.parse(db.prepare('SELECT options FROM products WHERE id = ?').get(id).options);
  assert.equal(opts(classic)[0].list, 'main');
  assert.equal(opts(edited)[0].list, undefined, 'a list Jess changed is left alone');
  const builder = db.prepare("SELECT * FROM products WHERE name = 'Build your own loaded'").get();
  assert.equal(builder.sort, 5);
  assert.equal(db.prepare('SELECT sort FROM products WHERE id = ?').get(box).sort, 6, 'later items move down one');
  assert.deepEqual(addLoadedBuilder(), { added: false, linked: 0 }, 'only once');
});
