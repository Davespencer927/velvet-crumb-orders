// End-to-end tests: starts the real server against a temporary database.
// Run with: npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import net from 'node:net';
import { fileURLToPath } from 'node:url';
import { signWebhookPayload, verifyWebhookSignature, formEncode } from '../src/stripe.js';

const root = fileURLToPath(new URL('..', import.meta.url));
const PASSWORD = 'correct horse battery';
const WEBHOOK_SECRET = 'whsec_test_secret';

function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer().listen(0, () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

async function startApp(extraEnv = {}) {
  const port = await freePort();
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'vc-test-'));
  const child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/server.js'], {
    cwd: root,
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDir, ADMIN_PASSWORD: PASSWORD, ...extraEnv },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  child.stdout.on('data', (d) => (output += d));
  child.stderr.on('data', (d) => (output += d));
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Server did not start:\n${output}`)), 8000);
    child.stdout.on('data', () => {
      if (output.includes('running on port')) {
        clearTimeout(timer);
        resolve();
      }
    });
  });
  const base = `http://127.0.0.1:${port}`;
  let cookie = '';
  async function call(method, url, body, { auth = true, headers = {} } = {}) {
    const res = await fetch(base + url, {
      method,
      headers: {
        ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(auth && cookie ? { Cookie: cookie } : {}),
        ...headers,
      },
      body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
    });
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
    const setCookie = res.headers.get('set-cookie');
    if (setCookie) cookie = setCookie.split(';')[0];
    return { status: res.status, data, headers: res.headers };
  }
  return { child, dataDir, base, call, output: () => output };
}

const nextOpenDate = (shop) => shop.dates.find((d) => !d.full).date;
const everyDay = (collect = true, deliver = true) =>
  Object.fromEntries([0, 1, 2, 3, 4, 5, 6].map((d) => [d, {
    collect: { on: collect, from: '10:00', to: '16:00' },
    deliver: { on: deliver, from: '16:00', to: '19:30' },
  }]));
const tinyJpeg = 'data:image/jpeg;base64,' + Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 16, 74, 70, 73, 70, 0, 1, 0xff, 0xd9]).toString('base64');

// ---------------------------------------------------------------------------
// Test mode (no Stripe keys)
// ---------------------------------------------------------------------------
let app;
before(async () => {
  app = await startApp();
});
after(() => app.child.kill());

test('admin routes need sign-in', async () => {
  const r = await app.call('GET', '/api/admin/products', undefined, { auth: false });
  assert.equal(r.status, 401);
  const wrong = await app.call('POST', '/api/admin/login', { password: 'nope' });
  assert.equal(wrong.status, 401);
  const ok = await app.call('POST', '/api/admin/login', { password: PASSWORD });
  assert.equal(ok.status, 200);
  assert.match(ok.headers.get('set-cookie'), /HttpOnly; SameSite=Strict/);
});

test('full order in test mode, through to the money page', async () => {
  const { call } = app;
  await call('POST', '/api/admin/login', { password: PASSWORD });

  const upload = await call('POST', '/api/admin/uploads', { dataUrl: tinyJpeg });
  assert.equal(upload.status, 201);
  const img = await fetch(app.base + upload.data.image);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/jpeg');

  const badUpload = await call('POST', '/api/admin/uploads', { dataUrl: 'data:image/png;base64,' + Buffer.from('not a png').toString('base64') });
  assert.equal(badUpload.status, 400);

  const brownie = await call('POST', '/api/admin/products', {
    name: 'Classic fudge brownie', description: 'Dense and gooey.', category: 'Brownies',
    price_pence: 350, cost_pence: 110, allergens: ['Eggs', 'Milk', 'Cereals containing gluten', 'Made up'], image: upload.data.image, status: 'on',
  });
  assert.equal(brownie.status, 201);
  assert.deepEqual(brownie.data.allergens, ['Eggs', 'Milk', 'Cereals containing gluten']);
  const blondie = await call('POST', '/api/admin/products', {
    name: 'White choc blondie', category: 'Blondies', price_pence: 375, cost_pence: 120, allergens: ['Eggs', 'Milk'], status: 'on',
  });
  const soldOut = await call('POST', '/api/admin/products', { name: 'Biscoff brownie', category: 'Brownies', price_pence: 400, status: 'soldout' });
  const hidden = await call('POST', '/api/admin/products', { name: 'Secret bake', price_pence: 500, status: 'hidden' });
  assert.equal(hidden.status, 201);

  const badImage = await call('POST', '/api/admin/products', { name: 'X', price_pence: 100, image: '/etc/passwd' });
  assert.equal(badImage.status, 400);

  // Nothing is open until Jess sets her days
  const closed = (await call('GET', '/api/shop', undefined, { auth: false })).data;
  assert.equal(closed.shop.scheduleSet, false);
  assert.equal(closed.dates.length, 0);

  await call('PUT', '/api/admin/settings', { delivery_postcodes: 'S70, S71', delivery_fee_pence: 300, collection_address: '1 Secret Lane', schedule: everyDay() });

  const shop = (await call('GET', '/api/shop', undefined, { auth: false })).data;
  assert.equal(shop.testMode, true);
  assert.equal(shop.shop.scheduleSet, true);
  assert.equal(shop.dates[0].collect.label, '10am to 4pm');
  assert.equal(shop.dates[0].deliver.label, '4pm to 7:30pm');
  assert.ok(!shop.products.some((p) => p.name === 'Secret bake'), 'hidden item stays off the menu');
  assert.ok(!shop.products.some((p) => p.name === 'Monthly special'), 'the monthly special starts hidden');
  assert.equal(shop.products.filter((p) => ['Classic fudge brownie', 'White choc blondie', 'Biscoff brownie'].includes(p.name)).length, 3);
  assert.ok(shop.products.every((p) => !('cost_pence' in p)), 'cost to make is never sent to customers');
  assert.ok(!JSON.stringify(shop).includes('Secret Lane'), 'collection address is private');
  const date = nextOpenDate(shop);

  const order = {
    items: [{ id: brownie.data.id, qty: 4 }, { id: blondie.data.id, qty: 2 }],
    method: 'delivery', date, name: 'Sam Taylor', email: 'sam@example.com', phone: '07700 900123',
    address: '12 High Street, Barnsley', postcode: 'S70 1AA', notes: 'Birthday!', allergensChecked: true,
  };

  assert.equal((await call('POST', '/api/orders', { ...order, allergensChecked: false })).status, 400);
  assert.equal((await call('POST', '/api/orders', { ...order, postcode: 'S7 1AA' })).status, 400, 'S7 is not S70');
  assert.equal((await call('POST', '/api/orders', { ...order, items: [{ id: soldOut.data.id, qty: 1 }] })).status, 409);
  assert.equal((await call('POST', '/api/orders', { ...order, items: [{ id: hidden.data.id, qty: 1 }] })).status, 409);
  assert.equal((await call('POST', '/api/orders', { ...order, date: '2001-01-01' })).status, 400);

  const placed = await call('POST', '/api/orders', order);
  assert.equal(placed.status, 201, JSON.stringify(placed.data));
  const token = placed.data.url.split('/').pop();

  let view = (await call('GET', `/api/orders/${token}`, undefined, { auth: false })).data;
  assert.equal(view.status, 'pending');
  assert.equal(view.total_pence, 4 * 350 + 2 * 375 + 300);

  view = (await call('POST', `/api/orders/${token}/test-pay`, undefined, { auth: false })).data;
  assert.equal(view.status, 'paid');

  // Collection order: address only shown after payment
  const collect = await call('POST', '/api/orders', { ...order, method: 'collection', items: [{ id: brownie.data.id, qty: 1 }], name: '=HYPERLINK("x")' });
  const cToken = collect.data.url.split('/').pop();
  assert.equal((await call('GET', `/api/orders/${cToken}`)).data.collectionAddress, '');
  await call('POST', `/api/orders/${cToken}/test-pay`);
  assert.equal((await call('GET', `/api/orders/${cToken}`)).data.collectionAddress, '1 Secret Lane');

  // Admin sees both, with a bake list
  const upcoming = (await call('GET', '/api/admin/orders?view=upcoming')).data.orders;
  assert.equal(upcoming.length, 2);
  assert.equal(upcoming.find((o) => o.name === 'Sam Taylor').time_window, '4pm to 7:30pm');
  const bake = (await call('GET', '/api/admin/bake-list')).data.rows;
  assert.equal(bake.find((r) => r.name === 'Classic fudge brownie').qty, 5);

  const first = upcoming.find((o) => o.name === 'Sam Taylor');
  assert.equal((await call('POST', `/api/admin/orders/${first.id}/status`, { status: 'ready' })).data.status, 'ready');
  assert.equal((await call('POST', `/api/admin/orders/${first.id}/status`, { status: 'completed' })).data.status, 'completed');
  assert.equal((await call('POST', `/api/admin/orders/${first.id}/status`, { status: 'paid' })).status, 409);

  // Cancel the second one (test payment: no Stripe call)
  const second = upcoming.find((o) => o.id !== first.id);
  assert.equal((await call('POST', `/api/admin/orders/${second.id}/cancel`, {})).data.status, 'refunded');

  // Money
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date());
  await call('POST', '/api/admin/expenses', { date: today, category: 'Packaging', description: 'Boxes', amount_pence: 1299 });
  const f = (await call('GET', `/api/admin/finance?from=${today}&to=${today}`)).data;
  const sales = 4 * 350 + 2 * 375 + 300;
  const cost = 4 * 110 + 2 * 120;
  const feeEach = (t) => Math.round(t * 0.015) + 20;
  const fees = feeEach(sales) + feeEach(350); // the refunded order's fee is still counted
  assert.equal(f.sales, sales);
  assert.equal(f.cost, cost);
  assert.equal(f.fees, fees);
  assert.equal(f.expenses, 1299);
  assert.equal(f.profit, sales - cost - fees - 1299);
  assert.equal(f.refunds.n, 1);
  assert.equal(f.testOrders, 1);
  assert.equal(f.bestSellers[0].name, 'Classic fudge brownie');

  // CSV export, with spreadsheet formula protection
  const csv = await fetch(`${app.base}/api/admin/export/orders.csv?from=${today}&to=${today}`, { headers: { Cookie: (await call('POST', '/api/admin/login', { password: PASSWORD })).headers.get('set-cookie').split(';')[0] } });
  const csvText = await csv.text();
  assert.match(csvText, /Sam Taylor/);
  assert.match(csvText, /"'=HYPERLINK\(""x""\)"/);

  // Daily cap fills the date
  await call('PUT', '/api/admin/settings', { daily_order_cap: 1 });
  const capped = (await call('GET', '/api/shop')).data;
  assert.equal(capped.dates.find((d) => d.date === date).full, true);
  assert.equal((await call('POST', '/api/orders', order)).status, 409);
  await call('PUT', '/api/admin/settings', { daily_order_cap: 0 });

  // Clearing test orders
  const cleared = (await call('POST', '/api/admin/delete-test-orders', {})).data;
  assert.equal(cleared.deleted, 2);
  assert.equal((await call('GET', `/api/admin/finance?from=${today}&to=${today}`)).data.sales, 0);
});

test('menu choices, notes and the starter menu', async () => {
  const { call } = app;
  await call('POST', '/api/admin/login', { password: PASSWORD });
  await call('PUT', '/api/admin/settings', { schedule: everyDay(true, false), daily_order_cap: 0 });
  const shop = (await call('GET', '/api/shop')).data;
  const box = shop.products.find((p) => p.name === 'Box of 6 (most popular)');
  const classic = shop.products.find((p) => p.name === 'Classic brownie or blondie');
  assert.ok(box && classic, 'starter menu is loaded');
  assert.equal(box.allergens_set, false);
  assert.ok(box.options[0].choices.every((c) => !('cost_pence' in c)), 'choice costs stay private');
  assert.equal(shop.shop.delivery.enabled, false, 'no delivery days ticked');

  const base = {
    method: 'collection', date: nextOpenDate(shop), name: 'Jo Baker', email: 'jo@example.com', phone: '07700 900777', allergensChecked: true,
  };
  const order = (items) => call('POST', '/api/orders', { ...base, items });

  assert.equal((await order([{ id: box.id, qty: 1, options: [{ group: 'Box type', choices: ['All loaded'] }] }])).status, 400, 'flavours question is required');
  assert.equal((await order([{ id: box.id, qty: 1, note: 'Any' }])).status, 400, 'box type is required');
  assert.equal((await order([{ id: box.id, qty: 1, note: 'Any', options: [{ group: 'Box type', choices: ['Made up'] }] }])).status, 409);
  assert.equal((await order([{ id: classic.id, qty: 1, options: [{ group: 'Base', choices: ['Chocolate brownie', 'White chocolate blondie'] }, { group: 'Topping', choices: ['Biscoff'] }] }])).status, 400, 'pick one means one');
  assert.equal((await call('POST', '/api/orders', { ...base, method: 'delivery', address: '1 Road', postcode: 'S70 1AA', items: [{ id: classic.id, qty: 1 }] })).status, 400, 'no delivery days');

  const placed = await order([
    { id: box.id, qty: 1, note: 'Biscoff and Kinder please', options: [{ group: 'Box type', choices: ['Mix of classic and loaded'] }] },
    { id: classic.id, qty: 2, options: [{ group: 'Base', choices: ['White chocolate blondie'] }, { group: 'Topping', choices: ['Pistachio'] }] },
    { id: classic.id, qty: 1, options: [{ group: 'Base', choices: ['White chocolate blondie'] }, { group: 'Topping', choices: ['Pistachio'] }] },
  ]);
  assert.equal(placed.status, 201, JSON.stringify(placed.data));
  const token = placed.data.url.split('/').pop();
  await call('POST', `/api/orders/${token}/test-pay`);
  const view = (await call('GET', `/api/orders/${token}`)).data;
  assert.equal(view.total_pence, 2250 + 3 * 350);
  assert.equal(view.items.length, 2, 'identical lines are merged');
  assert.equal(view.items[0].options, 'Box type: Mix of classic and loaded');
  assert.equal(view.items[0].note, 'Biscoff and Kinder please');
  assert.equal(view.items[0].allergens, null, 'allergens not set yet');
  assert.equal(view.items[1].qty, 3);
  assert.equal(view.timeWindow, '10am to 4pm');

  const bake = (await call('GET', '/api/admin/bake-list')).data.rows;
  assert.ok(bake.some((r) => r.options === 'Base: White chocolate blondie. Topping: Pistachio' && r.qty === 3));

  // Jess edits an item: choices with costs, allergens confirmed
  const products = (await call('GET', '/api/admin/products')).data.products;
  const adminBox = products.find((p) => p.id === box.id);
  assert.equal(adminBox.options[0].choices[1].price_pence, 150);
  const saved = await call('PUT', `/api/admin/products/${box.id}`, {
    ...adminBox,
    cost_pence: 700,
    options: [{ ...adminBox.options[0], choices: adminBox.options[0].choices.map((c, i) => ({ ...c, cost_pence: i * 50 })) }],
    allergens: [],
    allergens_none: true,
  });
  assert.equal(saved.status, 200, JSON.stringify(saved.data));
  assert.equal(saved.data.allergens_set, true);
  assert.equal(saved.data.options[0].choices[2].cost_pence, 100);
  const bad = await call('PUT', `/api/admin/products/${box.id}`, { ...adminBox, options: [{ name: 'Size', type: 'one', choices: [] }] });
  assert.equal(bad.status, 400);
  assert.equal((await call('POST', '/api/admin/products', { name: 'Clip', price_pence: 100, image: '/clipart/box-4.svg' })).status, 201);
});

test('clients are saved from orders and can be added by hand', async () => {
  const { call } = app;
  await call('POST', '/api/admin/login', { password: PASSWORD });
  await call('PUT', '/api/admin/settings', { schedule: everyDay() });
  const shop = (await call('GET', '/api/shop')).data;
  const item = shop.products.find((p) => p.name === 'Triple chocolate brownie');
  const place = async (email, phone, name) => {
    const r = await call('POST', '/api/orders', {
      items: [{ id: item.id, qty: 2 }], method: 'collection', date: nextOpenDate(shop), name, email, phone, allergensChecked: true,
    });
    const token = r.data.url.split('/').pop();
    await call('POST', `/api/orders/${token}/test-pay`);
  };
  await place('kim@example.com', '07700 900321', 'Kim Lee');
  await place('KIM@example.com', '+44 7700 900321', 'Kim Lee-Smith'); // same person
  await place('other@example.com', '07700900321', 'Kim at work'); // matched on phone? no: email wins, new email has no client, phone matches
  let list = (await call('GET', '/api/admin/clients?q=kim')).data.clients;
  assert.equal(list.length, 1);
  assert.equal(list[0].orders, 3);
  assert.equal(list[0].spent, 3 * 800);
  assert.equal(list[0].name, 'Kim at work');

  // Unpaid orders don't create clients
  await call('POST', '/api/orders', { items: [{ id: item.id, qty: 1 }], method: 'collection', date: nextOpenDate(shop), name: 'Never Paid', email: 'np@example.com', phone: '07700900999', allergensChecked: true });
  assert.equal((await call('GET', '/api/admin/clients?q=never')).data.clients.length, 0);

  // Jess adds someone
  assert.equal((await call('POST', '/api/admin/clients', { name: 'No Contact' })).status, 400);
  const added = await call('POST', '/api/admin/clients', { name: 'Café Rosa', phone: '01226 123456', notes: 'Wholesale, 2 boxes a week' });
  assert.equal(added.status, 201, JSON.stringify(added.data));
  assert.equal(added.data.client.source, 'added');
  assert.equal((await call('POST', '/api/admin/clients', { name: 'Dupe', email: 'kim@example.com' })).status, 409);
  const id = added.data.client.id;
  const upd = await call('PUT', `/api/admin/clients/${id}`, { name: 'Cafe Rosa', phone: '01226 123456', email: 'rosa@example.com', postcode: 's70 9zz' });
  assert.equal(upd.data.client.postcode, 'S70 9ZZ');
  assert.ok(!('phone_key' in upd.data.client));
  assert.equal((await call('GET', '/api/admin/clients?q=01226')).data.clients[0].name, 'Cafe Rosa');

  const kim = list[0];
  const detail = (await call('GET', `/api/admin/clients/${kim.id}`)).data;
  assert.equal(detail.orders.length, 3);
  assert.match(detail.orders[0].items[0], /2 × Triple chocolate brownie/);

  const csv = await fetch(`${app.base}/api/admin/export/clients.csv`, { headers: { Cookie: (await call('POST', '/api/admin/login', { password: PASSWORD })).headers.get('set-cookie').split(';')[0] } });
  assert.match(await csv.text(), /Cafe Rosa/);

  assert.equal((await call('DELETE', `/api/admin/clients/${kim.id}`)).status, 200);
  assert.equal((await call('GET', '/api/admin/clients?q=kim')).data.clients.length, 0);
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date());
  assert.ok((await call('GET', `/api/admin/finance?from=${today}&to=${today}`)).data.sales >= 2400, 'orders stay for the accounts');
});

test('coming soon items, labels, offers and notices', async () => {
  const { call } = app;
  await call('POST', '/api/admin/login', { password: PASSWORD });
  await call('PUT', '/api/admin/settings', { schedule: everyDay() });
  let shop = (await call('GET', '/api/shop', undefined, { auth: false })).data;
  const gf = shop.products.find((p) => p.name === 'Gluten free and vegan box of 4');
  assert.equal(gf.status, 'soon', 'the gluten free range starts as coming soon');
  assert.deepEqual(shop.shop.notices.map((n) => n.title), ['Coming soon', 'Monthly specials']);
  const date = nextOpenDate(shop);
  const tryOrder = await call('POST', '/api/orders', {
    items: [{ id: gf.id, qty: 1, note: 'x', options: [{ group: 'Box type', choices: ['All classic'] }] }],
    method: 'collection', date, name: 'Ann', email: 'ann@example.com', phone: '07700900111', allergensChecked: true,
  });
  assert.equal(tryOrder.status, 409);
  assert.match(tryOrder.data.error, /isn't available to order yet/);

  // Jess puts an item on offer with her own wording
  const products = (await call('GET', '/api/admin/products')).data.products;
  const jammy = products.find((p) => p.name === 'Jammy Dodger blondie');
  assert.equal((await call('PUT', `/api/admin/products/${jammy.id}`, { ...jammy, price_pence: 350, was_price_pence: 300 })).status, 400, 'was must be higher');
  const offer = await call('PUT', `/api/admin/products/${jammy.id}`, { ...jammy, price_pence: 350, was_price_pence: 400, badge: 'Half term treat' });
  assert.equal(offer.status, 200, JSON.stringify(offer.data));

  await call('PUT', '/api/admin/settings', {
    notices: [
      { title: 'Special offer', text: 'Jammy Dodger blondies £3.50 this week', show: true },
      { title: 'Coming soon', text: 'Hidden for now', show: false },
      { title: '', text: '' },
    ],
  });
  shop = (await call('GET', '/api/shop', undefined, { auth: false })).data;
  const j = shop.products.find((p) => p.id === jammy.id);
  assert.equal(j.badge, 'Half term treat');
  assert.equal(j.was_price_pence, 400);
  assert.deepEqual(shop.shop.notices, [{ title: 'Special offer', text: 'Jammy Dodger blondies £3.50 this week' }]);
  const saved = (await call('GET', '/api/admin/settings')).data.settings.notices;
  assert.equal(saved.length, 2, 'empty notices are dropped, hidden ones kept');
});

test('privacy notice and terms pages', async () => {
  const { call, base } = app;
  await call('POST', '/api/admin/login', { password: PASSWORD });
  await call('PUT', '/api/admin/settings', { contact_email: 'jess@example.com', contact_phone: '07700 900123', instagram: 'velvet_x_crumbs' });
  for (const [url, heading] of [['/privacy', 'Privacy notice'], ['/terms', 'Terms of sale']]) {
    const res = await fetch(base + url);
    const html = await res.text();
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/html/);
    assert.match(html, new RegExp(`<h1>${heading}</h1>`));
    assert.match(html, /by email at jess@example\.com, by text or phone on 07700 900123 or on Instagram @velvet_x_crumbs/);
    assert.ok(!html.includes('{contact}') && !html.includes('{business}'));
  }
  assert.match(await (await fetch(base + '/privacy')).text(), /<a href="https:\/\/ico\.org\.uk">ico\.org\.uk<\/a>/);

  // Jess's own wording is escaped and only safe links are allowed
  const settings = (await call('GET', '/api/admin/settings')).data;
  assert.ok(settings.legalDefaults.terms.includes('## Changes and cancellations'));
  await call('PUT', '/api/admin/settings', {
    terms_text: '## My terms\n<script>alert(1)</script>\n- [bad](javascript:alert(1)) [worse](//evil.example) [ok](/privacy)\n**Bold**',
  });
  const custom = await (await fetch(base + '/terms')).text();
  assert.ok(!custom.includes('<script>alert(1)</script>'));
  assert.ok(custom.includes('&lt;script&gt;'));
  assert.ok(!custom.includes('href="javascript'));
  assert.ok(!custom.includes('href="//evil'));
  assert.ok(custom.includes('<a href="/privacy">ok</a>'));
  assert.ok(custom.includes('<h2>My terms</h2>') && custom.includes('<strong>Bold</strong>'));

  // Saving the draft unchanged keeps following the standard wording
  await call('PUT', '/api/admin/settings', { terms_text: settings.legalDefaults.terms });
  assert.equal((await call('GET', '/api/admin/settings')).data.settings.terms_text, '');
});

test('settings are validated', async () => {
  await app.call('POST', '/api/admin/login', { password: PASSWORD });
  const badTimes = everyDay();
  badTimes[2].collect = { on: true, from: '17:00', to: '09:00' };
  assert.equal((await app.call('PUT', '/api/admin/settings', { schedule: badTimes })).status, 400);
  const notATime = everyDay();
  notATime[3].deliver.from = 'teatime';
  assert.equal((await app.call('PUT', '/api/admin/settings', { schedule: notATime })).status, 400);
  assert.equal((await app.call('PUT', '/api/admin/settings', { facebook_url: 'javascript:alert(1)' })).status, 400);
  assert.equal((await app.call('PUT', '/api/admin/settings', { lead_days: -1 })).status, 400);
  const ok = await app.call('PUT', '/api/admin/settings', { lead_days: 3, made_up_key: 'x' });
  assert.equal(ok.data.settings.lead_days, 3);
  assert.equal('made_up_key' in ok.data.settings, false);
});

test('files outside the app cannot be read', async () => {
  for (const url of ['/uploads/..%2fvelvet-crumb.db', '/uploads/../velvet-crumb.db', '/..%2fsrc%2fserver.js', '/%2e%2e/package.json']) {
    const r = await fetch(app.base + url);
    assert.equal(r.status, 404, url);
  }
  const page = await fetch(app.base + '/order/abc123');
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-security-policy'), /default-src 'self'/);
});

// ---------------------------------------------------------------------------
// Stripe mode, against a fake Stripe API
// ---------------------------------------------------------------------------
test('webhook signature check', () => {
  const body = '{"a":1}';
  const header = signWebhookPayload(body, WEBHOOK_SECRET);
  assert.equal(verifyWebhookSignature(body, header, WEBHOOK_SECRET), true);
  assert.equal(verifyWebhookSignature(body + ' ', header, WEBHOOK_SECRET), false);
  assert.equal(verifyWebhookSignature(body, header, 'whsec_other'), false);
  const old = signWebhookPayload(body, WEBHOOK_SECRET, Math.floor(Date.now() / 1000) - 3600);
  assert.equal(verifyWebhookSignature(body, old, WEBHOOK_SECRET), false);
  assert.deepEqual(formEncode({ a: [{ b: 1 }], c: 'x y' }), ['a%5B0%5D%5Bb%5D=1', 'c=x%20y']);
});

test('Stripe checkout, webhook, fee and refund', async () => {
  const calls = [];
  const fake = http.createServer((req, res) => {
    let body = '';
    req.on('data', (d) => (body += d));
    req.on('end', () => {
      calls.push({ method: req.method, url: req.url, body: new URLSearchParams(body), auth: req.headers.authorization });
      const send = (o) => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(o));
      };
      if (req.method === 'POST' && req.url === '/v1/checkout/sessions') return send({ id: 'cs_test_1', url: 'https://checkout.stripe.com/c/pay/cs_test_1' });
      if (req.url.startsWith('/v1/checkout/sessions/')) return send({ id: 'cs_test_1', payment_status: 'unpaid' });
      if (req.url.startsWith('/v1/payment_intents/pi_1')) return send({ id: 'pi_1', latest_charge: { balance_transaction: { fee: 47 } } });
      if (req.method === 'POST' && req.url === '/v1/refunds') return send({ id: 're_1', status: 'succeeded' });
      res.writeHead(404).end('{}');
    });
  });
  await new Promise((r) => fake.listen(0, r));
  const stripeApp = await startApp({
    STRIPE_SECRET_KEY: 'sk_test_fake',
    STRIPE_WEBHOOK_SECRET: WEBHOOK_SECRET,
    STRIPE_API_BASE: `http://127.0.0.1:${fake.address().port}`,
    BASE_URL: 'https://orders.example.com',
  });
  try {
    const { call } = stripeApp;
    await call('POST', '/api/admin/login', { password: PASSWORD });
    await call('PUT', '/api/admin/settings', { schedule: everyDay() });
    const p = (await call('POST', '/api/admin/products', { name: 'Brownie box', price_pence: 1200, cost_pence: 400, status: 'on' })).data;
    const shop = (await call('GET', '/api/shop')).data;
    assert.equal(shop.testMode, false);

    const placed = await call('POST', '/api/orders', {
      items: [{ id: p.id, qty: 2 }], method: 'delivery', date: nextOpenDate(shop), name: 'Alex Brown', email: 'alex@example.com',
      phone: '07700900456', address: '3 Park Road', postcode: 'S71 2BB', allergensChecked: true,
    });
    assert.equal(placed.status, 201, JSON.stringify(placed.data));
    assert.equal(placed.data.url, 'https://checkout.stripe.com/c/pay/cs_test_1');

    const session = calls.find((c) => c.url === '/v1/checkout/sessions');
    assert.equal(session.auth, 'Bearer sk_test_fake');
    assert.equal(session.body.get('mode'), 'payment');
    assert.equal(session.body.get('line_items[0][price_data][unit_amount]'), '1200');
    assert.equal(session.body.get('line_items[0][quantity]'), '2');
    assert.equal(session.body.get('line_items[1][price_data][unit_amount]'), '300');
    assert.equal(session.body.get('line_items[1][price_data][product_data][name]'), 'Local delivery');
    const token = session.body.get('metadata[order_token]');
    assert.ok(session.body.get('success_url').startsWith(`https://orders.example.com/order/${token}`));

    // Test payments are refused once Stripe is connected
    assert.equal((await call('POST', `/api/orders/${token}/test-pay`)).status, 403);

    const event = JSON.stringify({
      type: 'checkout.session.completed',
      data: { object: { id: 'cs_test_1', payment_status: 'paid', amount_total: 2700, payment_intent: 'pi_1', metadata: { order_token: token } } },
    });
    const bad = await call('POST', '/api/stripe/webhook', event, { headers: { 'Stripe-Signature': 't=1,v1=00' } });
    assert.equal(bad.status, 400);
    const good = await call('POST', '/api/stripe/webhook', event, { headers: { 'Stripe-Signature': signWebhookPayload(event, WEBHOOK_SECRET) } });
    assert.equal(good.status, 200);
    // Same event again (Stripe retries): still just one paid order
    await call('POST', '/api/stripe/webhook', event, { headers: { 'Stripe-Signature': signWebhookPayload(event, WEBHOOK_SECRET) } });

    const view = (await call('GET', `/api/orders/${token}`)).data;
    assert.equal(view.status, 'paid');

    // The real Stripe fee replaces the estimate
    const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/London' }).format(new Date());
    let fees;
    for (let i = 0; i < 20; i += 1) {
      fees = (await call('GET', `/api/admin/finance?from=${today}&to=${today}`)).data.fees;
      if (fees === 47) break;
      await new Promise((r) => setTimeout(r, 100));
    }
    assert.equal(fees, 47);

    const [order] = (await call('GET', '/api/admin/orders?view=upcoming')).data.orders;
    assert.equal((await call('GET', '/api/admin/clients?q=alex')).data.clients.length, 1, 'Stripe payment saves the client');
    const refunded = await call('POST', `/api/admin/orders/${order.id}/cancel`, {});
    assert.equal(refunded.data.status, 'refunded');
    const refundCall = calls.find((c) => c.url === '/v1/refunds');
    assert.equal(refundCall.body.get('payment_intent'), 'pi_1');
  } finally {
    stripeApp.child.kill();
    fake.close();
  }
});
